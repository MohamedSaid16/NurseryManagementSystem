-- Nursery Management System Database Schema
-- Updated with improvements and missing constraints

-- Users table (for authentication)
CREATE TABLE IF NOT EXISTS users (
    _id VARCHAR(255) PRIMARY KEY,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'employee', 'parent') NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    dateOfBirth DATE,
    profileImage VARCHAR(500),
    isActive BOOLEAN DEFAULT true,
    resetPasswordToken VARCHAR(255),
    resetPasswordExpire DATETIME,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Additional constraints
    INDEX idx_users_role_active (role, isActive),
    INDEX idx_users_created (createdAt)
);

-- Children table
CREATE TABLE IF NOT EXISTS children (
    _id VARCHAR(255) PRIMARY KEY,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    dateOfBirth DATE NOT NULL,
    age INT,
    gender ENUM('male', 'female', 'other') NOT NULL,
    room ENUM('infants', 'toddlers', 'preschoolers') NOT NULL,
    allergies TEXT,
    medicalConditions TEXT,
    emergencyContactName VARCHAR(200),
    emergencyContactPhone VARCHAR(20),
    enrollmentDate DATE NOT NULL,
    profileImage VARCHAR(500),
    isActive BOOLEAN DEFAULT true,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Additional constraints and indexes
    CHECK (age BETWEEN 0 AND 6),
    INDEX idx_children_room_active (room, isActive),
    INDEX idx_children_enrollment (enrollmentDate),
    INDEX idx_children_name (lastName, firstName)
);

-- Parents table (extends users)
CREATE TABLE IF NOT EXISTS parents (
    _id VARCHAR(255) PRIMARY KEY,
    userId VARCHAR(255) NOT NULL UNIQUE, -- One user can only be one parent
    occupation VARCHAR(100),
    emergencyContact VARCHAR(20),
    relationshipToChild VARCHAR(50),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(_id) ON DELETE CASCADE,
    
    INDEX idx_parents_user (userId)
);

-- Parent-Child relationships
CREATE TABLE IF NOT EXISTS parent_children (
    _id VARCHAR(255) PRIMARY KEY,
    parentId VARCHAR(255) NOT NULL,
    childId VARCHAR(255) NOT NULL,
    relationship ENUM('mother', 'father', 'guardian', 'other') NOT NULL,
    isPrimary BOOLEAN DEFAULT false,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (parentId) REFERENCES parents(_id) ON DELETE CASCADE,
    FOREIGN KEY (childId) REFERENCES children(_id) ON DELETE CASCADE,
    
    -- Ensure unique parent-child relationships
    UNIQUE KEY unique_parent_child (parentId, childId),
    INDEX idx_parent_children_child (childId),
    INDEX idx_parent_children_parent (parentId)
);

-- Employees table (extends users)
CREATE TABLE IF NOT EXISTS employees (
    _id VARCHAR(255) PRIMARY KEY,
    userId VARCHAR(255) NOT NULL UNIQUE, -- One user can only be one employee
    employeeId VARCHAR(50) UNIQUE NOT NULL,
    position ENUM('teacher', 'assistant', 'administrator', 'director', 'caregiver') NOT NULL,
    qualification TEXT,
    salary DECIMAL(10,2) CHECK (salary >= 0),
    hireDate DATE NOT NULL,
    assignedRoom ENUM('infants', 'toddlers', 'preschoolers', 'all'),
    isActive BOOLEAN DEFAULT true,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (userId) REFERENCES users(_id) ON DELETE CASCADE,
    
    INDEX idx_employees_position (position),
    INDEX idx_employees_room (assignedRoom),
    INDEX idx_employees_active (isActive)
);

-- Attendance table
CREATE TABLE IF NOT EXISTS attendance (
    _id VARCHAR(255) PRIMARY KEY,
    childId VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    checkIn TIME,
    checkOut TIME,
    status ENUM('present', 'absent', 'sick', 'vacation') DEFAULT 'present',
    notes TEXT,
    recordedBy VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (childId) REFERENCES children(_id) ON DELETE CASCADE,
    FOREIGN KEY (recordedBy) REFERENCES employees(_id) ON DELETE CASCADE,
    
    -- One attendance record per child per day
    UNIQUE KEY unique_child_date (childId, date),
    
    -- Additional constraints
    CHECK ((status = 'present' AND checkIn IS NOT NULL) OR status != 'present'),
    CHECK (checkOut IS NULL OR checkIn IS NOT NULL),
    
    INDEX idx_attendance_date_status (date, status),
    INDEX idx_attendance_child_month (childId, date)
);

-- Activities table
CREATE TABLE IF NOT EXISTS activities (
    _id VARCHAR(255) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type ENUM('educational', 'recreational', 'physical', 'creative', 'meal', 'nap') NOT NULL,
    room ENUM('infants', 'toddlers', 'preschoolers') NOT NULL,
    startTime DATETIME NOT NULL,
    endTime DATETIME NOT NULL,
    status ENUM('scheduled', 'in-progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    materials TEXT,
    objectives TEXT,
    createdBy VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (createdBy) REFERENCES employees(_id) ON DELETE CASCADE,
    
    -- Ensure endTime is after startTime
    CHECK (endTime > startTime),
    
    INDEX idx_activities_datetime (startTime, endTime),
    INDEX idx_activities_room_type (room, type),
    INDEX idx_activities_status (status),
    INDEX idx_activities_createdby (createdBy)
);

-- Activity participants (many-to-many relationship)
CREATE TABLE IF NOT EXISTS activity_children (
    _id VARCHAR(255) PRIMARY KEY,
    activityId VARCHAR(255) NOT NULL,
    childId VARCHAR(255) NOT NULL,
    participation ENUM('excellent', 'good', 'average', 'poor') DEFAULT 'good',
    notes TEXT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (activityId) REFERENCES activities(_id) ON DELETE CASCADE,
    FOREIGN KEY (childId) REFERENCES children(_id) ON DELETE CASCADE,
    
    -- Prevent duplicate child-activity entries
    UNIQUE KEY unique_activity_child (activityId, childId),
    
    INDEX idx_activity_children_activity (activityId),
    INDEX idx_activity_children_child (childId)
);

-- Activity assigned employees
CREATE TABLE IF NOT EXISTS activity_employees (
    _id VARCHAR(255) PRIMARY KEY,
    activityId VARCHAR(255) NOT NULL,
    employeeId VARCHAR(255) NOT NULL,
    role VARCHAR(100),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (activityId) REFERENCES activities(_id) ON DELETE CASCADE,
    FOREIGN KEY (employeeId) REFERENCES employees(_id) ON DELETE CASCADE,
    
    -- Prevent duplicate employee-activity assignments
    UNIQUE KEY unique_activity_employee (activityId, employeeId),
    
    INDEX idx_activity_employees_activity (activityId),
    INDEX idx_activity_employees_employee (employeeId)
);

-- Medical records table
CREATE TABLE IF NOT EXISTS medical_records (
    _id VARCHAR(255) PRIMARY KEY,
    childId VARCHAR(255) NOT NULL,
    recordDate DATE NOT NULL,
    height DECIMAL(4,1) CHECK (height > 0 AND height < 200),
    weight DECIMAL(4,1) CHECK (weight > 0 AND weight < 100),
    temperature DECIMAL(3,1) CHECK (temperature BETWEEN 35 AND 42),
    symptoms TEXT,
    diagnosis TEXT,
    medication TEXT,
    dosage TEXT,
    administeredBy VARCHAR(255),
    notes TEXT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (childId) REFERENCES children(_id) ON DELETE CASCADE,
    FOREIGN KEY (administeredBy) REFERENCES employees(_id) ON DELETE CASCADE,
    
    INDEX idx_medical_child_date (childId, recordDate),
    INDEX idx_medical_date (recordDate)
);

-- Billing and invoices table
CREATE TABLE IF NOT EXISTS invoices (
    _id VARCHAR(255) PRIMARY KEY,
    invoiceNumber VARCHAR(100) UNIQUE NOT NULL,
    childId VARCHAR(255) NOT NULL,
    parentId VARCHAR(255) NOT NULL,
    issueDate DATE NOT NULL,
    dueDate DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL CHECK (amount >= 0),
    taxAmount DECIMAL(10,2) DEFAULT 0 CHECK (taxAmount >= 0),
    totalAmount DECIMAL(10,2) NOT NULL CHECK (totalAmount >= 0),
    status ENUM('draft', 'sent', 'paid', 'overdue', 'cancelled') DEFAULT 'draft',
    items JSON,
    notes TEXT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (childId) REFERENCES children(_id) ON DELETE CASCADE,
    FOREIGN KEY (parentId) REFERENCES parents(_id) ON DELETE CASCADE,
    
    -- Ensure due date is after issue date
    CHECK (dueDate >= issueDate),
    
    INDEX idx_invoices_parent (parentId),
    INDEX idx_invoices_child (childId),
    INDEX idx_invoices_due_status (dueDate, status),
    INDEX idx_invoices_number (invoiceNumber)
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
    _id VARCHAR(255) PRIMARY KEY,
    invoiceId VARCHAR(255) NOT NULL,
    paymentDate DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
    paymentMethod ENUM('cash', 'card', 'bank_transfer', 'check') NOT NULL,
    referenceNumber VARCHAR(100),
    notes TEXT,
    processedBy VARCHAR(255),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (invoiceId) REFERENCES invoices(_id) ON DELETE CASCADE,
    FOREIGN KEY (processedBy) REFERENCES employees(_id) ON DELETE CASCADE,
    
    INDEX idx_payments_invoice (invoiceId),
    INDEX idx_payments_date (paymentDate),
    INDEX idx_payments_method (paymentMethod)
);

-- Messages/communications table
CREATE TABLE IF NOT EXISTS messages (
    _id VARCHAR(255) PRIMARY KEY,
    senderId VARCHAR(255) NOT NULL,
    receiverId VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    messageType ENUM('general', 'medical', 'payment', 'attendance', 'activity', 'emergency') DEFAULT 'general',
    isRead BOOLEAN DEFAULT false,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'low',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (senderId) REFERENCES users(_id) ON DELETE CASCADE,
    FOREIGN KEY (receiverId) REFERENCES users(_id) ON DELETE CASCADE,
    
    INDEX idx_messages_receiver_read (receiverId, isRead),
    INDEX idx_messages_sender (senderId),
    INDEX idx_messages_priority (priority),
    INDEX idx_messages_created (createdAt)
);

-- Additional tables that might be needed:

-- Room capacity table
CREATE TABLE IF NOT EXISTS room_capacity (
    _id VARCHAR(255) PRIMARY KEY,
    room ENUM('infants', 'toddlers', 'preschoolers') UNIQUE NOT NULL,
    maxCapacity INT NOT NULL CHECK (maxCapacity > 0),
    currentOccupancy INT DEFAULT 0 CHECK (currentOccupancy >= 0),
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Notification preferences table
CREATE TABLE IF NOT EXISTS notification_preferences (
    _id VARCHAR(255) PRIMARY KEY,
    userId VARCHAR(255) NOT NULL UNIQUE,
    emailNotifications BOOLEAN DEFAULT true,
    smsNotifications BOOLEAN DEFAULT false,
    pushNotifications BOOLEAN DEFAULT true,
    messageTypes JSON, -- Which types of messages to receive
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (userId) REFERENCES users(_id) ON DELETE CASCADE
);

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_logs (
    _id VARCHAR(255) PRIMARY KEY,
    action VARCHAR(100) NOT NULL,
    tableName VARCHAR(100) NOT NULL,
    recordId VARCHAR(255) NOT NULL,
    oldValues JSON,
    newValues JSON,
    performedBy VARCHAR(255) NOT NULL,
    performedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (performedBy) REFERENCES users(_id) ON DELETE CASCADE,
    
    INDEX idx_audit_action (action),
    INDEX idx_audit_table (tableName),
    INDEX idx_audit_user (performedBy),
    INDEX idx_audit_timestamp (performedAt)
);

-- Create additional indexes for better performance
CREATE INDEX idx_attendance_month ON attendance(date);
CREATE INDEX idx_activities_date_range ON activities(startTime, endTime);
CREATE INDEX idx_invoices_month ON invoices(issueDate);
CREATE INDEX idx_messages_type_priority ON messages(messageType, priority);
CREATE INDEX idx_children_active_room ON children(isActive, room);
CREATE INDEX idx_users_active_role ON users(isActive, role);

-- Insert initial room capacity data
INSERT IGNORE INTO room_capacity (_id, room, maxCapacity, currentOccupancy) VALUES
(UUID(), 'infants', 8, 0),
(UUID(), 'toddlers', 12, 0),
(UUID(), 'preschoolers', 15, 0);