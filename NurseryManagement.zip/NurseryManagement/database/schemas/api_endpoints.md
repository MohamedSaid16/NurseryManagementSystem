# API Endpoints Reference

## Base URL: `/api`

### Authentication
- `POST /auth/register` - Register new user
- `POST /auth/login` - Login user  
- `GET /auth/me` - Get current user
- `PUT /auth/updatedetails` - Update user details
- `PUT /auth/updatepassword` - Update password
- `POST /auth/forgotpassword` - Request password reset
- `PUT /auth/resetpassword/:resettoken` - Reset password
- `GET /auth/logout` - Logout user

### Children
- `GET /children` - Get all children
- `GET /children/:id` - Get child by ID
- `POST /children` - Create new child
- `PUT /children/:id` - Update child
- `DELETE /children/:id` - Delete child

### Activities  
- `GET /activities` - Get all activities
- `GET /activities/:id` - Get activity by ID
- `POST /activities` - Create activity
- `PUT /activities/:id` - Update activity
- `DELETE /activities/:id` - Delete activity
- `POST /activities/:id/children` - Add child to activity
- `DELETE /activities/:id/children/:childId` - Remove child from activity

### Attendance
- `GET /attendance` - Get attendance records
- `POST /attendance` - Record attendance
- `PUT /attendance/:id` - Update attendance

### Employees
- `GET /employees` - Get all employees
- `GET /employees/:id` - Get employee by ID
- `POST /employees` - Create employee
- `PUT /employees/:id` - Update employee