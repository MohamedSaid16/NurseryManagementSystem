# Data Validation Rules

## User Validation
- **firstName**: Required, 2-50 characters, letters and basic punctuation only
- **lastName**: Required, 2-50 characters, letters and basic punctuation only
- **email**: Required, valid email format, unique across system
- **password**: Required, min 8 characters, must contain:
  - At least one uppercase letter
  - At least one lowercase letter  
  - At least one number
  - At least one special character
- **phone**: Optional, must match format: +1-234-567-8900 or (234) 567-8900
- **role**: Required, must be one of: admin, employee, parent
- **dateOfBirth**: Optional, must be valid date, user must be at least 18 years old

## Child Validation
- **firstName**: Required, 2-50 characters, letters only
- **lastName**: Required, 2-50 characters, letters only
- **dateOfBirth**: Required, must be valid date, child must be between 0-6 years
- **age**: Auto-calculated from dateOfBirth, must be between 0-6
- **gender**: Required, must be one of: male, female, other
- **room**: Required, must be one of: infants, toddlers, preschoolers
- **allergies**: Optional, max 500 characters
- **medicalConditions**: Optional, max 500 characters
- **emergencyContactName**: Required if child enrolled, 2-100 characters
- **emergencyContactPhone**: Required if child enrolled, valid phone format
- **enrollmentDate**: Required, must be valid date, cannot be future date

## Employee Validation
- **employeeId**: Required, unique, 3-20 characters, alphanumeric
- **position**: Required, must be one of: teacher, assistant, administrator, director, caregiver
- **qualification**: Optional, max 200 characters
- **salary**: Optional, must be positive number if provided
- **hireDate**: Required, must be valid date, cannot be future date
- **assignedRoom**: Optional, must be one of: infants, toddlers, preschoolers, all

## Attendance Validation
- **childId**: Required, must reference existing child
- **date**: Required, cannot be future date
- **checkIn**: Required if status is 'present', must be valid time between 6:00 AM and 10:00 AM
- **checkOut**: Optional, must be after checkIn if provided, must be between 12:00 PM and 8:00 PM
- **status**: Required, must be one of: present, absent, sick, vacation
- **notes**: Optional, max 1000 characters

## Activity Validation
- **title**: Required, 5-200 characters
- **description**: Optional, max 1000 characters
- **type**: Required, must be one of: educational, recreational, physical, creative, meal, nap
- **room**: Required, must match existing room
- **startTime**: Required, must be valid datetime
- **endTime**: Required, must be after startTime, duration cannot exceed 4 hours
- **status**: Required, must be one of: scheduled, in-progress, completed, cancelled
- **materials**: Optional, max 500 characters
- **objectives**: Optional, max 500 characters

## Billing Validation
- **invoiceNumber**: Required, unique, format: INV-YYYY-MM-XXXX
- **amount**: Required, must be positive number, minimum $10
- **taxAmount**: Required, must be non-negative number
- **totalAmount**: Required, must equal amount + taxAmount
- **issueDate**: Required, must be valid date
- **dueDate**: Required, must be after issue date, within 30 days
- **status**: Required, must be one of: draft, sent, paid, overdue, cancelled

## Payment Validation
- **amount**: Required, must be positive number, cannot exceed invoice balance
- **paymentDate**: Required, cannot be future date
- **paymentMethod**: Required, must be one of: cash, card, bank_transfer, check
- **referenceNumber**: Required for card/bank transfers, unique

## Medical Record Validation
- **height**: Optional, must be between 10-200 cm if provided
- **weight**: Optional, must be between 1-100 kg if provided
- **temperature**: Optional, must be between 35-42°C if provided
- **recordDate**: Required, cannot be future date

## Message Validation
- **subject**: Optional, max 255 characters
- **message**: Required, 1-2000 characters
- **messageType**: Required, must be one of: general, medical, payment, attendance, activity, emergency
- **priority**: Required, must be one of: low, medium, high, urgent

## Business Rules
- A child cannot be enrolled if they are over 6 years old
- Attendance cannot be recorded for future dates
- Activities cannot overlap for the same room
- Invoices cannot be issued for inactive children
- Payments cannot exceed the invoice total amount
- Medical records can only be added by authorized employees