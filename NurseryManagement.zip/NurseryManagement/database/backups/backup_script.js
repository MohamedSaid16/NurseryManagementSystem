const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');

class DatabaseBackup {
  constructor() {
    this.backupDir = path.join(__dirname, 'backup_files');
    this.ensureBackupDir();
  }
  
  ensureBackupDir() {
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }
  }
  
  // Create MongoDB backup
  createBackup() {
    return new Promise((resolve, reject) => {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupFile = path.join(this.backupDir, `nursery-backup-${timestamp}.gz`);
      
      const uri = process.env.MONGODB_URI;
      if (!uri) {
        reject(new Error('MONGODB_URI not found in environment variables'));
        return;
      }
      
      const command = `mongodump --uri="${uri}" --archive="${backupFile}" --gzip`;
      
      console.log('Creating database backup...');
      exec(command, (error, stdout, stderr) => {
        if (error) {
          reject(error);
          return;
        }
        
        console.log(`Backup created successfully: ${backupFile}`);
        resolve(backupFile);
      });
    });
  }
  
  // Restore MongoDB backup
  restoreBackup(backupFile) {
    return new Promise((resolve, reject) => {
      if (!fs.existsSync(backupFile)) {
        reject(new Error('Backup file not found'));
        return;
      }
      
      const uri = process.env.MONGODB_URI;
      if (!uri) {
        reject(new Error('MONGODB_URI not found in environment variables'));
        return;
      }
      
      const command = `mongorestore --uri="${uri}" --archive="${backupFile}" --gzip --drop`;
      
      console.log('Restoring database backup...');
      exec(command, (error, stdout, stderr) => {
        if (error) {
          reject(error);
          return;
        }
        
        console.log('Backup restored successfully');
        resolve();
      });
    });
  }
  
  // List available backups
  listBackups() {
    return new Promise((resolve, reject) => {
      fs.readdir(this.backupDir, (err, files) => {
        if (err) {
          reject(err);
          return;
        }
        
        const backupFiles = files
          .filter(file => file.startsWith('nursery-backup-') && file.endsWith('.gz'))
          .map(file => {
            const filePath = path.join(this.backupDir, file);
            const stats = fs.statSync(filePath);
            return {
              filename: file,
              path: filePath,
              size: (stats.size / (1024 * 1024)).toFixed(2) + ' MB',
              created: stats.birthtime
            };
          })
          .sort((a, b) => b.created - a.created);
        
        resolve(backupFiles);
      });
    });
  }
  
  // Manual backup via code (alternative to mongodump)
  async manualBackup() {
    try {
      const collections = await mongoose.connection.db.listCollections().toArray();
      const backupData = {};
      const timestamp = new Date().toISOString();
      
      for (const collectionInfo of collections) {
        const collectionName = collectionInfo.name;
        const documents = await mongoose.connection.db.collection(collectionName).find({}).toArray();
        backupData[collectionName] = documents;
      }
      
      const backupFile = path.join(this.backupDir, `manual-backup-${timestamp.replace(/[:.]/g, '-')}.json`);
      fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2));
      
      console.log(`Manual backup created: ${backupFile}`);
      return backupFile;
    } catch (error) {
      console.error('Manual backup failed:', error);
      throw error;
    }
  }
}

module.exports = DatabaseBackup;

// Example usage:
// const backup = new DatabaseBackup();
// backup.createBackup().then(console.log).catch(console.error);