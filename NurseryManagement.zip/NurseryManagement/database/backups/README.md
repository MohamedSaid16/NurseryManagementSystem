# Database Backup System

## Overview
This directory contains scripts for backing up and restoring the MongoDB database.

## Files
- `backup_script.js` - Main backup/restore functionality
- `backup_files/` - Directory where backup files are stored (auto-created)

## Usage

### Create Backup
```bash
node -e "const Backup = require('./backup_script'); new Backup().createBackup();"