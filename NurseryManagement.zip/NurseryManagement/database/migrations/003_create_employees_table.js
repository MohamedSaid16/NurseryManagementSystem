const createEmployeesTable = async (db) => {
  try {
    console.log('Creating employees table...');
    
    await db.createCollection('employees', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: ['userId', 'employeeId', 'position', 'hireDate'],
          properties: {
            userId: {
              bsonType: 'objectId',
              description: 'must be an objectid and is required'
            },
            employeeId: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 3,
              maxLength: 20
            },
            position: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 2,
              maxLength: 100
            },
            qualification: {
              bsonType: 'string',
              description: 'must be a string'
            },
            salary: {
              bsonType: 'number',
              description: 'must be a number',
              minimum: 0
            },
            hireDate: {
              bsonType: 'date',
              description: 'must be a date and is required'
            },
            assignedRoom: {
              enum: ['infants', 'toddlers', 'preschoolers', 'all'],
              description: 'must be one of the enum values'
            },
            isActive: {
              bsonType: 'bool',
              description: 'must be a boolean'
            }
          }
        }
      }
    });

    // Create indexes
    await db.collection('employees').createIndex({ employeeId: 1 }, { unique: true });
    await db.collection('employees').createIndex({ userId: 1 }, { unique: true });
    await db.collection('employees').createIndex({ position: 1 });
    await db.collection('employees').createIndex({ assignedRoom: 1 });
    await db.collection('employees').createIndex({ isActive: 1 });

    console.log('Employees table created successfully');
  } catch (error) {
    console.error('Error creating employees table:', error);
    throw error;
  }
};

module.exports = createEmployeesTable;