const createUsersTable = async (db) => {
  try {
    console.log('Creating users table...');
    
    await db.createCollection('users', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: ['firstName', 'lastName', 'email', 'password', 'role'],
          properties: {
            firstName: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 2,
              maxLength: 50
            },
            lastName: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 2,
              maxLength: 50
            },
            email: {
              bsonType: 'string',
              description: 'must be a string and is required',
              pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'
            },
            password: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 6
            },
            role: {
              enum: ['admin', 'employee', 'parent'],
              description: 'must be one of the enum values and is required'
            },
            phone: {
              bsonType: 'string',
              description: 'must be a string'
            },
            address: {
              bsonType: 'string',
              description: 'must be a string'
            },
            profileImage: {
              bsonType: 'string',
              description: 'must be a string'
            },
            isActive: {
              bsonType: 'bool',
              description: 'must be a boolean'
            }
          }
        }
      }
    });

    // Create indexes
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('users').createIndex({ role: 1 });
    await db.collection('users').createIndex({ isActive: 1 });

    console.log('Users table created successfully');
  } catch (error) {
    console.error('Error creating users table:', error);
    throw error;
  }
};

module.exports = createUsersTable;