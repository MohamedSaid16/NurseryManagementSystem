const createChildrenTable = async (db) => {
  try {
    console.log('Creating children table...');
    
    await db.createCollection('children', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: ['firstName', 'lastName', 'dateOfBirth', 'gender', 'room', 'enrollmentDate'],
          properties: {
            firstName: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 2,
              maxLength: 50
            },
            lastName: {
              bsonType: 'string',
              description: 'must be a string and is required',
              minLength: 2,
              maxLength: 50
            },
            dateOfBirth: {
              bsonType: 'date',
              description: 'must be a date and is required'
            },
            age: {
              bsonType: 'int',
              description: 'must be an integer',
              minimum: 0,
              maximum: 6
            },
            gender: {
              enum: ['male', 'female', 'other'],
              description: 'must be one of the enum values and is required'
            },
            room: {
              enum: ['infants', 'toddlers', 'preschoolers'],
              description: 'must be one of the enum values and is required'
            },
            allergies: {
              bsonType: 'string',
              description: 'must be a string'
            },
            medicalConditions: {
              bsonType: 'string',
              description: 'must be a string'
            },
            emergencyContactName: {
              bsonType: 'string',
              description: 'must be a string'
            },
            emergencyContactPhone: {
              bsonType: 'string',
              description: 'must be a string'
            },
            enrollmentDate: {
              bsonType: 'date',
              description: 'must be a date and is required'
            },
            profileImage: {
              bsonType: 'string',
              description: 'must be a string'
            },
            isActive: {
              bsonType: 'bool',
              description: 'must be a boolean'
            }
          }
        }
      }
    });

    // Create indexes
    await db.collection('children').createIndex({ room: 1 });
    await db.collection('children').createIndex({ isActive: 1 });
    await db.collection('children').createIndex({ enrollmentDate: -1 });
    await db.collection('children').createIndex({ lastName: 1, firstName: 1 });

    console.log('Children table created successfully');
  } catch (error) {
    console.error('Error creating children table:', error);
    throw error;
  }
};

module.exports = createChildrenTable;