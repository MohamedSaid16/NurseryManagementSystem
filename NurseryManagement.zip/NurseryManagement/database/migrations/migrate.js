#!/usr/bin/env node

const mongoose = require('mongoose');
require('dotenv').config();

const runAllMigrations = async () => {
  console.log('🚀 Starting Database Migrations...\n');
  
  try {
    // Check if MONGODB_URI is set
    if (!process.env.MONGODB_URI) {
      throw new Error('MONGODB_URI environment variable is not set');
    }
    
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    const db = mongoose.connection.db;
    
    // Get all migration files
    const migrationFiles = [
      { name: '001_create_users_table', module: require('./001_create_users_table') },
      { name: '002_create_children_table', module: require('./002_create_children_table') },
      { name: '003_create_employees_table', module: require('./003_create_employees_table') },
      { name: '004_create_attendance_table', module: require('./004_create_attendance_table') }
    ];
    
    // Check if migrations collection exists
    const migrationsCollection = db.collection('migrations');
    const appliedMigrations = await migrationsCollection.find({}).toArray();
    const appliedMigrationNames = appliedMigrations.map(m => m.name);
    
    // Run migrations that haven't been applied
    for (const migration of migrationFiles) {
      if (!appliedMigrationNames.includes(migration.name)) {
        console.log(`🔄 Running migration: ${migration.name}`);
        await migration.module(db);
        
        // Record migration in database
        await migrationsCollection.insertOne({
          name: migration.name,
          appliedAt: new Date(),
          status: 'completed'
        });
        
        console.log(`✅ Completed: ${migration.name}`);
      } else {
        console.log(`⏭️  Skipping (already applied): ${migration.name}`);
      }
    }
    
    console.log('\n🎉 All migrations completed successfully!');
    
  } catch (error) {
    console.error('\n❌ Migration failed:', error.message);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
    console.log('📡 Database connection closed');
  }
};

// Run migrations if script is executed directly
if (require.main === module) {
  runAllMigrations().catch(console.error);
}

module.exports = runAllMigrations;