const mongoose = require('mongoose');
require('dotenv').config();

const runMigrations = async () => {
  let connection;
  
  try {
    // Connect to database
    connection = await mongoose.connect(process.env.MONGODB_URI);
    const db = mongoose.connection.db;
    
    console.log('Connected to database for migrations');
    
    // Run migrations in order
    const migrations = [
      require('./001_create_users_table'),
      require('./002_create_children_table'), 
      require('./003_create_employees_table'),
      require('./004_create_attendance_table')
    ];
    
    for (const migration of migrations) {
      await migration(db);
    }
    
    console.log('All migrations completed successfully!');
    
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await mongoose.disconnect();
    }
  }
};

// Run if called directly
if (require.main === module) {
  runMigrations();
}

module.exports = runMigrations;