const createAttendanceTable = async (db) => {
  try {
    console.log('Creating attendance table...');
    
    await db.createCollection('attendance', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: ['childId', 'date', 'status', 'recordedBy'],
          properties: {
            childId: {
              bsonType: 'objectId',
              description: 'must be an objectid and is required'
            },
            date: {
              bsonType: 'date',
              description: 'must be a date and is required'
            },
            checkIn: {
              bsonType: 'date',
              description: 'must be a date'
            },
            checkOut: {
              bsonType: 'date',
              description: 'must be a date'
            },
            status: {
              enum: ['present', 'absent', 'sick', 'vacation'],
              description: 'must be one of the enum values and is required'
            },
            notes: {
              bsonType: 'string',
              description: 'must be a string'
            },
            recordedBy: {
              bsonType: 'objectId',
              description: 'must be an objectid and is required'
            }
          }
        }
      }
    });

    // Create indexes
    await db.collection('attendance').createIndex({ date: 1 });
    await db.collection('attendance').createIndex({ childId: 1, date: 1 }, { unique: true });
    await db.collection('attendance').createIndex({ status: 1 });
    await db.collection('attendance').createIndex({ recordedBy: 1 });

    console.log('Attendance table created successfully');
  } catch (error) {
    console.error('Error creating attendance table:', error);
    throw error;
  }
};

module.exports = createAttendanceTable;