const mongoose = require('mongoose');
require('dotenv').config();

const runSeeds = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to database for seeding');
    
    // Run seeds in order
    const seeds = [
      require('./admin_seed'),
      require('./sample_data_seed')
    ];
    
    for (const seed of seeds) {
      await seed();
    }
    
    console.log('All seeds completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Seeding failed:', error);
    process.exit(1);
  }
};

// Run if called directly
if (require.main === module) {
  runSeeds();
}

module.exports = runSeeds;