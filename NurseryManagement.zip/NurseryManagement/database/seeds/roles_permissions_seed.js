const mongoose = require('mongoose');

const seedRolesAndPermissions = async () => {
  try {
    console.log('Seeding roles and permissions...');
    
    const db = mongoose.connection.db;
    
    // Define roles with permissions
    const roles = [
      {
        name: 'admin',
        description: 'System Administrator - Full access to all features',
        permissions: [
          // User management
          'users:create', 'users:read', 'users:update', 'users:delete',
          // Child management
          'children:create', 'children:read', 'children:update', 'children:delete',
          // Employee management
          'employees:create', 'employees:read', 'employees:update', 'employees:delete',
          // Parent management
          'parents:create', 'parents:read', 'parents:update', 'parents:delete',
          // Attendance
          'attendance:create', 'attendance:read', 'attendance:update', 'attendance:delete',
          // Activities
          'activities:create', 'activities:read', 'activities:update', 'activities:delete',
          // Billing
          'billing:create', 'billing:read', 'billing:update', 'billing:delete',
          // Reports
          'reports:generate', 'reports:export',
          // System
          'system:configure', 'system:backup'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'employee',
        description: 'Staff Member - Access to child care and activity management',
        permissions: [
          // Child management
          'children:read', 'children:update',
          // Attendance
          'attendance:create', 'attendance:read', 'attendance:update',
          // Activities
          'activities:create', 'activities:read', 'activities:update',
          // Basic reports
          'reports:generate',
          // Messaging
          'messages:send', 'messages:read'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'parent',
        description: 'Parent - Access to their child information and communications',
        permissions: [
          // Child information
          'children:read',
          // Attendance
          'attendance:read',
          // Activities
          'activities:read',
          // Billing
          'billing:read', 'payments:view',
          // Messaging
          'messages:send', 'messages:read',
          // Profile
          'profile:update'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    // Insert roles into database
    const rolesCollection = db.collection('roles');
    
    for (const role of roles) {
      const existingRole = await rolesCollection.findOne({ name: role.name });
      if (!existingRole) {
        await rolesCollection.insertOne(role);
        console.log(`✅ Created role: ${role.name}`);
      } else {
        // Update existing role
        await rolesCollection.updateOne(
          { name: role.name },
          { $set: { 
            permissions: role.permissions,
            description: role.description,
            updatedAt: new Date()
          }}
        );
        console.log(`✅ Updated role: ${role.name}`);
      }
    }
    
    console.log('Roles and permissions seeded successfully');
    
  } catch (error) {
    console.error('Roles and permissions seeding failed:', error);
    throw error;
  }
};

module.exports = seedRolesAndPermissions;