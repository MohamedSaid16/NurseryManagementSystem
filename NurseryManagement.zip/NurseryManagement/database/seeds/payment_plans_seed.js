const mongoose = require('mongoose');

const seedPaymentPlans = async () => {
  try {
    console.log('Seeding payment plans...');
    
    const db = mongoose.connection.db;
    
    // Define payment plans
    const paymentPlans = [
      {
        name: 'Full-Time Infant Care',
        description: 'Full-time care for infants (0-12 months) - 5 days per week',
        rate: 1200.00,
        billingCycle: 'monthly',
        ageGroup: 'infant',
        hoursIncluded: 'full-time',
        careHours: '8:00 AM - 6:00 PM',
        daysPerWeek: 5,
        features: [
          'Individualized care plans',
          'Daily activity reports',
          'Meals and snacks included',
          'Developmental assessments',
          'Parent communication app access'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Full-Time Toddler Care',
        description: 'Full-time care for toddlers (1-3 years) - 5 days per week',
        rate: 1100.00,
        billingCycle: 'monthly',
        ageGroup: 'toddler',
        hoursIncluded: 'full-time',
        careHours: '8:00 AM - 6:00 PM',
        daysPerWeek: 5,
        features: [
          'Structured learning activities',
          'Social development programs',
          'Meals and snacks included',
          'Progress reports',
          'Outdoor play activities'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Full-Time Preschool',
        description: 'Full-time preschool program (3-5 years) - 5 days per week',
        rate: 1000.00,
        billingCycle: 'monthly',
        ageGroup: 'preschool',
        hoursIncluded: 'full-time',
        careHours: '8:00 AM - 6:00 PM',
        daysPerWeek: 5,
        features: [
          'Curriculum-based learning',
          'School readiness program',
          'Meals and snacks included',
          'Weekly progress updates',
          'Specialized activities'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Part-Time Preschool',
        description: 'Part-time preschool program (3-5 years) - 3 days per week',
        rate: 650.00,
        billingCycle: 'monthly',
        ageGroup: 'preschool',
        hoursIncluded: 'part-time',
        careHours: '9:00 AM - 3:00 PM',
        daysPerWeek: 3,
        features: [
          'Curriculum-based learning',
          'Social development focus',
          'Snacks included',
          'Progress reports',
          'Flexible scheduling'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Drop-In Care',
        description: 'Flexible care as needed - hourly rate',
        rate: 15.00,
        billingCycle: 'hourly',
        ageGroup: 'all',
        hoursIncluded: 'flexible',
        careHours: 'As scheduled',
        daysPerWeek: 0,
        features: [
          'Flexible scheduling',
          'No long-term commitment',
          'All ages welcome',
          'Advance booking required',
          'Subject to availability'
        ],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    // Insert payment plans into database
    const plansCollection = db.collection('paymentplans');
    
    for (const plan of paymentPlans) {
      const existingPlan = await plansCollection.findOne({ name: plan.name });
      if (!existingPlan) {
        await plansCollection.insertOne(plan);
        console.log(`✅ Created payment plan: ${plan.name}`);
      } else {
        // Update existing plan
        await plansCollection.updateOne(
          { name: plan.name },
          { $set: {
            rate: plan.rate,
            description: plan.description,
            features: plan.features,
            updatedAt: new Date()
          }}
        );
        console.log(`✅ Updated payment plan: ${plan.name}`);
      }
    }
    
    console.log('Payment plans seeded successfully');
    
  } catch (error) {
    console.error('Payment plans seeding failed:', error);
    throw error;
  }
};

module.exports = seedPaymentPlans;