const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../../backend/models/User');

const seedAdmin = async () => {
  try {
    console.log('Seeding admin user...');
    
    // Check if admin already exists
    const existingAdmin = await User.findOne({ email: 'admin@nursery.com' });
    if (existingAdmin) {
      console.log('Admin user already exists');
      return;
    }
    
    // Create admin user
    const admin = await User.create({
      firstName: 'System',
      lastName: 'Admin',
      email: 'admin@nursery.com',
      password: 'admin123',
      role: 'admin',
      phone: '+1234567890',
      isActive: true
    });
    
    console.log('Admin user created successfully:', admin.email);
  } catch (error) {
    console.error('Admin seeding failed:', error);
    throw error;
  }
};

module.exports = seedAdmin;