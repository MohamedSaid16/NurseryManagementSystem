const mongoose = require('mongoose');
const Child = require('../../backend/models/Child');

const seedSampleChildren = async () => {
  try {
    console.log('Seeding sample children...');
    
    const children = [
      {
        firstName: 'Emma',
        lastName: 'Wilson',
        dateOfBirth: new Date('2021-05-15'),
        gender: 'female',
        room: 'toddlers',
        allergies: 'None',
        medicalConditions: 'None',
        emergencyContactName: 'Lisa Wilson',
        emergencyContactPhone: '+1234567893',
        enrollmentDate: new Date('2023-01-10'),
        isActive: true
      },
      {
        firstName: 'Noah',
        lastName: 'Brown',
        dateOfBirth: new Date('2022-02-20'),
        gender: 'male',
        room: 'infants',
        allergies: 'Peanuts',
        medicalConditions: 'Mild asthma',
        emergencyContactName: 'David Brown',
        emergencyContactPhone: '+1234567894',
        enrollmentDate: new Date('2023-03-15'),
        isActive: true
      },
      {
        firstName: 'Olivia',
        lastName: 'Garcia',
        dateOfBirth: new Date('2020-08-10'),
        gender: 'female',
        room: 'preschoolers',
        allergies: 'Dairy',
        medicalConditions: 'None',
        emergencyContactName: 'Maria Garcia',
        emergencyContactPhone: '+1234567895',
        enrollmentDate: new Date('2022-09-05'),
        isActive: true
      },
      {
        firstName: 'Liam',
        lastName: 'Smith',
        dateOfBirth: new Date('2021-11-30'),
        gender: 'male',
        room: 'toddlers',
        allergies: 'None',
        medicalConditions: 'None',
        emergencyContactName: 'Jennifer Smith',
        emergencyContactPhone: '+1234567896',
        enrollmentDate: new Date('2023-02-20'),
        isActive: true
      }
    ];
    
    for (const childData of children) {
      const existingChild = await Child.findOne({ 
        firstName: childData.firstName, 
        lastName: childData.lastName 
      });
      
      if (!existingChild) {
        // Calculate age
        const today = new Date();
        const birthDate = new Date(childData.dateOfBirth);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        
        await Child.create({
          ...childData,
          age: age
        });
        
        console.log(`Child created: ${childData.firstName} ${childData.lastName}`);
      }
    }
    
    console.log('Sample children seeded successfully');
  } catch (error) {
    console.error('Children seeding failed:', error);
    throw error;
  }
};

module.exports = seedSampleChildren;