const mongoose = require('mongoose');
const User = require('../../backend/models/User');
const Employee = require('../../backend/models/Employee');

const seedEmployees = async () => {
  try {
    console.log('Seeding employees...');
    
    const employees = [
      {
        firstName: 'Sarah',
        lastName: 'Johnson',
        email: 'sarah.johnson@nursery.com',
        password: 'employee123',
        role: 'employee',
        phone: '+1234567891',
        employeeId: 'EMP001',
        position: 'Lead Teacher',
        qualification: 'Early Childhood Education Degree',
        hireDate: new Date('2022-01-15'),
        assignedRoom: 'toddlers'
      },
      {
        firstName: 'Mike',
        lastName: 'Chen',
        email: 'mike.chen@nursery.com',
        password: 'employee123',
        role: 'employee',
        phone: '+1234567892',
        employeeId: 'EMP002',
        position: 'Assistant Teacher',
        qualification: 'Child Development Certificate',
        hireDate: new Date('2023-03-20'),
        assignedRoom: 'infants'
      },
      {
        firstName: 'Emily',
        lastName: 'Rodriguez',
        email: 'emily.rodriguez@nursery.com',
        password: 'employee123',
        role: 'employee',
        phone: '+1234567893',
        employeeId: 'EMP003',
        position: 'Preschool Teacher',
        qualification: 'Bachelor in Education',
        hireDate: new Date('2021-08-10'),
        assignedRoom: 'preschoolers'
      }
    ];
    
    for (const empData of employees) {
      const existingUser = await User.findOne({ email: empData.email });
      if (!existingUser) {
        const user = await User.create({
          firstName: empData.firstName,
          lastName: empData.lastName,
          email: empData.email,
          password: empData.password,
          role: empData.role,
          phone: empData.phone,
          isActive: true
        });
        
        await Employee.create({
          userId: user._id,
          employeeId: empData.employeeId,
          position: empData.position,
          qualification: empData.qualification,
          hireDate: empData.hireDate,
          assignedRoom: empData.assignedRoom,
          isActive: true
        });
        
        console.log(`Employee created: ${empData.firstName} ${empData.lastName}`);
      }
    }
    
    console.log('Employees seeded successfully');
  } catch (error) {
    console.error('Employees seeding failed:', error);
    throw error;
  }
};

module.exports = seedEmployees;