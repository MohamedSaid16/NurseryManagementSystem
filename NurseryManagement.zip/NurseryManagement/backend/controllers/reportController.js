const Child = require('../models/Child');
const Attendance = require('../models/Attendance');
const Activity = require('../models/Activity');
const Invoice = require('../models/Invoice');
const Payment = require('../models/Payment');
const Employee = require('../models/Employee');
const generateReports = require('../utils/generateReports');

// Generate attendance report
exports.generateAttendanceReport = async (req, res) => {
  try {
    const { startDate, endDate, format = 'pdf' } = req.body;

    const attendance = await Attendance.find({
      date: { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      }
    })
    .populate('child', 'firstName lastName room')
    .populate('recordedBy', 'firstName lastName')
    .sort({ date: 1, 'child.firstName': 1 });

    // Calculate statistics
    const stats = await Attendance.aggregate([
      {
        $match: {
          date: { 
            $gte: new Date(startDate), 
            $lte: new Date(endDate) 
          }
        }
      },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const totalRecords = stats.reduce((sum, stat) => sum + stat.count, 0);
    const presentCount = stats.find(stat => stat._id === 'present')?.count || 0;
    const attendanceRate = totalRecords > 0 ? (presentCount / totalRecords) * 100 : 0;

    const reportData = {
      type: 'attendance',
      title: 'Attendance Report',
      period: `${startDate} to ${endDate}`,
      generatedAt: new Date(),
      data: attendance,
      statistics: {
        total: totalRecords,
        present: presentCount,
        absent: stats.find(stat => stat._id === 'absent')?.count || 0,
        late: stats.find(stat => stat._id === 'late')?.count || 0,
        excused: stats.find(stat => stat._id === 'excused')?.count || 0,
        attendanceRate: Math.round(attendanceRate)
      }
    };

    if (format === 'pdf') {
      const pdfBuffer = await generateReports.generateAttendancePDF(reportData);
      
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=attendance-report-${startDate}-to-${endDate}.pdf`,
        'Content-Length': pdfBuffer.length
      });
      
      res.send(pdfBuffer);
    } else {
      res.status(200).json({
        success: true,
        report: reportData
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Generate financial report
exports.generateFinancialReport = async (req, res) => {
  try {
    const { startDate, endDate, format = 'pdf' } = req.body;

    // Get payments in period
    const payments = await Payment.find({
      status: 'completed',
      paymentDate: { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      }
    })
    .populate('parent', 'firstName lastName')
    .populate('invoice')
    .sort({ paymentDate: 1 });

    // Get invoices in period
    const invoices = await Invoice.find({
      invoiceDate: { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      }
    })
    .populate('parent', 'firstName lastName')
    .populate('child', 'firstName lastName')
    .sort({ invoiceDate: 1 });

    // Calculate totals
    const totalRevenue = payments.reduce((sum, payment) => sum + payment.amount, 0);
    const totalInvoiced = invoices.reduce((sum, invoice) => sum + invoice.total, 0);
    const outstandingBalance = invoices
      .filter(inv => inv.status !== 'paid')
      .reduce((sum, invoice) => sum + invoice.balanceDue, 0);

    const reportData = {
      type: 'financial',
      title: 'Financial Report',
      period: `${startDate} to ${endDate}`,
      generatedAt: new Date(),
      data: {
        payments,
        invoices
      },
      statistics: {
        totalRevenue,
        totalInvoiced,
        outstandingBalance,
        paymentCount: payments.length,
        invoiceCount: invoices.length,
        paidInvoices: invoices.filter(inv => inv.status === 'paid').length,
        pendingInvoices: invoices.filter(inv => inv.status === 'sent').length,
        overdueInvoices: invoices.filter(inv => inv.status === 'overdue').length
      }
    };

    if (format === 'pdf') {
      const pdfBuffer = await generateReports.generateFinancialPDF(reportData);
      
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=financial-report-${startDate}-to-${endDate}.pdf`,
        'Content-Length': pdfBuffer.length
      });
      
      res.send(pdfBuffer);
    } else {
      res.status(200).json({
        success: true,
        report: reportData
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Generate children progress report
exports.generateChildrenReport = async (req, res) => {
  try {
    const { room, format = 'pdf' } = req.body;

    let query = { status: 'active' };
    if (room) {
      query.room = room;
    }

    const children = await Child.find(query)
      .populate('parents.parent', 'firstName lastName')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .sort({ room: 1, firstName: 1 });

    // Get attendance data for each child
    const childrenWithStats = await Promise.all(
      children.map(async (child) => {
        const attendanceStats = await Attendance.aggregate([
          { $match: { child: child._id } },
          {
            $group: {
              _id: '$status',
              count: { $sum: 1 }
            }
          }
        ]);

        const activityCount = await Activity.countDocuments({
          'children.child': child._id,
          startTime: { $gte: new Date(new Date().getFullYear(), 0, 1) }
        });

        const presentCount = attendanceStats.find(stat => stat._id === 'present')?.count || 0;
        const totalAttendance = attendanceStats.reduce((sum, stat) => sum + stat.count, 0);
        const attendanceRate = totalAttendance > 0 ? Math.round((presentCount / totalAttendance) * 100) : 0;

        return {
          ...child.toObject(),
          statistics: {
            attendanceRate,
            activityCount,
            totalAttendance
          }
        };
      })
    );

    const reportData = {
      type: 'children',
      title: room ? `${room.charAt(0).toUpperCase() + room.slice(1)} Room Children Report` : 'Children Progress Report',
      generatedAt: new Date(),
      data: childrenWithStats,
      statistics: {
        totalChildren: children.length,
        byRoom: {
          infants: children.filter(c => c.room === 'infants').length,
          toddlers: children.filter(c => c.room === 'toddlers').length,
          preschool: children.filter(c => c.room === 'preschool').length
        }
      }
    };

    if (format === 'pdf') {
      const pdfBuffer = await generateReports.generateChildrenPDF(reportData);
      
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=children-report-${new Date().toISOString().split('T')[0]}.pdf`,
        'Content-Length': pdfBuffer.length
      });
      
      res.send(pdfBuffer);
    } else {
      res.status(200).json({
        success: true,
        report: reportData
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Generate employee performance report
exports.generateEmployeeReport = async (req, res) => {
  try {
    const { department, format = 'pdf' } = req.body;

    let query = { status: 'active' };
    if (department) {
      query.department = department;
    }

    const employees = await Employee.find(query)
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName room')
      .populate('performanceReviews.reviewer', 'firstName lastName')
      .sort({ department: 1, 'user.firstName': 1 });

    const employeesWithStats = await Promise.all(
      employees.map(async (employee) => {
        // Get activities conducted by employee
        const activityCount = await Activity.countDocuments({
          'assignedEmployees.employee': employee._id,
          startTime: { $gte: new Date(new Date().getFullYear(), 0, 1) }
        });

        // Get attendance records taken by employee
        const attendanceCount = await Attendance.countDocuments({
          recordedBy: employee.user._id,
          date: { $gte: new Date(new Date().getFullYear(), 0, 1) }
        });

        const averageRating = employee.performanceReviews.length > 0 
          ? employee.performanceReviews.reduce((sum, review) => sum + review.rating, 0) / employee.performanceReviews.length
          : 0;

        return {
          ...employee.toObject(),
          statistics: {
            activityCount,
            attendanceCount,
            assignedChildren: employee.assignedChildren.length,
            averageRating: Math.round(averageRating * 10) / 10,
            lastReview: employee.performanceReviews.length > 0 
              ? employee.performanceReviews[employee.performanceReviews.length - 1].reviewDate
              : null
          }
        };
      })
    );

    const reportData = {
      type: 'employee',
      title: 'Employee Performance Report',
      generatedAt: new Date(),
      data: employeesWithStats,
      statistics: {
        totalEmployees: employees.length,
        byDepartment: {
          infants: employees.filter(e => e.department === 'infants').length,
          toddlers: employees.filter(e => e.department === 'toddlers').length,
          preschool: employees.filter(e => e.department === 'preschool').length,
          administration: employees.filter(e => e.department === 'administration').length
        }
      }
    };

    if (format === 'pdf') {
      const pdfBuffer = await generateReports.generateEmployeePDF(reportData);
      
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=employee-report-${new Date().toISOString().split('T')[0]}.pdf`,
        'Content-Length': pdfBuffer.length
      });
      
      res.send(pdfBuffer);
    } else {
      res.status(200).json({
        success: true,
        report: reportData
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get dashboard statistics
exports.getDashboardStats = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Today's attendance
    const todayAttendance = await Attendance.find({
      date: { $gte: today, $lt: tomorrow }
    });
    
    const presentToday = todayAttendance.filter(a => a.status === 'present').length;
    const totalChildren = await Child.countDocuments({ status: 'active' });
    const attendanceRate = totalChildren > 0 ? Math.round((presentToday / totalChildren) * 100) : 0;

    // Recent statistics
    const totalEmployees = await Employee.countDocuments({ status: 'active' });
    const totalParents = await Parent.countDocuments({ status: 'active' });
    
    // Monthly revenue
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthlyRevenue = await Payment.aggregate([
      {
        $match: {
          status: 'completed',
          paymentDate: { $gte: monthStart, $lte: today }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);

    // Pending payments
    const pendingPayments = await Payment.countDocuments({ status: 'pending' });

    res.status(200).json({
      success: true,
      stats: {
        totalChildren,
        totalEmployees,
        totalParents,
        todayAttendance: attendanceRate,
        monthlyRevenue: monthlyRevenue[0]?.total || 0,
        pendingPayments
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get recent activities for dashboard
exports.getRecentActivities = async (req, res) => {
  try {
    const activities = await Activity.find()
      .populate('children.child', 'firstName lastName')
      .populate('assignedEmployees.employee', 'firstName lastName')
      .sort({ startTime: -1 })
      .limit(10);

    res.status(200).json({
      success: true,
      activities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};