const Invoice = require('../models/Invoice');
const Payment = require('../models/Payment');
const Parent = require('../models/Parent');
const Child = require('../models/Child');

// Get all invoices
exports.getInvoices = async (req, res) => {
  try {
    const { status, parentId, startDate, endDate } = req.query;
    
    let query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (parentId) {
      query.parent = parentId;
    }
    
    if (startDate && endDate) {
      query.invoiceDate = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }

    const invoices = await Invoice.find(query)
      .populate('parent', 'firstName lastName email phone')
      .populate('child', 'firstName lastName room')
      .populate('payments.payment')
      .sort({ invoiceDate: -1 });

    res.status(200).json({
      success: true,
      count: invoices.length,
      invoices
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get invoices by parent
exports.getInvoicesByParent = async (req, res) => {
  try {
    const invoices = await Invoice.find({ parent: req.params.parentId })
      .populate('child', 'firstName lastName room')
      .populate('payments.payment')
      .sort({ invoiceDate: -1 });

    res.status(200).json({
      success: true,
      count: invoices.length,
      invoices
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get invoice by ID
exports.getInvoice = async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id)
      .populate('parent', 'firstName lastName email phone address')
      .populate('child', 'firstName lastName room')
      .populate({
        path: 'payments.payment',
        populate: {
          path: 'processedBy',
          select: 'firstName lastName'
        }
      });

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    res.status(200).json({
      success: true,
      invoice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create invoice
exports.createInvoice = async (req, res) => {
  try {
    const invoice = await Invoice.create(req.body);

    const populatedInvoice = await Invoice.findById(invoice._id)
      .populate('parent', 'firstName lastName email phone')
      .populate('child', 'firstName lastName room');

    res.status(201).json({
      success: true,
      invoice: populatedInvoice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update invoice
exports.updateInvoice = async (req, res) => {
  try {
    let invoice = await Invoice.findById(req.params.id);

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    invoice = await Invoice.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    })
    .populate('parent', 'firstName lastName email phone')
    .populate('child', 'firstName lastName room')
    .populate('payments.payment');

    res.status(200).json({
      success: true,
      invoice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete invoice
exports.deleteInvoice = async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id);

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    // Delete associated payments
    await Payment.deleteMany({ invoice: req.params.id });

    await Invoice.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Invoice deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Send invoice
exports.sendInvoice = async (req, res) => {
  try {
    const invoice = await Invoice.findByIdAndUpdate(
      req.params.id,
      {
        status: 'sent',
        sentDate: new Date()
      },
      { new: true }
    )
    .populate('parent', 'firstName lastName email phone')
    .populate('child', 'firstName lastName room');

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    // Here you would typically send email to parent
    // await sendInvoiceEmail(invoice);

    res.status(200).json({
      success: true,
      message: 'Invoice sent successfully',
      invoice
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get all payments
exports.getPayments = async (req, res) => {
  try {
    const { status, parentId, startDate, endDate } = req.query;
    
    let query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (parentId) {
      query.parent = parentId;
    }
    
    if (startDate && endDate) {
      query.paymentDate = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }

    const payments = await Payment.find(query)
      .populate('parent', 'firstName lastName email phone')
      .populate('invoice')
      .populate('processedBy', 'firstName lastName')
      .sort({ paymentDate: -1 });

    res.status(200).json({
      success: true,
      count: payments.length,
      payments
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get payments by parent
exports.getPaymentsByParent = async (req, res) => {
  try {
    const payments = await Payment.find({ parent: req.params.parentId })
      .populate('invoice')
      .populate('processedBy', 'firstName lastName')
      .sort({ paymentDate: -1 });

    res.status(200).json({
      success: true,
      count: payments.length,
      payments
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create payment
exports.createPayment = async (req, res) => {
  try {
    const payment = await Payment.create({
      ...req.body,
      processedBy: req.user.id
    });

    // Update invoice if payment is associated with one
    if (req.body.invoice) {
      const invoice = await Invoice.findById(req.body.invoice);
      if (invoice) {
        const newAmountPaid = invoice.amountPaid + req.body.amount;
        const newBalanceDue = invoice.total - newAmountPaid;
        
        await Invoice.findByIdAndUpdate(
          req.body.invoice,
          {
            amountPaid: newAmountPaid,
            balanceDue: newBalanceDue,
            status: newBalanceDue <= 0 ? 'paid' : 'sent',
            paidDate: newBalanceDue <= 0 ? new Date() : invoice.paidDate,
            $push: {
              payments: {
                payment: payment._id,
                amount: req.body.amount,
                date: new Date()
              }
            }
          }
        );
      }
    }

    const populatedPayment = await Payment.findById(payment._id)
      .populate('parent', 'firstName lastName email phone')
      .populate('invoice')
      .populate('processedBy', 'firstName lastName');

    res.status(201).json({
      success: true,
      payment: populatedPayment
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update payment status
exports.updatePaymentStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const payment = await Payment.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    )
    .populate('parent', 'firstName lastName email phone')
    .populate('invoice')
    .populate('processedBy', 'firstName lastName');

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }

    res.status(200).json({
      success: true,
      payment
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get parent balance
exports.getParentBalance = async (req, res) => {
  try {
    const parent = await Parent.findById(req.params.parentId);

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    const invoices = await Invoice.find({ 
      parent: req.params.parentId,
      status: { $in: ['sent', 'overdue'] }
    });

    const balanceDue = invoices.reduce((total, invoice) => total + invoice.balanceDue, 0);

    res.status(200).json({
      success: true,
      balance: {
        balanceDue,
        pendingInvoices: invoices.length
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get financial overview
exports.getFinancialOverview = async (req, res) => {
  try {
    const { period = 'month' } = req.query;
    
    let startDate, endDate;
    const now = new Date();
    
    switch (period) {
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'quarter':
        const quarter = Math.floor(now.getMonth() / 3);
        startDate = new Date(now.getFullYear(), quarter * 3, 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    
    endDate = new Date();

    // Get total revenue
    const revenueData = await Payment.aggregate([
      {
        $match: {
          status: 'completed',
          paymentDate: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$amount' }
        }
      }
    ]);

    // Get pending payments
    const pendingData = await Payment.aggregate([
      {
        $match: {
          status: 'pending',
          paymentDate: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: null,
          totalPending: { $sum: '$amount' }
        }
      }
    ]);

    // Count pending invoices
    const pendingInvoices = await Invoice.countDocuments({
      status: { $in: ['sent', 'overdue'] }
    });

    const totalRevenue = revenueData[0]?.totalRevenue || 0;
    const totalPending = pendingData[0]?.totalPending || 0;

    res.status(200).json({
      success: true,
      overview: {
        totalRevenue,
        totalPending,
        pendingInvoices,
        // These would typically come from expense tracking
        totalExpenses: totalRevenue * 0.6, // Placeholder - 60% of revenue
        netProfit: totalRevenue * 0.4 // Placeholder - 40% profit margin
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};