const Activity = require('../models/Activity');
const Child = require('../models/Child');

// Get all activities
exports.getActivities = async (req, res) => {
  try {
    const { date, type, room } = req.query;
    
    let query = {};
    
    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      query.startTime = { $gte: startDate, $lt: endDate };
    }
    
    if (type) {
      query.type = type;
    }
    
    if (room) {
      query.room = room;
    }

    const activities = await Activity.find(query)
      .populate('children.child', 'firstName lastName room')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .populate('createdBy', 'firstName lastName')
      .sort({ startTime: 1 });

    res.status(200).json({
      success: true,
      count: activities.length,
      activities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get activities by date
exports.getActivitiesByDate = async (req, res) => {
  try {
    const date = new Date(req.params.date);
    const nextDate = new Date(date);
    nextDate.setDate(nextDate.getDate() + 1);

    const activities = await Activity.find({
      startTime: { $gte: date, $lt: nextDate }
    })
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position')
    .populate('createdBy', 'firstName lastName')
    .sort({ startTime: 1 });

    res.status(200).json({
      success: true,
      count: activities.length,
      activities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get activities by child
exports.getActivitiesByChild = async (req, res) => {
  try {
    const activities = await Activity.find({
      'children.child': req.params.childId
    })
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position')
    .populate('createdBy', 'firstName lastName')
    .sort({ startTime: -1 });

    res.status(200).json({
      success: true,
      count: activities.length,
      activities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get activity by ID
exports.getActivity = async (req, res) => {
  try {
    const activity = await Activity.findById(req.params.id)
      .populate('children.child', 'firstName lastName room age')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .populate('createdBy', 'firstName lastName');

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    res.status(200).json({
      success: true,
      activity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create activity
exports.createActivity = async (req, res) => {
  try {
    const activity = await Activity.create({
      ...req.body,
      createdBy: req.user.id
    });

    const populatedActivity = await Activity.findById(activity._id)
      .populate('children.child', 'firstName lastName room')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .populate('createdBy', 'firstName lastName');

    res.status(201).json({
      success: true,
      activity: populatedActivity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update activity
exports.updateActivity = async (req, res) => {
  try {
    let activity = await Activity.findById(req.params.id);

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    activity = await Activity.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    })
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position')
    .populate('createdBy', 'firstName lastName');

    res.status(200).json({
      success: true,
      activity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete activity
exports.deleteActivity = async (req, res) => {
  try {
    const activity = await Activity.findById(req.params.id);

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    await Activity.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Activity deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Add child to activity
exports.addChildToActivity = async (req, res) => {
  try {
    const { childId, participation } = req.body;

    const activity = await Activity.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          children: {
            child: childId,
            participation: participation || 'good'
          }
        }
      },
      { new: true }
    )
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position');

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    res.status(200).json({
      success: true,
      activity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Remove child from activity
exports.removeChildFromActivity = async (req, res) => {
  try {
    const activity = await Activity.findByIdAndUpdate(
      req.params.id,
      {
        $pull: {
          children: { child: req.params.childId }
        }
      },
      { new: true }
    )
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position');

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    res.status(200).json({
      success: true,
      activity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update activity status
exports.updateActivityStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const activity = await Activity.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    )
    .populate('children.child', 'firstName lastName room')
    .populate('assignedEmployees.employee', 'firstName lastName position');

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: 'Activity not found'
      });
    }

    res.status(200).json({
      success: true,
      activity
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};