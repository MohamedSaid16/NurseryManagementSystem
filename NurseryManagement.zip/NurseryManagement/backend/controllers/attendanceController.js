const Attendance = require('../models/Attendance');
const Child = require('../models/Child');

// Get all attendance records
exports.getAttendance = async (req, res) => {
  try {
    const { date, childId, status } = req.query;
    
    let query = {};
    
    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      query.date = { $gte: startDate, $lt: endDate };
    }
    
    if (childId) {
      query.child = childId;
    }
    
    if (status) {
      query.status = status;
    }

    const attendance = await Attendance.find(query)
      .populate('child', 'firstName lastName room')
      .populate('recordedBy', 'firstName lastName')
      .populate('checkIn.recordedBy', 'firstName lastName')
      .populate('checkOut.recordedBy', 'firstName lastName')
      .sort({ date: -1, 'child.firstName': 1 });

    res.status(200).json({
      success: true,
      count: attendance.length,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get attendance by date
exports.getAttendanceByDate = async (req, res) => {
  try {
    const date = new Date(req.params.date);
    const nextDate = new Date(date);
    nextDate.setDate(nextDate.getDate() + 1);

    const attendance = await Attendance.find({
      date: { $gte: date, $lt: nextDate }
    })
    .populate('child', 'firstName lastName room age')
    .populate('recordedBy', 'firstName lastName')
    .sort({ 'child.firstName': 1 });

    res.status(200).json({
      success: true,
      count: attendance.length,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get today's attendance
exports.getTodayAttendance = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const attendance = await Attendance.find({
      date: { $gte: today, $lt: tomorrow }
    })
    .populate('child', 'firstName lastName room age')
    .populate('recordedBy', 'firstName lastName')
    .sort({ 'child.firstName': 1 });

    res.status(200).json({
      success: true,
      count: attendance.length,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get child attendance
exports.getChildAttendance = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    let query = { child: req.params.childId };
    
    if (startDate && endDate) {
      query.date = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }

    const attendance = await Attendance.find(query)
      .populate('recordedBy', 'firstName lastName')
      .sort({ date: -1 });

    res.status(200).json({
      success: true,
      count: attendance.length,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create attendance record
exports.createAttendance = async (req, res) => {
  try {
    const { child, date, status, notes, absenceReason } = req.body;

    // Check if attendance already exists for this child and date
    const existingAttendance = await Attendance.findOne({
      child,
      date: new Date(date)
    });

    if (existingAttendance) {
      return res.status(400).json({
        success: false,
        message: 'Attendance already recorded for this child on this date'
      });
    }

    const attendance = await Attendance.create({
      child,
      date: new Date(date),
      status,
      recordedBy: req.user.id,
      notes,
      absenceReason
    });

    const populatedAttendance = await Attendance.findById(attendance._id)
      .populate('child', 'firstName lastName room')
      .populate('recordedBy', 'firstName lastName');

    res.status(201).json({
      success: true,
      attendance: populatedAttendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update attendance record
exports.updateAttendance = async (req, res) => {
  try {
    let attendance = await Attendance.findById(req.params.id);

    if (!attendance) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    attendance = await Attendance.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    })
    .populate('child', 'firstName lastName room')
    .populate('recordedBy', 'firstName lastName')
    .populate('checkIn.recordedBy', 'firstName lastName')
    .populate('checkOut.recordedBy', 'firstName lastName');

    res.status(200).json({
      success: true,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Check in child
exports.checkIn = async (req, res) => {
  try {
    const { time, notes } = req.body;

    const attendance = await Attendance.findByIdAndUpdate(
      req.params.id,
      {
        status: 'present',
        checkIn: {
          time,
          recordedBy: req.user.id,
          notes
        }
      },
      { new: true }
    )
    .populate('child', 'firstName lastName room')
    .populate('checkIn.recordedBy', 'firstName lastName');

    if (!attendance) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    res.status(200).json({
      success: true,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Check out child
exports.checkOut = async (req, res) => {
  try {
    const { time, notes } = req.body;

    const attendance = await Attendance.findByIdAndUpdate(
      req.params.id,
      {
        checkOut: {
          time,
          recordedBy: req.user.id,
          notes
        }
      },
      { new: true }
    )
    .populate('child', 'firstName lastName room')
    .populate('checkOut.recordedBy', 'firstName lastName');

    if (!attendance) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    res.status(200).json({
      success: true,
      attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get attendance statistics
exports.getAttendanceStats = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    let dateQuery = {};
    if (startDate && endDate) {
      dateQuery.date = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }

    const stats = await Attendance.aggregate([
      { $match: dateQuery },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const totalRecords = stats.reduce((sum, stat) => sum + stat.count, 0);
    const presentCount = stats.find(stat => stat._id === 'present')?.count || 0;
    const attendanceRate = totalRecords > 0 ? (presentCount / totalRecords) * 100 : 0;

    res.status(200).json({
      success: true,
      stats: {
        total: totalRecords,
        present: presentCount,
        absent: stats.find(stat => stat._id === 'absent')?.count || 0,
        late: stats.find(stat => stat._id === 'late')?.count || 0,
        excused: stats.find(stat => stat._id === 'excused')?.count || 0,
        attendanceRate: Math.round(attendanceRate)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};