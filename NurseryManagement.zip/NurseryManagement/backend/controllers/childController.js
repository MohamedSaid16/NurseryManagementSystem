const Child = require('../models/Child');
const Parent = require('../models/Parent');
const Attendance = require('../models/Attendance');
const Activity = require('../models/Activity');

// Get all children
exports.getChildren = async (req, res) => {
  try {
    const children = await Child.find()
      .populate('parents.parent', 'firstName lastName email phone')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .sort({ firstName: 1 });

    res.status(200).json({
      success: true,
      count: children.length,
      children
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get child by ID
exports.getChild = async (req, res) => {
  try {
    const child = await Child.findById(req.params.id)
      .populate('parents.parent', 'firstName lastName email phone')
      .populate('assignedEmployees.employee', 'firstName lastName position')
      .populate('notes.addedBy', 'firstName lastName');

    if (!child) {
      return res.status(404).json({
        success: false,
        message: 'Child not found'
      });
    }

    res.status(200).json({
      success: true,
      child
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create new child
exports.createChild = async (req, res) => {
  try {
    const child = await Child.create(req.body);

    // If parents are specified, update parent records
    if (req.body.parents && req.body.parents.length > 0) {
      for (let parentData of req.body.parents) {
        await Parent.findByIdAndUpdate(
          parentData.parent,
          { $push: { children: { child: child._id, relationship: parentData.relationship } } },
          { new: true }
        );
      }
    }

    const populatedChild = await Child.findById(child._id)
      .populate('parents.parent', 'firstName lastName email phone')
      .populate('assignedEmployees.employee', 'firstName lastName position');

    res.status(201).json({
      success: true,
      child: populatedChild
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update child
exports.updateChild = async (req, res) => {
  try {
    let child = await Child.findById(req.params.id);

    if (!child) {
      return res.status(404).json({
        success: false,
        message: 'Child not found'
      });
    }

    child = await Child.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('parents.parent', 'firstName lastName email phone')
      .populate('assignedEmployees.employee', 'firstName lastName position');

    res.status(200).json({
      success: true,
      child
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete child
exports.deleteChild = async (req, res) => {
  try {
    const child = await Child.findById(req.params.id);

    if (!child) {
      return res.status(404).json({
        success: false,
        message: 'Child not found'
      });
    }

    // Remove child from parent records
    await Parent.updateMany(
      { 'children.child': req.params.id },
      { $pull: { children: { child: req.params.id } } }
    );

    await Child.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Child deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get children by parent
exports.getChildrenByParent = async (req, res) => {
  try {
    const parent = await Parent.findOne({ user: req.params.parentId })
      .populate({
        path: 'children.child',
        populate: [
          { path: 'assignedEmployees.employee', select: 'firstName lastName position' },
          { path: 'parents.parent', select: 'firstName lastName' }
        ]
      });

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    res.status(200).json({
      success: true,
      children: parent.children.map(item => item.child)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get children by employee
exports.getChildrenByEmployee = async (req, res) => {
  try {
    const children = await Child.find({ 
      'assignedEmployees.employee': req.params.employeeId 
    })
    .populate('parents.parent', 'firstName lastName email phone')
    .populate('assignedEmployees.employee', 'firstName lastName position')
    .sort({ firstName: 1 });

    res.status(200).json({
      success: true,
      count: children.length,
      children
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Add note to child
exports.addNote = async (req, res) => {
  try {
    const { note } = req.body;

    const child = await Child.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          notes: {
            note,
            addedBy: req.user.id
          }
        }
      },
      { new: true }
    ).populate('notes.addedBy', 'firstName lastName');

    if (!child) {
      return res.status(404).json({
        success: false,
        message: 'Child not found'
      });
    }

    res.status(200).json({
      success: true,
      child
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get child progress
exports.getChildProgress = async (req, res) => {
  try {
    const childId = req.params.id;
    
    // Get attendance stats
    const attendanceStats = await Attendance.aggregate([
      { $match: { child: mongoose.Types.ObjectId(childId) } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    // Get activity count
    const activityCount = await Activity.countDocuments({
      'children.child': childId,
      startTime: { $gte: new Date(new Date().getFullYear(), 0, 1) } // This year
    });

    // Get milestone count (you might want to create a separate milestones model)
    const milestoneCount = 0; // Placeholder

    const presentCount = attendanceStats.find(stat => stat._id === 'present')?.count || 0;
    const totalAttendance = attendanceStats.reduce((sum, stat) => sum + stat.count, 0);
    const attendancePercentage = totalAttendance > 0 ? Math.round((presentCount / totalAttendance) * 100) : 0;

    res.status(200).json({
      success: true,
      progress: {
        attendance: attendancePercentage,
        activities: activityCount,
        milestones: milestoneCount
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get recent activities for child
exports.getRecentActivities = async (req, res) => {
  try {
    const activities = await Activity.find({
      'children.child': req.params.id
    })
    .populate('assignedEmployees.employee', 'firstName lastName')
    .sort({ startTime: -1 })
    .limit(10);

    res.status(200).json({
      success: true,
      activities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};