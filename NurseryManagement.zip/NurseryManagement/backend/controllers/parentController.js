const Parent = require('../models/Parent');
const User = require('../models/User');
const Child = require('../models/Child');
const Invoice = require('../models/Invoice');

// Get all parents
exports.getParents = async (req, res) => {
  try {
    const parents = await Parent.find()
      .populate('user', 'firstName lastName email phone')
      .populate('children.child', 'firstName lastName age room')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: parents.length,
      parents
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get parent by ID
exports.getParent = async (req, res) => {
  try {
    const parent = await Parent.findById(req.params.id)
      .populate('user', 'firstName lastName email phone')
      .populate({
        path: 'children.child',
        populate: {
          path: 'assignedEmployees.employee',
          select: 'firstName lastName position'
        }
      });

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    res.status(200).json({
      success: true,
      parent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get parent by user ID
exports.getParentByUser = async (req, res) => {
  try {
    const parent = await Parent.findOne({ user: req.params.userId })
      .populate('user', 'firstName lastName email phone')
      .populate({
        path: 'children.child',
        populate: [
          { path: 'assignedEmployees.employee', select: 'firstName lastName position' },
          { path: 'parents.parent', select: 'firstName lastName' }
        ]
      });

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    res.status(200).json({
      success: true,
      parent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create parent
exports.createParent = async (req, res) => {
  try {
    const parent = await Parent.create(req.body);

    const populatedParent = await Parent.findById(parent._id)
      .populate('user', 'firstName lastName email phone')
      .populate('children.child', 'firstName lastName age room');

    res.status(201).json({
      success: true,
      parent: populatedParent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update parent
exports.updateParent = async (req, res) => {
  try {
    let parent = await Parent.findById(req.params.id);

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    parent = await Parent.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('user', 'firstName lastName email phone')
      .populate('children.child', 'firstName lastName age room');

    res.status(200).json({
      success: true,
      parent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete parent
exports.deleteParent = async (req, res) => {
  try {
    const parent = await Parent.findById(req.params.id);

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    // Remove parent from child records
    await Child.updateMany(
      { 'parents.parent': req.params.id },
      { $pull: { parents: { parent: req.params.id } } }
    );

    await Parent.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Parent deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Add child to parent
exports.addChild = async (req, res) => {
  try {
    const { childId, relationship } = req.body;

    const parent = await Parent.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          children: {
            child: childId,
            relationship
          }
        }
      },
      { new: true }
    ).populate('children.child', 'firstName lastName age room');

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    // Also add parent to child record
    await Child.findByIdAndUpdate(childId, {
      $push: {
        parents: {
          parent: req.params.id,
          relationship
        }
      }
    });

    res.status(200).json({
      success: true,
      parent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get parent balance
exports.getParentBalance = async (req, res) => {
  try {
    const parent = await Parent.findById(req.params.id);

    if (!parent) {
      return res.status(404).json({
        success: false,
        message: 'Parent not found'
      });
    }

    // Calculate total balance due from invoices
    const invoices = await Invoice.find({ 
      parent: req.params.id,
      status: { $in: ['sent', 'overdue'] }
    });

    const balanceDue = invoices.reduce((total, invoice) => total + invoice.balanceDue, 0);

    res.status(200).json({
      success: true,
      balance: {
        balanceDue,
        pendingInvoices: invoices.length
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};