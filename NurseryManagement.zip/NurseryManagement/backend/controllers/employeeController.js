const Employee = require('../models/Employee');
const User = require('../models/User');
const Child = require('../models/Child');

// Get all employees
exports.getEmployees = async (req, res) => {
  try {
    const employees = await Employee.find()
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: employees.length,
      employees
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get employee by ID
exports.getEmployee = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id)
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room')
      .populate('performanceReviews.reviewer', 'firstName lastName');

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    res.status(200).json({
      success: true,
      employee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get employee by user ID
exports.getEmployeeByUser = async (req, res) => {
  try {
    const employee = await Employee.findOne({ user: req.params.userId })
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room');

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    res.status(200).json({
      success: true,
      employee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Create employee
exports.createEmployee = async (req, res) => {
  try {
    const employee = await Employee.create(req.body);

    const populatedEmployee = await Employee.findById(employee._id)
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room');

    res.status(201).json({
      success: true,
      employee: populatedEmployee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update employee
exports.updateEmployee = async (req, res) => {
  try {
    let employee = await Employee.findById(req.params.id);

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    employee = await Employee.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room');

    res.status(200).json({
      success: true,
      employee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete employee
exports.deleteEmployee = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    // Remove employee from child records
    await Child.updateMany(
      { 'assignedEmployees.employee': req.params.id },
      { $pull: { assignedEmployees: { employee: req.params.id } } }
    );

    await Employee.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Employee deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Assign child to employee
exports.assignChild = async (req, res) => {
  try {
    const { childId, role } = req.body;

    const employee = await Employee.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          assignedChildren: {
            child: childId,
            role
          }
        }
      },
      { new: true }
    ).populate('assignedChildren.child', 'firstName lastName age room');

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    // Also add employee to child record
    await Child.findByIdAndUpdate(childId, {
      $push: {
        assignedEmployees: {
          employee: req.params.id,
          role
        }
      }
    });

    res.status(200).json({
      success: true,
      employee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get employees by role
exports.getEmployeesByRole = async (req, res) => {
  try {
    const employees = await Employee.find({ position: req.params.role })
      .populate('user', 'firstName lastName email phone')
      .populate('assignedChildren.child', 'firstName lastName age room')
      .sort({ firstName: 1 });

    res.status(200).json({
      success: true,
      count: employees.length,
      employees
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Add performance review
exports.addPerformanceReview = async (req, res) => {
  try {
    const { rating, comments, goals } = req.body;

    const employee = await Employee.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          performanceReviews: {
            reviewDate: new Date(),
            reviewer: req.user.id,
            rating,
            comments,
            goals
          }
        }
      },
      { new: true }
    ).populate('performanceReviews.reviewer', 'firstName lastName');

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }

    res.status(200).json({
      success: true,
      employee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};