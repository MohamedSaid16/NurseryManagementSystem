const Child = require('../models/Child');
const Employee = require('../models/Employee');
const Attendance = require('../models/Attendance');
const Activity = require('../models/Activity');
const Invoice = require('../models/Invoice');
const User = require('../models/User');

// @desc    Get admin dashboard statistics
// @route   GET /api/dashboard/admin
// @access  Private/Admin
exports.getAdminStats = async (req, res) => {
  try {
    console.log('📊 Fetching admin dashboard stats...');
    
    // Get counts from database
    const [
      totalChildren,
      totalEmployees,
      totalParents,
      todayAttendance,
      pendingInvoices,
      recentActivities
    ] = await Promise.all([
      // Total children count
      Child.countDocuments({ isActive: true }),
      
      // Total employees count
      Employee.countDocuments({ isActive: true }),
      
      // Total parents count
      User.countDocuments({ role: 'parent', isActive: true }),
      
      // Today's attendance
      Attendance.aggregate([
        {
          $match: {
            date: {
              $gte: new Date(new Date().setHours(0, 0, 0, 0)),
              $lt: new Date(new Date().setHours(23, 59, 59, 999))
            }
          }
        },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 }
          }
        }
      ]),
      
      // Pending invoices
      Invoice.countDocuments({ status: { $in: ['sent', 'overdue'] } }),
      
      // Recent activities (last 7 days)
      Activity.find({
        startTime: {
          $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        }
      })
      .populate('children.child', 'firstName lastName')
      .populate('createdBy', 'firstName lastName')
      .sort({ startTime: -1 })
      .limit(5)
    ]);

    // Calculate attendance stats
    const presentCount = todayAttendance.find(a => a._id === 'present')?.count || 0;
    const totalToday = todayAttendance.reduce((sum, a) => sum + a.count, 0);
    const attendanceRate = totalToday > 0 ? Math.round((presentCount / totalToday) * 100) : 0;

    res.status(200).json({
      success: true,
      data: {
        totalChildren,
        totalEmployees,
        totalParents,
        todaysAttendance: `${presentCount}/${totalToday}`,
        attendanceRate: `${attendanceRate}%`,
        pendingPayments: pendingInvoices,
        recentActivities: recentActivities.map(activity => ({
          id: activity._id,
          title: activity.title,
          type: activity.type,
          childrenCount: activity.children.length,
          room: activity.room,
          time: activity.startTime,
          createdBy: activity.createdBy ? 
            `${activity.createdBy.firstName} ${activity.createdBy.lastName}` : 'Unknown'
        }))
      }
    });

  } catch (error) {
    console.error('❌ Admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching dashboard statistics',
      error: error.message
    });
  }
};

// @desc    Get employee dashboard statistics
// @route   GET /api/dashboard/employee
// @access  Private/Employee
exports.getEmployeeStats = async (req, res) => {
  try {
    const employeeId = req.user.id;
    console.log(`📊 Fetching employee dashboard stats for: ${employeeId}`);
    
    const today = new Date();
    const startOfToday = new Date(today.setHours(0, 0, 0, 0));
    const endOfToday = new Date(today.setHours(23, 59, 59, 999));

    const [
      myChildren,
      todaysActivities,
      todaysAttendance,
      upcomingActivities
    ] = await Promise.all([
      // Children in employee's room
      Child.countDocuments({ 
        room: req.user.assignedRoom, 
        isActive: true 
      }),
      
      // Today's activities count
      Activity.countDocuments({
        startTime: { $gte: startOfToday, $lt: endOfToday }
      }),
      
      // Today's attendance for employee's room
      Attendance.aggregate([
        {
          $match: {
            date: { $gte: startOfToday, $lt: endOfToday }
          }
        },
        {
          $lookup: {
            from: 'children',
            localField: 'childId',
            foreignField: '_id',
            as: 'child'
          }
        },
        {
          $unwind: '$child'
        },
        {
          $match: {
            'child.room': req.user.assignedRoom
          }
        },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 }
          }
        }
      ]),
      
      // Today's schedule
      Activity.find({
        startTime: { $gte: startOfToday, $lt: endOfToday }
      })
      .populate('children.child', 'firstName lastName')
      .sort({ startTime: 1 })
      .limit(10)
    ]);

    const presentCount = todaysAttendance.find(a => a._id === 'present')?.count || 0;
    const totalChildrenInRoom = myChildren;

    res.status(200).json({
      success: true,
      data: {
        myChildren: totalChildrenInRoom,
        todaysActivities,
        attendanceToday: `${presentCount}/${totalChildrenInRoom}`,
        schedule: upcomingActivities.map(activity => ({
          time: activity.startTime,
          title: activity.title,
          type: activity.type,
          room: activity.room,
          childrenCount: activity.children.length
        }))
      }
    });

  } catch (error) {
    console.error('❌ Employee dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching employee dashboard',
      error: error.message
    });
  }
};

// @desc    Get parent dashboard statistics
// @route   GET /api/dashboard/parent
// @access  Private/Parent
exports.getParentStats = async (req, res) => {
  try {
    const parentId = req.user.id;
    console.log(`📊 Fetching parent dashboard stats for: ${parentId}`);
    
    const [
      myChildren,
      unreadMessages,
      pendingInvoices,
      childrenList
    ] = await Promise.all([
      // Count of parent's children
      Child.countDocuments({ 
        'parents.parent': parentId, 
        isActive: true 
      }),
      
      // Unread messages count (you'll need a Message model)
      0, // Placeholder for now
      
      // Pending invoices for parent
      Invoice.countDocuments({ 
        parentId: parentId, 
        status: { $in: ['sent', 'overdue'] } 
      }),
      
      // Parent's children list
      Child.find({ 
        'parents.parent': parentId, 
        isActive: true 
      })
      .select('firstName lastName room dateOfBirth')
      .populate('parents.parent', 'firstName lastName')
    ]);

    // Get today's attendance for each child
    const today = new Date();
    const startOfToday = new Date(today.setHours(0, 0, 0, 0));
    const endOfToday = new Date(today.setHours(23, 59, 59, 999));

    const childrenWithAttendance = await Promise.all(
      childrenList.map(async (child) => {
        const todayAttendance = await Attendance.findOne({
          childId: child._id,
          date: { $gte: startOfToday, $lt: endOfToday }
        });
        
        return {
          id: child._id,
          name: `${child.firstName} ${child.lastName}`,
          room: child.room,
          status: todayAttendance ? todayAttendance.status : 'unknown',
          checkIn: todayAttendance?.checkIn || null,
          checkOut: todayAttendance?.checkOut || null
        };
      })
    );

    res.status(200).json({
      success: true,
      data: {
        myChildren,
        unreadMessages,
        pendingPayments: pendingInvoices,
        children: childrenWithAttendance
      }
    });

  } catch (error) {
    console.error('❌ Parent dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching parent dashboard',
      error: error.message
    });
  }
};

// @desc    Get recent activities
// @route   GET /api/dashboard/recent-activities
// @access  Private
exports.getRecentActivities = async (req, res) => {
  try {
    const recentActivities = await Activity.find()
      .populate('children.child', 'firstName lastName')
      .populate('createdBy', 'firstName lastName')
      .sort({ createdAt: -1 })
      .limit(10);

    res.status(200).json({
      success: true,
      data: recentActivities.map(activity => ({
        id: activity._id,
        title: activity.title,
        type: activity.type,
        description: activity.description,
        room: activity.room,
        childrenCount: activity.children.length,
        startTime: activity.startTime,
        endTime: activity.endTime,
        createdBy: activity.createdBy ? 
          `${activity.createdBy.firstName} ${activity.createdBy.lastName}` : 'Unknown',
        createdAt: activity.createdAt
      }))
    });

  } catch (error) {
    console.error('❌ Recent activities error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching recent activities',
      error: error.message
    });
  }
};

// @desc    Get attendance summary
// @route   GET /api/dashboard/attendance-summary
// @access  Private
exports.getAttendanceSummary = async (req, res) => {
  try {
    const { period = 'today' } = req.query; // today, week, month
    
    let startDate, endDate;
    const now = new Date();
    
    switch (period) {
      case 'today':
        startDate = new Date(now.setHours(0, 0, 0, 0));
        endDate = new Date(now.setHours(23, 59, 59, 999));
        break;
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        endDate = new Date();
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      default:
        startDate = new Date(now.setHours(0, 0, 0, 0));
        endDate = new Date(now.setHours(23, 59, 59, 999));
    }

    const attendanceSummary = await Attendance.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const present = attendanceSummary.find(a => a._id === 'present')?.count || 0;
    const absent = attendanceSummary.find(a => a._id === 'absent')?.count || 0;
    const sick = attendanceSummary.find(a => a._id === 'sick')?.count || 0;
    const total = present + absent + sick;

    res.status(200).json({
      success: true,
      data: {
        present,
        absent,
        sick,
        total,
        attendanceRate: total > 0 ? Math.round((present / total) * 100) : 0
      }
    });

  } catch (error) {
    console.error('❌ Attendance summary error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching attendance summary',
      error: error.message
    });
  }
};