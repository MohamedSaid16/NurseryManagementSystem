const PDFDocument = require('pdfkit');

// Generate attendance report PDF
exports.generateAttendancePDF = async (reportData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Add content to PDF
      doc.fontSize(20).text(reportData.title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Period: ${reportData.period}`, { align: 'center' });
      doc.text(`Generated: ${reportData.generatedAt.toLocaleDateString()}`, { align: 'center' });
      doc.moveDown();

      // Add statistics
      doc.fontSize(14).text('Summary Statistics:');
      doc.fontSize(12);
      doc.text(`Total Records: ${reportData.statistics.total}`);
      doc.text(`Present: ${reportData.statistics.present}`);
      doc.text(`Absent: ${reportData.statistics.absent}`);
      doc.text(`Late: ${reportData.statistics.late}`);
      doc.text(`Excused: ${reportData.statistics.excused}`);
      doc.text(`Attendance Rate: ${reportData.statistics.attendanceRate}%`);
      doc.moveDown();

      // Add attendance details
      doc.fontSize(14).text('Attendance Details:');
      doc.moveDown();

      let yPosition = doc.y;
      reportData.data.forEach((record, index) => {
        if (yPosition > 700) { // New page if near bottom
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(10);
        doc.text(`${index + 1}. ${record.child.firstName} ${record.child.lastName} - ${record.room} Room`);
        doc.text(`   Date: ${new Date(record.date).toLocaleDateString()}`);
        doc.text(`   Status: ${record.status}`);
        if (record.checkIn) {
          doc.text(`   Check In: ${record.checkIn.time}`);
        }
        if (record.checkOut) {
          doc.text(`   Check Out: ${record.checkOut.time}`);
        }
        doc.moveDown(0.5);
        yPosition = doc.y;
      });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

// Generate financial report PDF
exports.generateFinancialPDF = async (reportData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Add content to PDF
      doc.fontSize(20).text(reportData.title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Period: ${reportData.period}`, { align: 'center' });
      doc.text(`Generated: ${reportData.generatedAt.toLocaleDateString()}`, { align: 'center' });
      doc.moveDown();

      // Add financial summary
      doc.fontSize(14).text('Financial Summary:');
      doc.fontSize(12);
      doc.text(`Total Revenue: $${reportData.statistics.totalRevenue.toFixed(2)}`);
      doc.text(`Total Invoiced: $${reportData.statistics.totalInvoiced.toFixed(2)}`);
      doc.text(`Outstanding Balance: $${reportData.statistics.outstandingBalance.toFixed(2)}`);
      doc.text(`Payment Count: ${reportData.statistics.paymentCount}`);
      doc.text(`Invoice Count: ${reportData.statistics.invoiceCount}`);
      doc.moveDown();

      // Add payment summary
      doc.fontSize(14).text('Recent Payments:');
      doc.moveDown();

      let yPosition = doc.y;
      reportData.data.payments.slice(0, 20).forEach((payment, index) => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(10);
        doc.text(`${index + 1}. ${payment.parent.firstName} ${payment.parent.lastName}`);
        doc.text(`   Amount: $${payment.amount.toFixed(2)}`);
        doc.text(`   Date: ${new Date(payment.paymentDate).toLocaleDateString()}`);
        doc.text(`   Method: ${payment.paymentMethod}`);
        doc.moveDown(0.5);
        yPosition = doc.y;
      });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

// Generate children report PDF
exports.generateChildrenPDF = async (reportData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Add content to PDF
      doc.fontSize(20).text(reportData.title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Generated: ${reportData.generatedAt.toLocaleDateString()}`, { align: 'center' });
      doc.moveDown();

      // Add summary
      doc.fontSize(14).text('Summary:');
      doc.fontSize(12);
      doc.text(`Total Children: ${reportData.statistics.totalChildren}`);
      doc.text(`Infants Room: ${reportData.statistics.byRoom.infants}`);
      doc.text(`Toddlers Room: ${reportData.statistics.byRoom.toddlers}`);
      doc.text(`Preschool Room: ${reportData.statistics.byRoom.preschool}`);
      doc.moveDown();

      // Add children details
      doc.fontSize(14).text('Children Details:');
      doc.moveDown();

      let yPosition = doc.y;
      reportData.data.forEach((child, index) => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(10);
        doc.text(`${index + 1}. ${child.firstName} ${child.lastName}`);
        doc.text(`   Room: ${child.room}`);
        doc.text(`   Age: ${child.age} years`);
        doc.text(`   Attendance Rate: ${child.statistics.attendanceRate}%`);
        doc.text(`   Activities: ${child.statistics.activityCount}`);
        doc.moveDown(0.5);
        yPosition = doc.y;
      });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

// Generate employee report PDF
exports.generateEmployeePDF = async (reportData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Add content to PDF
      doc.fontSize(20).text(reportData.title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Generated: ${reportData.generatedAt.toLocaleDateString()}`, { align: 'center' });
      doc.moveDown();

      // Add summary
      doc.fontSize(14).text('Summary:');
      doc.fontSize(12);
      doc.text(`Total Employees: ${reportData.statistics.totalEmployees}`);
      doc.text(`Infants Department: ${reportData.statistics.byDepartment.infants}`);
      doc.text(`Toddlers Department: ${reportData.statistics.byDepartment.toddlers}`);
      doc.text(`Preschool Department: ${reportData.statistics.byDepartment.preschool}`);
      doc.moveDown();

      // Add employee details
      doc.fontSize(14).text('Employee Details:');
      doc.moveDown();

      let yPosition = doc.y;
      reportData.data.forEach((employee, index) => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(10);
        doc.text(`${index + 1}. ${employee.user.firstName} ${employee.user.lastName}`);
        doc.text(`   Department: ${employee.department}`);
        doc.text(`   Position: ${employee.position}`);
        doc.text(`   Activities: ${employee.statistics.activityCount}`);
        doc.text(`   Attendance Records: ${employee.statistics.attendanceCount}`);
        doc.text(`   Assigned Children: ${employee.statistics.assignedChildren}`);
        doc.text(`   Average Rating: ${employee.statistics.averageRating}/5`);
        doc.moveDown(0.5);
        yPosition = doc.y;
      });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};