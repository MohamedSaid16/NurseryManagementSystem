const PDFDocument = require('pdfkit');
const moment = require('moment');

// Generate invoice PDF
exports.generateInvoicePDF = async (invoice) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 50 });
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Header
      generateHeader(doc);
      
      // Customer Information
      generateCustomerInformation(doc, invoice);
      
      // Invoice Information
      generateInvoiceInformation(doc, invoice);
      
      // Invoice Items
      generateInvoiceTable(doc, invoice);
      
      // Footer
      generateFooter(doc);

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

function generateHeader(doc) {
  doc
    .fillColor('#444444')
    .fontSize(20)
    .text('Little Stars Nursery', 50, 57)
    .fontSize(10)
    .text('123 Education Street', 200, 65, { align: 'right' })
    .text('Learning City, LC 12345', 200, 80, { align: 'right' })
    .moveDown();
}

function generateCustomerInformation(doc, invoice) {
  doc
    .fillColor('#444444')
    .fontSize(20)
    .text('Invoice', 50, 160);

  generateHr(doc, 185);

  const customerInformationTop = 200;

  doc
    .fontSize(10)
    .text('Invoice Number:', 50, customerInformationTop)
    .font('Helvetica-Bold')
    .text(invoice.invoiceNumber, 150, customerInformationTop)
    .font('Helvetica')
    .text('Invoice Date:', 50, customerInformationTop + 15)
    .text(formatDate(new Date(invoice.invoiceDate)), 150, customerInformationTop + 15)
    .text('Balance Due:', 50, customerInformationTop + 30)
    .font('Helvetica-Bold')
    .text(formatCurrency(invoice.balanceDue), 150, customerInformationTop + 30)

    .font('Helvetica')
    .text(invoice.parent.firstName + ' ' + invoice.parent.lastName, 300, customerInformationTop)
    .text(invoice.parent.email, 300, customerInformationTop + 15)
    .text(invoice.parent.phone, 300, customerInformationTop + 30)
    .moveDown();

  generateHr(doc, 252);
}

function generateInvoiceInformation(doc, invoice) {
  doc
    .fontSize(10)
    .text(`Child: ${invoice.child.firstName} ${invoice.child.lastName}`, 50, 270)
    .text(`Room: ${invoice.child.room}`, 50, 285)
    .text(`Due Date: ${formatDate(new Date(invoice.dueDate))}`, 50, 300)
    .moveDown();
}

function generateInvoiceTable(doc, invoice) {
  let i;
  const invoiceTableTop = 330;

  doc.font('Helvetica-Bold');
  generateTableRow(
    doc,
    invoiceTableTop,
    'Item',
    'Description',
    'Unit Cost',
    'Quantity',
    'Line Total'
  );
  generateHr(doc, invoiceTableTop + 20);
  doc.font('Helvetica');

  for (i = 0; i < invoice.items.length; i++) {
    const item = invoice.items[i];
    const position = invoiceTableTop + (i + 1) * 30;
    
    generateTableRow(
      doc,
      position,
      (i + 1).toString(),
      item.description,
      formatCurrency(item.unitPrice),
      item.quantity.toString(),
      formatCurrency(item.amount)
    );

    generateHr(doc, position + 20);
  }

  const subtotalPosition = invoiceTableTop + (i + 1) * 30;
  generateTableRow(
    doc,
    subtotalPosition,
    '',
    '',
    'Subtotal',
    '',
    formatCurrency(invoice.subtotal)
  );

  const taxPosition = subtotalPosition + 20;
  generateTableRow(
    doc,
    taxPosition,
    '',
    '',
    'Tax',
    '',
    formatCurrency(invoice.tax)
  );

  const discountPosition = taxPosition + 20;
  generateTableRow(
    doc,
    discountPosition,
    '',
    '',
    'Discount',
    '',
    formatCurrency(invoice.discount)
  );

  const duePosition = discountPosition + 20;
  doc.font('Helvetica-Bold');
  generateTableRow(
    doc,
    duePosition,
    '',
    '',
    'Total Due',
    '',
    formatCurrency(invoice.total)
  );
  doc.font('Helvetica');
}

function generateTableRow(doc, y, item, description, unitCost, quantity, lineTotal) {
  doc
    .fontSize(10)
    .text(item, 50, y)
    .text(description, 100, y, { width: 200 })
    .text(unitCost, 300, y, { width: 60, align: 'right' })
    .text(quantity, 360, y, { width: 40, align: 'right' })
    .text(lineTotal, 400, y, { width: 80, align: 'right' });
}

function generateHr(doc, y) {
  doc
    .strokeColor('#aaaaaa')
    .lineWidth(1)
    .moveTo(50, y)
    .lineTo(550, y)
    .stroke();
}

function generateFooter(doc) {
  doc
    .fontSize(10)
    .text(
      'Thank you for choosing Little Stars Nursery. Please make payment by the due date.',
      50,
      780,
      { align: 'center', width: 500 }
    );
}

function formatCurrency(amount) {
  return '$' + amount.toFixed(2);
}

function formatDate(date) {
  return moment(date).format('MMMM DD, YYYY');
}

// Generate receipt PDF
exports.generateReceiptPDF = async (payment) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 50 });
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      // Header
      generateReceiptHeader(doc);
      
      // Payment Information
      generatePaymentInformation(doc, payment);
      
      // Footer
      generateReceiptFooter(doc);

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

function generateReceiptHeader(doc) {
  doc
    .fillColor('#444444')
    .fontSize(20)
    .text('Little Stars Nursery', 50, 57)
    .fontSize(15)
    .text('Payment Receipt', 50, 100)
    .fontSize(10)
    .text('123 Education Street', 200, 65, { align: 'right' })
    .text('Learning City, LC 12345', 200, 80, { align: 'right' })
    .moveDown();
}

function generatePaymentInformation(doc, payment) {
  const informationTop = 150;

  doc
    .fillColor('#444444')
    .fontSize(10)
    .text('Receipt Number:', 50, informationTop)
    .font('Helvetica-Bold')
    .text(payment.paymentNumber, 150, informationTop)
    .font('Helvetica')
    .text('Payment Date:', 50, informationTop + 15)
    .text(formatDate(new Date(payment.paymentDate)), 150, informationTop + 15)
    .text('Payment Method:', 50, informationTop + 30)
    .text(formatPaymentMethod(payment.paymentMethod), 150, informationTop + 30)
    .text('Amount Paid:', 50, informationTop + 45)
    .font('Helvetica-Bold')
    .text(formatCurrency(payment.amount), 150, informationTop + 45)

    .font('Helvetica')
    .text(payment.parent.firstName + ' ' + payment.parent.lastName, 300, informationTop)
    .text(payment.parent.email, 300, informationTop + 15)
    .text(payment.parent.phone, 300, informationTop + 30)
    .moveDown();

  generateHr(doc, informationTop + 60);

  if (payment.invoice) {
    doc
      .text('Applied to Invoice:', 50, informationTop + 80)
      .font('Helvetica-Bold')
      .text(payment.invoice.invoiceNumber, 150, informationTop + 80)
      .font('Helvetica')
      .text('Invoice Amount:', 50, informationTop + 95)
      .text(formatCurrency(payment.invoice.total), 150, informationTop + 95);
  }

  doc
    .fontSize(12)
    .text('Payment Status: ' + payment.status.toUpperCase(), 50, informationTop + 120)
    .font('Helvetica-Bold')
    .fillColor(payment.status === 'completed' ? '#28a745' : '#ffc107');
}

function generateReceiptFooter(doc) {
  doc
    .fillColor('#444444')
    .fontSize(10)
    .text(
      'Thank you for your payment. This receipt confirms your transaction with Little Stars Nursery.',
      50,
      700,
      { align: 'center', width: 500 }
    );
}

function formatPaymentMethod(method) {
  const methods = {
    'credit_card': 'Credit Card',
    'debit_card': 'Debit Card',
    'bank_transfer': 'Bank Transfer',
    'cash': 'Cash',
    'check': 'Check'
  };
  return methods[method] || method;
}