const express = require('express');
const {
  getParents,
  getParent,
  createParent,
  updateParent,
  deleteParent,
  getParentByUser,
  addChild,
  getParentBalance
} = require('../controllers/parentController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, authorize('admin'), getParents)
  .post(protect, authorize('admin'), createParent);

router.route('/user/:userId')
  .get(protect, getParentByUser);

router.route('/:id')
  .get(protect, getParent)
  .put(protect, authorize('admin'), updateParent)
  .delete(protect, authorize('admin'), deleteParent);

router.route('/:id/child')
  .post(protect, authorize('admin'), addChild);

router.route('/:id/balance')
  .get(protect, getParentBalance);

module.exports = router;