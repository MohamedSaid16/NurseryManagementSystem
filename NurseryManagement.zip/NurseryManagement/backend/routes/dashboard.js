const express = require('express');
const {
  getAdminStats,
  getEmployeeStats,
  getParentStats,
  getRecentActivities,
  getAttendanceSummary
} = require('../controllers/dashboardController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Admin only routes
router.get('/admin', protect, authorize('admin'), getAdminStats);

// Employee routes
router.get('/employee', protect, authorize('employee', 'admin'), getEmployeeStats);

// Parent routes
router.get('/parent', protect, authorize('parent', 'admin'), getParentStats);

// General routes
router.get('/recent-activities', protect, getRecentActivities);
router.get('/attendance-summary', protect, getAttendanceSummary);

module.exports = router;