const express = require('express');
const {
  getActivities,
  getActivitiesByDate,
  getActivitiesByChild,
  getActivity,
  createActivity,
  updateActivity,
  deleteActivity,
  addChildToActivity,
  removeChildFromActivity,
  updateActivityStatus
} = require('../controllers/activityController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getActivities)
  .post(protect, authorize('admin', 'employee'), createActivity);

router.route('/date/:date')
  .get(protect, getActivitiesByDate);

router.route('/child/:childId')
  .get(protect, getActivitiesByChild);

router.route('/:id')
  .get(protect, getActivity)
  .put(protect, authorize('admin', 'employee'), updateActivity)
  .delete(protect, authorize('admin', 'employee'), deleteActivity);

router.route('/:id/child')
  .post(protect, authorize('admin', 'employee'), addChildToActivity);

router.route('/:id/child/:childId')
  .delete(protect, authorize('admin', 'employee'), removeChildFromActivity);

router.route('/:id/status')
  .put(protect, authorize('admin', 'employee'), updateActivityStatus);

module.exports = router;