const express = require('express');
const {
  getEmployees,
  getEmployee,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getEmployeeByUser,
  assignChild,
  getEmployeesByRole,
  addPerformanceReview
} = require('../controllers/employeeController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, authorize('admin'), getEmployees)
  .post(protect, authorize('admin'), createEmployee);

router.route('/user/:userId')
  .get(protect, getEmployeeByUser);

router.route('/role/:role')
  .get(protect, authorize('admin'), getEmployeesByRole);

router.route('/:id')
  .get(protect, authorize('admin'), getEmployee)
  .put(protect, authorize('admin'), updateEmployee)
  .delete(protect, authorize('admin'), deleteEmployee);

router.route('/:id/child')
  .post(protect, authorize('admin'), assignChild);

router.route('/:id/review')
  .post(protect, authorize('admin'), addPerformanceReview);

module.exports = router;