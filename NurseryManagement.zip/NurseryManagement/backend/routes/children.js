const express = require('express');
const {
  getChildren,
  getChild,
  createChild,
  updateChild,
  deleteChild,
  getChildrenByParent,
  getChildrenByEmployee,
  addNote,
  getChildProgress,
  getRecentActivities
} = require('../controllers/childController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getChildren)
  .post(protect, authorize('admin', 'employee'), createChild);

router.route('/parent/:parentId')
  .get(protect, getChildrenByParent);

router.route('/employee/:employeeId')
  .get(protect, getChildrenByEmployee);

router.route('/:id')
  .get(protect, getChild)
  .put(protect, authorize('admin', 'employee'), updateChild)
  .delete(protect, authorize('admin'), deleteChild);

router.route('/:id/note')
  .post(protect, authorize('admin', 'employee'), addNote);

router.route('/:id/progress')
  .get(protect, getChildProgress);

router.route('/:id/recent-activities')
  .get(protect, getRecentActivities);

module.exports = router;