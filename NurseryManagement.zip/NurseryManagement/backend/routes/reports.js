const express = require('express');
const {
  generateAttendanceReport,
  generateFinancialReport,
  generateChildrenReport,
  generateEmployeeReport,
  getDashboardStats,
  getRecentActivities
} = require('../controllers/reportController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/attendance')
  .post(protect, authorize('admin'), generateAttendanceReport);

router.route('/financial')
  .post(protect, authorize('admin'), generateFinancialReport);

router.route('/children')
  .post(protect, authorize('admin'), generateChildrenReport);

router.route('/employee')
  .post(protect, authorize('admin'), generateEmployeeReport);

router.route('/dashboard/stats')
  .get(protect, authorize('admin'), getDashboardStats);

router.route('/dashboard/recent-activities')
  .get(protect, getRecentActivities);

module.exports = router;