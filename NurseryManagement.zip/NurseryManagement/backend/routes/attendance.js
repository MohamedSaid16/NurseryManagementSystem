const express = require('express');
const {
  getAttendance,
  getAttendanceByDate,
  getTodayAttendance,
  getChildAttendance,
  createAttendance,
  updateAttendance,
  checkIn,
  checkOut,
  getAttendanceStats
} = require('../controllers/attendanceController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getAttendance)
  .post(protect, authorize('admin', 'employee'), createAttendance);

router.route('/today')
  .get(protect, getTodayAttendance);

router.route('/date/:date')
  .get(protect, getAttendanceByDate);

router.route('/stats')
  .get(protect, getAttendanceStats);

router.route('/child/:childId')
  .get(protect, getChildAttendance);

router.route('/:id')
  .put(protect, authorize('admin', 'employee'), updateAttendance);

router.route('/:id/checkin')
  .put(protect, authorize('admin', 'employee'), checkIn);

router.route('/:id/checkout')
  .put(protect, authorize('admin', 'employee'), checkOut);

module.exports = router;