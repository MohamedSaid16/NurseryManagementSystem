const express = require('express');
const {
  getInvoices,
  getInvoicesByParent,
  getInvoice,
  createInvoice,
  updateInvoice,
  deleteInvoice,
  sendInvoice,
  getPayments,
  getPaymentsByParent,
  createPayment,
  updatePaymentStatus,
  getParentBalance,
  getFinancialOverview
} = require('../controllers/billingController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Invoice routes
router.route('/invoices')
  .get(protect, getInvoices)
  .post(protect, authorize('admin'), createInvoice);

router.route('/invoices/parent/:parentId')
  .get(protect, getInvoicesByParent);

router.route('/invoices/:id')
  .get(protect, getInvoice)
  .put(protect, authorize('admin'), updateInvoice)
  .delete(protect, authorize('admin'), deleteInvoice);

router.route('/invoices/:id/send')
  .put(protect, authorize('admin'), sendInvoice);

// Payment routes
router.route('/payments')
  .get(protect, getPayments)
  .post(protect, createPayment);

router.route('/payments/parent/:parentId')
  .get(protect, getPaymentsByParent);

router.route('/payments/:id/status')
  .put(protect, authorize('admin'), updatePaymentStatus);

// Balance and overview
router.route('/parent/:parentId/balance')
  .get(protect, getParentBalance);

router.route('/overview')
  .get(protect, authorize('admin'), getFinancialOverview);

module.exports = router;