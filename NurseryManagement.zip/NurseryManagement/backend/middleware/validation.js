const { body, validationResult, param, query } = require('express-validator');
const { validateEmail, validatePhone } = require('../utils/helpers');

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// Common validation rules
const commonValidations = {
  email: body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),

  password: body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),

  phone: body('phone')
    .matches(/^\+?[\d\s-()]{10,}$/)
    .withMessage('Please provide a valid phone number'),

  objectId: param('id')
    .isMongoId()
    .withMessage('Invalid ID format'),

  date: body('date')
    .isISO8601()
    .withMessage('Please provide a valid date in ISO format')
};

// Auth validation rules
exports.validateRegister = [
  body('firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required')
    .isLength({ max: 50 })
    .withMessage('First name cannot exceed 50 characters'),

  body('lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required')
    .isLength({ max: 50 })
    .withMessage('Last name cannot exceed 50 characters'),

  commonValidations.email,
  commonValidations.password,
  commonValidations.phone,

  body('role')
    .isIn(['admin', 'employee', 'parent'])
    .withMessage('Role must be admin, employee, or parent'),

  handleValidationErrors
];

exports.validateLogin = [
  body('email')
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address'),

  body('password')
    .notEmpty()
    .withMessage('Password is required'),

  handleValidationErrors
];

exports.validateForgotPassword = [
  body('email')
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address'),

  handleValidationErrors
];

exports.validateResetPassword = [
  body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long'),

  handleValidationErrors
];

// Child validation rules
exports.validateChild = [
  body('firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required')
    .isLength({ max: 50 })
    .withMessage('First name cannot exceed 50 characters'),

  body('lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required')
    .isLength({ max: 50 })
    .withMessage('Last name cannot exceed 50 characters'),

  body('birthDate')
    .notEmpty()
    .withMessage('Birth date is required')
    .isISO8601()
    .withMessage('Please provide a valid birth date'),

  body('gender')
    .isIn(['male', 'female'])
    .withMessage('Gender must be male or female'),

  body('room')
    .isIn(['infants', 'toddlers', 'preschool'])
    .withMessage('Room must be infants, toddlers, or preschool'),

  body('allergies')
    .optional()
    .isArray()
    .withMessage('Allergies must be an array'),

  body('medications')
    .optional()
    .isArray()
    .withMessage('Medications must be an array'),

  body('emergencyContacts')
    .optional()
    .isArray()
    .withMessage('Emergency contacts must be an array'),

  handleValidationErrors
];

// Parent validation rules
exports.validateParent = [
  body('firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required')
    .isLength({ max: 50 })
    .withMessage('First name cannot exceed 50 characters'),

  body('lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required')
    .isLength({ max: 50 })
    .withMessage('Last name cannot exceed 50 characters'),

  commonValidations.email,
  commonValidations.phone,

  body('address.street')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Street address cannot exceed 100 characters'),

  body('address.city')
    .optional()
    .trim()
    .isLength({ max: 50 })
    .withMessage('City cannot exceed 50 characters'),

  body('address.state')
    .optional()
    .trim()
    .isLength({ max: 50 })
    .withMessage('State cannot exceed 50 characters'),

  body('address.zipCode')
    .optional()
    .matches(/^\d{5}(-\d{4})?$/)
    .withMessage('Please provide a valid ZIP code'),

  handleValidationErrors
];

// Employee validation rules
exports.validateEmployee = [
  body('position')
    .isIn(['teacher', 'assistant', 'director', 'admin', 'cook', 'janitor'])
    .withMessage('Invalid position'),

  body('department')
    .isIn(['infants', 'toddlers', 'preschool', 'administration', 'kitchen', 'maintenance'])
    .withMessage('Invalid department'),

  body('salary')
    .isNumeric()
    .withMessage('Salary must be a number')
    .isFloat({ min: 0 })
    .withMessage('Salary must be a positive number'),

  body('hireDate')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid hire date'),

  body('qualifications')
    .optional()
    .isArray()
    .withMessage('Qualifications must be an array'),

  handleValidationErrors
];

// Attendance validation rules
exports.validateAttendance = [
  body('child')
    .notEmpty()
    .withMessage('Child ID is required')
    .isMongoId()
    .withMessage('Invalid child ID'),

  body('date')
    .notEmpty()
    .withMessage('Date is required')
    .isISO8601()
    .withMessage('Please provide a valid date'),

  body('status')
    .isIn(['present', 'absent', 'late', 'excused'])
    .withMessage('Status must be present, absent, late, or excused'),

  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),

  body('absenceReason')
    .optional()
    .isIn(['sick', 'vacation', 'appointment', 'family', 'other'])
    .withMessage('Invalid absence reason'),

  handleValidationErrors
];

exports.validateCheckIn = [
  body('time')
    .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
    .withMessage('Please provide a valid time in HH:MM format'),

  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),

  handleValidationErrors
];

exports.validateCheckOut = [
  body('time')
    .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
    .withMessage('Please provide a valid time in HH:MM format'),

  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),

  handleValidationErrors
];

// Activity validation rules
exports.validateActivity = [
  body('title')
    .trim()
    .notEmpty()
    .withMessage('Activity title is required')
    .isLength({ max: 100 })
    .withMessage('Title cannot exceed 100 characters'),

  body('type')
    .isIn(['play', 'learning', 'meal', 'nap', 'art', 'music', 'outdoor', 'incident'])
    .withMessage('Invalid activity type'),

  body('room')
    .isIn(['infants', 'toddlers', 'preschool', 'playground', 'art', 'music'])
    .withMessage('Invalid room'),

  body('startTime')
    .notEmpty()
    .withMessage('Start time is required')
    .isISO8601()
    .withMessage('Please provide a valid start time'),

  body('endTime')
    .notEmpty()
    .withMessage('End time is required')
    .isISO8601()
    .withMessage('Please provide a valid end time'),

  body('children')
    .optional()
    .isArray()
    .withMessage('Children must be an array'),

  body('learningObjectives')
    .optional()
    .isArray()
    .withMessage('Learning objectives must be an array'),

  body('materials')
    .optional()
    .isArray()
    .withMessage('Materials must be an array'),

  handleValidationErrors
];

// Invoice validation rules
exports.validateInvoice = [
  body('parent')
    .notEmpty()
    .withMessage('Parent ID is required')
    .isMongoId()
    .withMessage('Invalid parent ID'),

  body('child')
    .notEmpty()
    .withMessage('Child ID is required')
    .isMongoId()
    .withMessage('Invalid child ID'),

  body('dueDate')
    .notEmpty()
    .withMessage('Due date is required')
    .isISO8601()
    .withMessage('Please provide a valid due date'),

  body('items')
    .isArray({ min: 1 })
    .withMessage('At least one invoice item is required'),

  body('items.*.description')
    .trim()
    .notEmpty()
    .withMessage('Item description is required'),

  body('items.*.unitPrice')
    .isNumeric()
    .withMessage('Unit price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Unit price must be a positive number'),

  body('items.*.quantity')
    .isInt({ min: 1 })
    .withMessage('Quantity must be a positive integer'),

  body('tax')
    .optional()
    .isNumeric()
    .withMessage('Tax must be a number')
    .isFloat({ min: 0 })
    .withMessage('Tax must be a positive number'),

  body('discount')
    .optional()
    .isNumeric()
    .withMessage('Discount must be a number')
    .isFloat({ min: 0 })
    .withMessage('Discount must be a positive number'),

  handleValidationErrors
];

// Payment validation rules
exports.validatePayment = [
  body('parent')
    .notEmpty()
    .withMessage('Parent ID is required')
    .isMongoId()
    .withMessage('Invalid parent ID'),

  body('amount')
    .isNumeric()
    .withMessage('Amount must be a number')
    .isFloat({ min: 0.01 })
    .withMessage('Amount must be greater than 0'),

  body('paymentMethod')
    .isIn(['credit_card', 'debit_card', 'bank_transfer', 'cash', 'check'])
    .withMessage('Invalid payment method'),

  body('paymentDate')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid payment date'),

  handleValidationErrors
];

// Report validation rules
exports.validateReport = [
  body('startDate')
    .notEmpty()
    .withMessage('Start date is required')
    .isISO8601()
    .withMessage('Please provide a valid start date'),

  body('endDate')
    .notEmpty()
    .withMessage('End date is required')
    .isISO8601()
    .withMessage('Please provide a valid end date'),

  body('format')
    .optional()
    .isIn(['pdf', 'json'])
    .withMessage('Format must be pdf or json'),

  handleValidationErrors
];

// Query parameter validation
exports.validateQueryParams = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),

  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),

  query('sort')
    .optional()
    .isString()
    .withMessage('Sort must be a string'),

  handleValidationErrors
];

// Object ID validation for route parameters
exports.validateObjectId = [
  commonValidations.objectId,
  handleValidationErrors
];