const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please enter activity title'],
    trim: true,
    maxLength: [100, 'Title cannot exceed 100 characters']
  },
  description: {
    type: String,
    trim: true
  },
  type: {
    type: String,
    enum: ['play', 'learning', 'meal', 'nap', 'art', 'music', 'outdoor', 'incident'],
    required: true
  },
  room: {
    type: String,
    enum: ['infants', 'toddlers', 'preschool', 'playground', 'art', 'music'],
    required: true
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  duration: {
    type: Number // in minutes
  },
  // Participating children
  children: [{
    child: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Child',
      required: true
    },
    participation: {
      type: String,
      enum: ['excellent', 'good', 'fair', 'poor'],
      default: 'good'
    },
    notes: String
  }],
  // Assigned employees
  assignedEmployees: [{
    employee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
      required: true
    }
  }],
  // Activity details
  materials: [{
    type: String,
    trim: true
  }],
  learningObjectives: [{
    type: String,
    trim: true
  }],
  photos: [{
    public_id: String,
    url: String,
    caption: String
  }],
  notes: String,
  // For incident reports
  incidentReport: {
    type: {
      type: String,
      enum: ['injury', 'behavior', 'medical', 'other']
    },
    severity: {
      type: String,
      enum: ['low', 'medium', 'high']
    },
    description: String,
    actionTaken: String,
    parentsNotified: Boolean
  },
  status: {
    type: String,
    enum: ['scheduled', 'in_progress', 'completed', 'cancelled'],
    default: 'scheduled'
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    required: true
  }
}, {
  timestamps: true
});

// Calculate duration before saving
activitySchema.pre('save', function(next) {
  if (this.startTime && this.endTime) {
    this.duration = (new Date(this.endTime) - new Date(this.startTime)) / (1000 * 60);
  }
  next();
});

module.exports = mongoose.model('Activity', activitySchema);