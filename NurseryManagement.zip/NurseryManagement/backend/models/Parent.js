const mongoose = require('mongoose');

const parentSchema = new mongoose.Schema({
  parentId: {
    type: String,
    unique: true,
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  address: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: {
      type: String,
      default: 'United States'
    }
  },
  emergencyContact: {
    name: String,
    relationship: String,
    phone: String,
    email: String
  },
  // Children references
  children: [{
    child: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Child',
      required: true
    },
    relationship: {
      type: String,
      enum: ['mother', 'father', 'guardian'],
      required: true
    }
  }],
  // Billing information
  billingAddress: {
    street: String,
    city: String,
    state: String,
    zipCode: String
  },
  paymentMethod: {
    type: String,
    enum: ['credit_card', 'debit_card', 'bank_transfer', 'cash'],
    default: 'credit_card'
  },
  cardLastFour: String,
  // Communication preferences
  communicationPreferences: {
    email: { type: Boolean, default: true },
    sms: { type: Boolean, default: true },
    push: { type: Boolean, default: true }
  },
  // Additional information
  occupation: String,
  employer: String,
  workPhone: String,
  notes: String,
  status: {
    type: String,
    enum: ['active', 'inactive', 'suspended'],
    default: 'active'
  }
}, {
  timestamps: true
});

// Generate parent ID before saving
parentSchema.pre('save', async function(next) {
  if (!this.parentId) {
    const year = new Date().getFullYear().toString().slice(-2);
    const count = await mongoose.model('Parent').countDocuments();
    this.parentId = `PA${year}${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Parent', parentSchema);