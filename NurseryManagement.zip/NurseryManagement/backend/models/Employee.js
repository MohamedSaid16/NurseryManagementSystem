const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  employeeId: {
    type: String,
    unique: true,
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  position: {
    type: String,
    required: [true, 'Please enter employee position'],
    enum: ['teacher', 'assistant', 'director', 'admin', 'cook', 'janitor']
  },
  department: {
    type: String,
    enum: ['infants', 'toddlers', 'preschool', 'administration', 'kitchen', 'maintenance'],
    required: true
  },
  hireDate: {
    type: Date,
    default: Date.now
  },
  salary: {
    type: Number,
    required: true
  },
  qualifications: [{
    type: String,
    trim: true
  }],
  certifications: [{
    name: String,
    issuingOrganization: String,
    issueDate: Date,
    expiryDate: Date
  }],
  emergencyContact: {
    name: String,
    relationship: String,
    phone: String,
    email: String
  },
  // Work schedule
  workSchedule: {
    monday: { start: String, end: String },
    tuesday: { start: String, end: String },
    wednesday: { start: String, end: String },
    thursday: { start: String, end: String },
    friday: { start: String, end: String },
    saturday: { start: String, end: String },
    sunday: { start: String, end: String }
  },
  // Assigned children
  assignedChildren: [{
    child: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Child'
    },
    role: {
      type: String,
      enum: ['primary', 'secondary']
    }
  }],
  // Performance and reviews
  performanceReviews: [{
    reviewDate: Date,
    reviewer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee'
    },
    rating: Number,
    comments: String,
    goals: [String]
  }],
  // Leave management
  leaveBalance: {
    sick: { type: Number, default: 0 },
    vacation: { type: Number, default: 0 },
    personal: { type: Number, default: 0 }
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'on_leave', 'terminated'],
    default: 'active'
  },
  notes: String
}, {
  timestamps: true
});

// Generate employee ID before saving
employeeSchema.pre('save', async function(next) {
  if (!this.employeeId) {
    const year = new Date().getFullYear().toString().slice(-2);
    const count = await mongoose.model('Employee').countDocuments();
    this.employeeId = `EM${year}${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Employee', employeeSchema);