const mongoose = require('mongoose');

const childSchema = new mongoose.Schema({
  childId: {
    type: String,
    unique: true,
    required: true
  },
  firstName: {
    type: String,
    required: [true, 'Please enter child first name'],
    trim: true,
    maxLength: [50, 'First name cannot exceed 50 characters']
  },
  lastName: {
    type: String,
    required: [true, 'Please enter child last name'],
    trim: true,
    maxLength: [50, 'Last name cannot exceed 50 characters']
  },
  birthDate: {
    type: Date,
    required: [true, 'Please enter birth date']
  },
  age: {
    type: Number,
    required: true
  },
  gender: {
    type: String,
    enum: ['male', 'female'],
    required: true
  },
  room: {
    type: String,
    enum: ['infants', 'toddlers', 'preschool'],
    required: true
  },
  profileImage: {
    public_id: String,
    url: String
  },
  // Parent references
  parents: [{
    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Parent',
      required: true
    },
    relationship: {
      type: String,
      enum: ['mother', 'father', 'guardian', 'other'],
      required: true
    }
  }],
  // Employee references (teachers/caregivers)
  assignedEmployees: [{
    employee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee'
    },
    role: {
      type: String,
      enum: ['primary', 'secondary', 'assistant']
    }
  }],
  // Medical information
  allergies: [{
    type: String,
    trim: true
  }],
  medications: [{
    name: String,
    dosage: String,
    schedule: String,
    instructions: String
  }],
  specialNeeds: {
    type: String,
    trim: true
  },
  dietaryRestrictions: [{
    type: String,
    trim: true
  }],
  emergencyContacts: [{
    name: {
      type: String,
      required: true
    },
    relationship: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true
    },
    email: String,
    address: String
  }],
  // Enrollment information
  enrollmentDate: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'waiting', 'graduated'],
    default: 'active'
  },
  notes: [{
    note: String,
    addedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    date: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Calculate age before saving
childSchema.pre('save', function(next) {
  if (this.birthDate) {
    const today = new Date();
    const birthDate = new Date(this.birthDate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    this.age = age;
  }
  next();
});

// Generate child ID before saving
childSchema.pre('save', async function(next) {
  if (!this.childId) {
    const year = new Date().getFullYear().toString().slice(-2);
    const count = await mongoose.model('Child').countDocuments();
    this.childId = `CH${year}${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Child', childSchema);