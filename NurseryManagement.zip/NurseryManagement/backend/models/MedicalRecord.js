const mongoose = require('mongoose');

const medicalRecordSchema = new mongoose.Schema({
  child: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Child',
    required: true
  },
  recordType: {
    type: String,
    enum: ['vaccination', 'checkup', 'incident', 'medication', 'allergy', 'other'],
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  description: {
    type: String,
    required: true
  },
  // For vaccinations
  vaccination: {
    name: String,
    dose: String,
    nextDueDate: Date
  },
  // For medical incidents
  incident: {
    type: String,
    description: String,
    severity: {
      type: String,
      enum: ['low', 'medium', 'high']
    },
    actionTaken: String,
    followUpRequired: Boolean
  },
  // For medications
  medication: {
    name: String,
    dosage: String,
    frequency: String,
    duration: String,
    prescribedBy: String
  },
  // General medical information
  height: Number,
  weight: Number,
  temperature: Number,
  bloodPressure: String,
  notes: String,
  // Attachments
  documents: [{
    public_id: String,
    url: String,
    description: String
  }],
  recordedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    required: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('MedicalRecord', medicalRecordSchema);