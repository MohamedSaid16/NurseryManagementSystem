const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  child: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Child',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['present', 'absent', 'late', 'excused'],
    required: true
  },
  checkIn: {
    time: String,
    recordedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee'
    },
    notes: String
  },
  checkOut: {
    time: String,
    recordedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee'
    },
    notes: String
  },
  recordedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    required: true
  },
  notes: String,
  // For absence tracking
  absenceReason: {
    type: String,
    enum: ['sick', 'vacation', 'appointment', 'family', 'other']
  },
  doctorNote: {
    public_id: String,
    url: String
  }
}, {
  timestamps: true
});

// Compound index to ensure one attendance record per child per day
attendanceSchema.index({ child: 1, date: 1 }, { unique: true });

// Virtual for duration
attendanceSchema.virtual('duration').get(function() {
  if (this.checkIn && this.checkOut) {
    const [inHour, inMinute] = this.checkIn.time.split(':').map(Number);
    const [outHour, outMinute] = this.checkOut.time.split(':').map(Number);
    
    const inTime = new Date(2000, 0, 1, inHour, inMinute);
    const outTime = new Date(2000, 0, 1, outHour, outMinute);
    
    return (outTime - inTime) / (1000 * 60); // duration in minutes
  }
  return 0;
});

module.exports = mongoose.model('Attendance', attendanceSchema);