const nodemailer = require('nodemailer');

// Create transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: process.env.SMTP_PORT || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

// Verify connection
transporter.verify(function (error, success) {
  if (error) {
    console.log('SMTP connection error:', error);
  } else {
    console.log('SMTP server is ready to take our messages');
  }
});

// Email templates
const emailTemplates = {
  welcome: (user) => ({
    subject: 'Welcome to Little Stars Nursery!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4CAF50;">Welcome to Little Stars Nursery!</h2>
        <p>Dear ${user.firstName} ${user.lastName},</p>
        <p>Your account has been successfully created. We're excited to have you as part of our nursery family!</p>
        <p>You can now access your account using the credentials you provided.</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <p><strong>Login Details:</strong></p>
          <p>Email: ${user.email}</p>
          <p>Role: ${user.role}</p>
        </div>
        <p>If you have any questions, please don't hesitate to contact us.</p>
        <p>Best regards,<br>The Little Stars Nursery Team</p>
      </div>
    `
  }),

  invoice: (invoice, parent) => ({
    subject: `Invoice ${invoice.invoiceNumber} from Little Stars Nursery`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2196F3;">Invoice ${invoice.invoiceNumber}</h2>
        <p>Dear ${parent.firstName} ${parent.lastName},</p>
        <p>Please find your latest invoice attached. The details are as follows:</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <p><strong>Invoice Details:</strong></p>
          <p>Invoice Number: ${invoice.invoiceNumber}</p>
          <p>Child: ${invoice.child.firstName} ${invoice.child.lastName}</p>
          <p>Due Date: ${new Date(invoice.dueDate).toLocaleDateString()}</p>
          <p>Total Amount: $${invoice.total.toFixed(2)}</p>
          <p>Balance Due: $${invoice.balanceDue.toFixed(2)}</p>
        </div>
        <p>Please make payment by the due date to avoid late fees.</p>
        <p>You can view and pay your invoice by logging into your parent portal.</p>
        <p>Best regards,<br>The Little Stars Nursery Team</p>
      </div>
    `
  }),

  paymentConfirmation: (payment, parent) => ({
    subject: `Payment Confirmation - ${payment.paymentNumber}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4CAF50;">Payment Confirmed!</h2>
        <p>Dear ${parent.firstName} ${parent.lastName},</p>
        <p>Thank you for your payment. We have successfully processed your transaction.</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <p><strong>Payment Details:</strong></p>
          <p>Payment Number: ${payment.paymentNumber}</p>
          <p>Amount: $${payment.amount.toFixed(2)}</p>
          <p>Date: ${new Date(payment.paymentDate).toLocaleDateString()}</p>
          <p>Method: ${payment.paymentMethod}</p>
          <p>Status: ${payment.status}</p>
        </div>
        <p>A receipt has been attached to this email for your records.</p>
        <p>Best regards,<br>The Little Stars Nursery Team</p>
      </div>
    `
  }),

  attendanceNotification: (child, attendance, parent) => ({
    subject: `Daily Attendance Update - ${child.firstName} ${child.lastName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #FF9800;">Daily Attendance Update</h2>
        <p>Dear ${parent.firstName} ${parent.lastName},</p>
        <p>Here's today's attendance update for ${child.firstName}:</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <p><strong>Attendance Status:</strong> ${attendance.status.toUpperCase()}</p>
          ${attendance.checkIn ? `<p><strong>Check-in Time:</strong> ${attendance.checkIn.time}</p>` : ''}
          ${attendance.checkOut ? `<p><strong>Check-out Time:</strong> ${attendance.checkOut.time}</p>` : ''}
          ${attendance.notes ? `<p><strong>Notes:</strong> ${attendance.notes}</p>` : ''}
        </div>
        <p>If you have any questions about today's attendance, please contact us.</p>
        <p>Best regards,<br>The Little Stars Nursery Team</p>
      </div>
    `
  }),

  passwordReset: (user, resetUrl) => ({
    subject: 'Password Reset Request - Little Stars Nursery',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2196F3;">Password Reset Request</h2>
        <p>Dear ${user.firstName} ${user.lastName},</p>
        <p>You have requested to reset your password. Click the link below to create a new password:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" style="background-color: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
            Reset Your Password
          </a>
        </div>
        <p>This link will expire in 30 minutes for security reasons.</p>
        <p>If you didn't request this reset, please ignore this email.</p>
        <p>Best regards,<br>The Little Stars Nursery Team</p>
      </div>
    `
  })
};

// Send email function
const sendEmail = async (to, templateName, data) => {
  try {
    const template = emailTemplates[templateName];
    if (!template) {
      throw new Error(`Email template '${templateName}' not found`);
    }

    const emailContent = typeof template === 'function' ? template(data) : template;

    const mailOptions = {
      from: `"Little Stars Nursery" <${process.env.SMTP_EMAIL}>`,
      to: to,
      subject: emailContent.subject,
      html: emailContent.html,
      attachments: data.attachments || []
    };

    const result = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
};

module.exports = {
  transporter,
  sendEmail,
  emailTemplates
};