import React, { createContext, useState, useContext, useEffect } from 'react';
import authService from '../services/auth';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('token');
      const userData = localStorage.getItem('user');
      
      console.log('🔍 Auth Check - Token:', token ? 'Exists' : 'Missing');
      console.log('🔍 Auth Check - User Data:', userData ? 'Exists' : 'Missing');
      
      if (token && userData) {
        setUser(JSON.parse(userData));
        console.log('✅ User restored from localStorage');
      }
    } catch (error) {
      console.error('❌ Auth check error:', error);
    } finally {
      setLoading(false);
      console.log('🔍 Auth loading complete');
    }
  };

  const login = async (email, password) => {
    console.log('🚀 Login attempt with:', { email, password });
    
    try {
      // TEMPORARY: Simulate successful login for testing
      console.log('🔧 Using temporary login simulation');
      
      let userData;
      let userRole = 'parent';
      
      // Determine role based on email
      if (email === 'admin@nursery.com') {
        userRole = 'admin';
        userData = {
          id: '1',
          firstName: 'Admin',
          lastName: 'User',
          email: 'admin@nursery.com',
          role: 'admin',
          phone: '+1234567890'
        };
      } else if (email === 'sarah.johnson@nursery.com') {
        userRole = 'employee';
        userData = {
          id: '2',
          firstName: 'Sarah',
          lastName: 'Johnson',
          email: 'sarah.johnson@nursery.com',
          role: 'employee',
          phone: '+1234567891'
        };
      } else {
        userRole = 'parent';
        userData = {
          id: '3',
          firstName: 'Parent',
          lastName: 'User',
          email: email,
          role: 'parent',
          phone: '+1234567892'
        };
      }

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Store in localStorage
      localStorage.setItem('token', 'demo-token-' + Date.now());
      localStorage.setItem('user', JSON.stringify(userData));
      
      setUser(userData);
      
      console.log('✅ Login successful:', userData);
      
      return { 
        success: true, 
        user: userData,
        role: userRole
      };
      
    } catch (error) {
      console.error('❌ Login error:', error);
      return { 
        success: false, 
        error: error.message || 'Login failed' 
      };
    }
  };

  const logout = () => {
    console.log('🚪 Logging out user');
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    console.log('✅ User logged out');
  };

  const value = {
    user,
    login,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;