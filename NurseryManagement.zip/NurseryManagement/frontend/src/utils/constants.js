export const USER_ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  PARENT: 'parent'
};

export const CHILD_ROOMS = {
  INFANTS: 'infants',
  TODDLERS: 'toddlers',
  PRESCHOOL: 'preschool'
};

export const ACTIVITY_TYPES = {
  PLAY: 'play',
  LEARNING: 'learning',
  MEAL: 'meal',
  NAP: 'nap',
  ART: 'art',
  MUSIC: 'music',
  OUTDOOR: 'outdoor',
  INCIDENT: 'incident'
};

export const ATTENDANCE_STATUS = {
  PRESENT: 'present',
  ABSENT: 'absent',
  LATE: 'late',
  EXCUSED: 'excused'
};

export const INVOICE_STATUS = {
  DRAFT: 'draft',
  PENDING: 'pending',
  PAID: 'paid',
  OVERDUE: 'overdue'
};

export const PAYMENT_METHODS = {
  CREDIT_CARD: 'credit_card',
  DEBIT_CARD: 'debit_card',
  BANK_TRANSFER: 'bank_transfer',
  CASH: 'cash'
};

export const MESSAGE_TYPES = {
  GENERAL: 'general',
  URGENT: 'urgent',
  ANNOUNCEMENT: 'announcement'
};

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    FORGOT_PASSWORD: '/auth/forgot-password',
    RESET_PASSWORD: '/auth/reset-password'
  },
  CHILDREN: {
    BASE: '/children',
    BY_PARENT: '/children/parent',
    ATTENDANCE: '/children/attendance',
    MILESTONES: '/children/milestones'
  },
  ACTIVITIES: {
    BASE: '/activities',
    BY_CHILD: '/activities/child',
    BY_DATE: '/activities/date'
  },
  BILLING: {
    BASE: '/billing',
    INVOICES: '/billing/invoices',
    PAYMENTS: '/billing/payments'
  },
  MESSAGES: {
    BASE: '/messages',
    CONVERSATIONS: '/messages/conversations'
  }
};

export const DATE_FORMATS = {
  DISPLAY: 'MMM DD, YYYY',
  API: 'YYYY-MM-DD',
  TIME: 'HH:mm'
};