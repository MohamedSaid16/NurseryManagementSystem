export const validateRequired = (value) => {
  return value && value.toString().trim().length > 0;
};

export const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password) => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
  return passwordRegex.test(password);
};

export const validatePhone = (phone) => {
  const phoneRegex = /^\+?[\d\s-()]{10,}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
};

export const validateDate = (dateString) => {
  const date = new Date(dateString);
  return date instanceof Date && !isNaN(date);
};

export const validateNumber = (value, min = null, max = null) => {
  const num = Number(value);
  if (isNaN(num)) return false;
  if (min !== null && num < min) return false;
  if (max !== null && num > max) return false;
  return true;
};

export const validateChildForm = (formData) => {
  const errors = {};

  if (!validateRequired(formData.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (!validateRequired(formData.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (!validateRequired(formData.birthDate) || !validateDate(formData.birthDate)) {
    errors.birthDate = 'Valid birth date is required';
  }

  if (!validateRequired(formData.gender)) {
    errors.gender = 'Gender is required';
  }

  if (!validateRequired(formData.room)) {
    errors.room = 'Room is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validateEmployeeForm = (formData) => {
  const errors = {};

  if (!validateRequired(formData.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (!validateRequired(formData.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (!validateRequired(formData.email) || !validateEmail(formData.email)) {
    errors.email = 'Valid email is required';
  }

  if (!validateRequired(formData.phone) || !validatePhone(formData.phone)) {
    errors.phone = 'Valid phone number is required';
  }

  if (!validateRequired(formData.role)) {
    errors.role = 'Role is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validateParentForm = (formData) => {
  const errors = {};

  if (!validateRequired(formData.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (!validateRequired(formData.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (!validateRequired(formData.email) || !validateEmail(formData.email)) {
    errors.email = 'Valid email is required';
  }

  if (!validateRequired(formData.phone) || !validatePhone(formData.phone)) {
    errors.phone = 'Valid phone number is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validateActivityForm = (formData) => {
  const errors = {};

  if (!validateRequired(formData.title)) {
    errors.title = 'Activity title is required';
  }

  if (!validateRequired(formData.type)) {
    errors.type = 'Activity type is required';
  }

  if (!validateRequired(formData.startTime)) {
    errors.startTime = 'Start time is required';
  }

  if (!validateRequired(formData.endTime)) {
    errors.endTime = 'End time is required';
  }

  if (formData.startTime && formData.endTime) {
    const start = new Date(`2000-01-01T${formData.startTime}`);
    const end = new Date(`2000-01-01T${formData.endTime}`);
    if (end <= start) {
      errors.endTime = 'End time must be after start time';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validatePaymentForm = (formData) => {
  const errors = {};

  if (!validateRequired(formData.amount) || !validateNumber(formData.amount, 0.01)) {
    errors.amount = 'Valid amount is required';
  }

  if (!validateRequired(formData.paymentMethod)) {
    errors.paymentMethod = 'Payment method is required';
  }

  if (formData.paymentMethod.includes('card')) {
    if (!validateRequired(formData.cardNumber) || formData.cardNumber.length !== 16) {
      errors.cardNumber = 'Valid card number is required';
    }

    if (!validateRequired(formData.expiryDate)) {
      errors.expiryDate = 'Expiry date is required';
    }

    if (!validateRequired(formData.cvv) || (formData.cvv.length < 3 || formData.cvv.length > 4)) {
      errors.cvv = 'Valid CVV is required';
    }

    if (!validateRequired(formData.nameOnCard)) {
      errors.nameOnCard = 'Name on card is required';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Export as both named and default
const validation = {
  validateRequired,
  validateEmail,
  validatePassword,
  validatePhone,
  validateDate,
  validateNumber,
  validateChildForm,
  validateEmployeeForm,
  validateParentForm,
  validateActivityForm,
  validatePaymentForm
};

export default validation;