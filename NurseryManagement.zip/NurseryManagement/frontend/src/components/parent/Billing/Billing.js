import React, { useState, useEffect } from 'react';
import  billingService  from '../../../services/billing';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import Modal from '../../common/Modal/Modal';
import './Billing.css';

const Billing = () => {
  const [invoices, setInvoices] = useState([]);
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [balance, setBalance] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [paymentData, setPaymentData] = useState({
    amount: '',
    paymentMethod: 'credit_card',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    nameOnCard: ''
  });

  useEffect(() => {
    loadBillingData();
  }, []);

  const loadBillingData = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem('user'));
      const parentId = user._id;

      const [balanceRes, invoicesRes, paymentsRes] = await Promise.all([
        billingService.getParentBalance(parentId),
        billingService.getInvoices(parentId),
        billingService.getPaymentHistory(parentId)
      ]);

      setBalance(balanceRes.balance || 0);
      setInvoices(invoicesRes.invoices || invoicesRes);
      setPaymentHistory(paymentsRes.payments || paymentsRes);
    } catch (error) {
      console.error('Error loading billing data:', error);
      alert('Error loading billing information');
    } finally {
      setLoading(false);
    }
  };

  const handleMakePayment = (invoice = null) => {
    setSelectedInvoice(invoice);
    setPaymentData({
      amount: invoice ? invoice.amountDue : balance.toString(),
      paymentMethod: 'credit_card',
      cardNumber: '',
      expiryDate: '',
      cvv: '',
      nameOnCard: ''
    });
    setShowPaymentModal(true);
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      
      const paymentPayload = {
        parentId: user._id,
        amount: parseFloat(paymentData.amount),
        paymentMethod: paymentData.paymentMethod,
        invoiceId: selectedInvoice?._id,
        paymentDate: new Date().toISOString(),
        cardLastFour: paymentData.cardNumber.slice(-4)
      };

      const result = await billingService.makePayment(paymentPayload);
      
      alert('Payment processed successfully!');
      setShowPaymentModal(false);
      loadBillingData(); // Refresh data
    } catch (error) {
      console.error('Error processing payment:', error);
      alert('Error processing payment: ' + error.message);
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      paid: { class: 'paid', text: 'Paid' },
      pending: { class: 'pending', text: 'Pending' },
      overdue: { class: 'overdue', text: 'Overdue' },
      draft: { class: 'draft', text: 'Draft' }
    };
    return statusConfig[status] || { class: 'draft', text: 'Unknown' };
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getUpcomingPayments = () => {
    return invoices.filter(invoice => 
      invoice.status === 'pending' && new Date(invoice.dueDate) > new Date()
    );
  };

  const getOverdueInvoices = () => {
    return invoices.filter(invoice => 
      invoice.status === 'overdue' || 
      (invoice.status === 'pending' && new Date(invoice.dueDate) < new Date())
    );
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="billing">
      <div className="page-header">
        <div className="header-content">
          <h1>Billing & Payments</h1>
          <button 
            className="btn btn-primary"
            onClick={() => handleMakePayment()}
            disabled={balance <= 0}
          >
            Make Payment
          </button>
        </div>
      </div>

      {/* Balance Overview */}
      <div className="balance-overview">
        <div className="balance-card">
          <div className="balance-icon">💰</div>
          <div className="balance-info">
            <h3>Current Balance</h3>
            <div className="balance-amount">{formatCurrency(balance)}</div>
            <div className="balance-details">
              <span className="detail-item">
                <span className="detail-label">Overdue:</span>
                <span className="detail-value overdue">{getOverdueInvoices().length} invoices</span>
              </span>
              <span className="detail-item">
                <span className="detail-label">Upcoming:</span>
                <span className="detail-value upcoming">{getUpcomingPayments().length} payments</span>
              </span>
            </div>
          </div>
          <button 
            className="btn btn-primary"
            onClick={() => handleMakePayment()}
            disabled={balance <= 0}
          >
            Pay Now
          </button>
        </div>
      </div>

      <div className="billing-content">
        {/* Invoices Section */}
        <div className="billing-section">
          <div className="section-header">
            <h2>Invoices</h2>
            <div className="section-actions">
              <button className="btn btn-outline">Download All</button>
            </div>
          </div>

          <div className="invoices-table">
            <div className="table-header">
              <div className="col">Invoice #</div>
              <div className="col">Date</div>
              <div className="col">Due Date</div>
              <div className="col">Amount</div>
              <div className="col">Status</div>
              <div className="col">Actions</div>
            </div>
            <div className="table-body">
              {invoices.map(invoice => {
                const status = getStatusBadge(invoice.status);
                return (
                  <div key={invoice._id} className="table-row">
                    <div className="col">
                      <strong>INV-{invoice.invoiceNumber}</strong>
                      <div className="invoice-description">{invoice.description}</div>
                    </div>
                    <div className="col">
                      {new Date(invoice.invoiceDate).toLocaleDateString()}
                    </div>
                    <div className="col">
                      {new Date(invoice.dueDate).toLocaleDateString()}
                    </div>
                    <div className="col amount">
                      {formatCurrency(invoice.amount)}
                    </div>
                    <div className="col">
                      <span className={`status-badge status-${status.class}`}>
                        {status.text}
                      </span>
                    </div>
                    <div className="col actions">
                      <button 
                        className="btn btn-sm btn-outline"
                        onClick={() => window.open(`/api/invoices/${invoice._id}/download`, '_blank')}
                      >
                        Download
                      </button>
                      {invoice.status !== 'paid' && (
                        <button 
                          className="btn btn-sm btn-primary"
                          onClick={() => handleMakePayment(invoice)}
                        >
                          Pay Now
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
              {invoices.length === 0 && (
                <div className="no-data">
                  <p>No invoices found</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="billing-section">
          <div className="section-header">
            <h2>Payment History</h2>
          </div>

          <div className="payments-table">
            <div className="table-header">
              <div className="col">Date</div>
              <div className="col">Description</div>
              <div className="col">Method</div>
              <div className="col">Amount</div>
              <div className="col">Status</div>
              <div className="col">Receipt</div>
            </div>
            <div className="table-body">
              {paymentHistory.map(payment => (
                <div key={payment._id} className="table-row">
                  <div className="col">
                    {new Date(payment.paymentDate).toLocaleDateString()}
                  </div>
                  <div className="col">
                    <strong>{payment.description}</strong>
                    {payment.invoiceNumber && (
                      <div className="payment-reference">
                        Invoice: INV-{payment.invoiceNumber}
                      </div>
                    )}
                  </div>
                  <div className="col">
                    <span className="payment-method">
                      {payment.paymentMethod === 'credit_card' ? '💳 Credit Card' : 
                       payment.paymentMethod === 'bank_transfer' ? '🏦 Bank Transfer' : 
                       payment.paymentMethod === 'cash' ? '💵 Cash' : 'Payment'}
                    </span>
                    {payment.cardLastFour && (
                      <div className="card-info">**** {payment.cardLastFour}</div>
                    )}
                  </div>
                  <div className="col amount">
                    {formatCurrency(payment.amount)}
                  </div>
                  <div className="col">
                    <span className={`status-badge status-${payment.status}`}>
                      {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                    </span>
                  </div>
                  <div className="col actions">
                    <button 
                      className="btn btn-sm btn-outline"
                      onClick={() => window.open(`/api/payments/${payment._id}/receipt`, '_blank')}
                    >
                      Receipt
                    </button>
                  </div>
                </div>
              ))}
              {paymentHistory.length === 0 && (
                <div className="no-data">
                  <p>No payment history found</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      <Modal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        title="Make Payment"
        size="medium"
      >
        <form onSubmit={handlePaymentSubmit} className="payment-form">
          <div className="form-group">
            <label className="form-label">Amount to Pay *</label>
            <input
              type="number"
              className="form-control"
              value={paymentData.amount}
              onChange={(e) => setPaymentData({...paymentData, amount: e.target.value})}
              step="0.01"
              min="0.01"
              max={balance}
              required
            />
            <div className="form-hint">
              Maximum: {formatCurrency(balance)}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Payment Method *</label>
            <select
              className="form-control"
              value={paymentData.paymentMethod}
              onChange={(e) => setPaymentData({...paymentData, paymentMethod: e.target.value})}
              required
            >
              <option value="credit_card">Credit Card</option>
              <option value="bank_transfer">Bank Transfer</option>
              <option value="debit_card">Debit Card</option>
            </select>
          </div>

          {paymentData.paymentMethod.includes('card') && (
            <>
              <div className="form-group">
                <label className="form-label">Name on Card *</label>
                <input
                  type="text"
                  className="form-control"
                  value={paymentData.nameOnCard}
                  onChange={(e) => setPaymentData({...paymentData, nameOnCard: e.target.value})}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Card Number *</label>
                <input
                  type="text"
                  className="form-control"
                  value={paymentData.cardNumber}
                  onChange={(e) => setPaymentData({...paymentData, cardNumber: e.target.value})}
                  placeholder="1234 5678 9012 3456"
                  maxLength="16"
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Expiry Date *</label>
                  <input
                    type="month"
                    className="form-control"
                    value={paymentData.expiryDate}
                    onChange={(e) => setPaymentData({...paymentData, expiryDate: e.target.value})}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">CVV *</label>
                  <input
                    type="text"
                    className="form-control"
                    value={paymentData.cvv}
                    onChange={(e) => setPaymentData({...paymentData, cvv: e.target.value})}
                    maxLength="4"
                    required
                  />
                </div>
              </div>
            </>
          )}

          <div className="payment-summary">
            <div className="summary-item">
              <span>Amount:</span>
              <span>{formatCurrency(parseFloat(paymentData.amount) || 0)}</span>
            </div>
            <div className="summary-item">
              <span>Processing Fee:</span>
              <span>{formatCurrency(0)}</span>
            </div>
            <div className="summary-item total">
              <span>Total:</span>
              <span>{formatCurrency(parseFloat(paymentData.amount) || 0)}</span>
            </div>
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => setShowPaymentModal(false)}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Process Payment
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Billing;