import React, { useState, useEffect } from 'react';
import  messagesService  from '../../../services/messages';
import  employeesService  from '../../../services/employees';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import Modal from '../../common/Modal/Modal';
import './Messages.css';

const Messages = () => {
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showNewMessageModal, setShowNewMessageModal] = useState(false);
  const [newMessage, setNewMessage] = useState({
    recipient: '',
    subject: '',
    message: ''
  });

  useEffect(() => {
    loadMessagesData();
  }, []);

  const loadMessagesData = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem('user'));
      const parentId = user._id;

      const [conversationsRes, employeesRes] = await Promise.all([
        messagesService.getConversations(parentId),
        employeesService.getAll()
      ]);

      setConversations(conversationsRes.conversations || conversationsRes);
      setEmployees(employeesRes.employees || employeesRes);

      // Select first conversation by default
      if (conversationsRes.conversations && conversationsRes.conversations.length > 0) {
        handleSelectConversation(conversationsRes.conversations[0]);
      }
    } catch (error) {
      console.error('Error loading messages data:', error);
      alert('Error loading messages');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectConversation = async (conversation) => {
    try {
      setSelectedConversation(conversation);
      const messagesRes = await messagesService.getMessages(conversation._id);
      setMessages(messagesRes.messages || messagesRes);

      // Mark messages as read
      const unreadMessages = messagesRes.messages?.filter(msg => 
        !msg.read && msg.sender._id !== JSON.parse(localStorage.getItem('user'))._id
      );
      
      if (unreadMessages && unreadMessages.length > 0) {
        await Promise.all(
          unreadMessages.map(msg => messagesService.markAsRead(msg._id))
        );
      }
    } catch (error) {
      console.error('Error loading conversation messages:', error);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    try {
      setSending(true);
      const user = JSON.parse(localStorage.getItem('user'));

      const messageData = {
        sender: user._id,
        recipient: newMessage.recipient,
        subject: newMessage.subject,
        message: newMessage.message,
        parentId: user._id,
        timestamp: new Date().toISOString()
      };

      await messagesService.sendMessage(messageData);
      
      alert('Message sent successfully!');
      setShowNewMessageModal(false);
      setNewMessage({ recipient: '', subject: '', message: '' });
      loadMessagesData(); // Refresh conversations
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Error sending message');
    } finally {
      setSending(false);
    }
  };

  const handleReply = async (messageText) => {
    if (!selectedConversation) return;

    try {
      setSending(true);
      const user = JSON.parse(localStorage.getItem('user'));

      const replyData = {
        sender: user._id,
        recipient: selectedConversation.participants.find(p => p._id !== user._id)?._id,
        subject: `Re: ${selectedConversation.lastMessage?.subject || 'Message'}`,
        message: messageText,
        parentId: user._id,
        timestamp: new Date().toISOString(),
        conversationId: selectedConversation._id
      };

      await messagesService.sendMessage(replyData);
      
      // Refresh messages in current conversation
      const messagesRes = await messagesService.getMessages(selectedConversation._id);
      setMessages(messagesRes.messages || messagesRes);
    } catch (error) {
      console.error('Error sending reply:', error);
      alert('Error sending reply');
    } finally {
      setSending(false);
    }
  };

  const getEmployeeName = (employeeId) => {
    const employee = employees.find(emp => emp._id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown';
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleDateString();
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="messages">
      <div className="page-header">
        <div className="header-content">
          <h1>Messages</h1>
          <button 
            className="btn btn-primary"
            onClick={() => setShowNewMessageModal(true)}
          >
            New Message
          </button>
        </div>
      </div>

      <div className="messages-container">
        {/* Conversations List */}
        <div className="conversations-sidebar">
          <div className="conversations-header">
            <h3>Conversations</h3>
          </div>
          <div className="conversations-list">
            {conversations.map(conversation => (
              <div
                key={conversation._id}
                className={`conversation-item ${
                  selectedConversation?._id === conversation._id ? 'active' : ''
                } ${conversation.unreadCount > 0 ? 'unread' : ''}`}
                onClick={() => handleSelectConversation(conversation)}
              >
                <div className="conversation-avatar">
                  {conversation.participants[0]?.firstName?.charAt(0) || 'U'}
                </div>
                <div className="conversation-info">
                  <div className="conversation-name">
                    {getEmployeeName(conversation.participants.find(p => 
                      p._id !== JSON.parse(localStorage.getItem('user'))._id
                    )?._id)}
                  </div>
                  <div className="conversation-preview">
                    {conversation.lastMessage?.message?.substring(0, 50)}...
                  </div>
                </div>
                <div className="conversation-meta">
                  <div className="conversation-time">
                    {formatTime(conversation.lastMessage?.timestamp)}
                  </div>
                  {conversation.unreadCount > 0 && (
                    <div className="unread-badge">{conversation.unreadCount}</div>
                  )}
                </div>
              </div>
            ))}
            {conversations.length === 0 && (
              <div className="no-conversations">
                <p>No conversations yet</p>
                <button 
                  className="btn btn-primary btn-sm"
                  onClick={() => setShowNewMessageModal(true)}
                >
                  Start a Conversation
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Messages Area */}
        <div className="messages-area">
          {selectedConversation ? (
            <>
              <div className="messages-header">
                <h3>
                  {getEmployeeName(selectedConversation.participants.find(p => 
                    p._id !== JSON.parse(localStorage.getItem('user'))._id
                  )?._id)}
                </h3>
                <div className="conversation-actions">
                  <button className="btn btn-outline btn-sm">Call</button>
                  <button className="btn btn-outline btn-sm">Schedule Meeting</button>
                </div>
              </div>

              <div className="messages-list">
                {messages.map(message => (
                  <div
                    key={message._id}
                    className={`message ${message.sender._id === JSON.parse(localStorage.getItem('user'))._id ? 'sent' : 'received'}`}
                  >
                    <div className="message-content">
                      <div className="message-text">{message.message}</div>
                      <div className="message-time">
                        {formatTime(message.timestamp)} • {formatDate(message.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
                {messages.length === 0 && (
                  <div className="no-messages">
                    <p>No messages in this conversation</p>
                  </div>
                )}
              </div>

              <MessageInput onSendMessage={handleReply} disabled={sending} />
            </>
          ) : (
            <div className="no-conversation-selected">
              <div className="placeholder-icon">💬</div>
              <h3>Select a conversation</h3>
              <p>Choose a conversation from the list or start a new one</p>
              <button 
                className="btn btn-primary"
                onClick={() => setShowNewMessageModal(true)}
              >
                New Message
              </button>
            </div>
          )}
        </div>
      </div>

      {/* New Message Modal */}
      <Modal
        isOpen={showNewMessageModal}
        onClose={() => setShowNewMessageModal(false)}
        title="New Message"
        size="medium"
      >
        <form onSubmit={handleSendMessage} className="new-message-form">
          <div className="form-group">
            <label className="form-label">To *</label>
            <select
              className="form-control"
              value={newMessage.recipient}
              onChange={(e) => setNewMessage({...newMessage, recipient: e.target.value})}
              required
            >
              <option value="">Select Recipient</option>
              {employees.map(employee => (
                <option key={employee._id} value={employee._id}>
                  {employee.firstName} {employee.lastName} - {employee.role}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Subject *</label>
            <input
              type="text"
              className="form-control"
              value={newMessage.subject}
              onChange={(e) => setNewMessage({...newMessage, subject: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Message *</label>
            <textarea
              className="form-control"
              rows="6"
              value={newMessage.message}
              onChange={(e) => setNewMessage({...newMessage, message: e.target.value})}
              placeholder="Type your message here..."
              required
            />
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => setShowNewMessageModal(false)}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={sending}>
              {sending ? 'Sending...' : 'Send Message'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

// Message Input Component
const MessageInput = ({ onSendMessage, disabled }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="message-input">
      <div className="input-group">
        <input
          type="text"
          className="form-control"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          disabled={disabled}
        />
        <button type="submit" className="btn btn-primary" disabled={disabled || !message.trim()}>
          Send
        </button>
      </div>
    </form>
  );
};

export default Messages;