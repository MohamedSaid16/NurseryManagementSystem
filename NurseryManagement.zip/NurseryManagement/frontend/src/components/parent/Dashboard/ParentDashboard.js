import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  billingService from '../../../services/billing';
import  messagesService  from '../../../services/messages';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './ParentDashboard.css';

const ParentDashboard = () => {
  const [children, setChildren] = useState([]);
  const [billingInfo, setBillingInfo] = useState({});
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [activeChild, setActiveChild] = useState(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [childrenRes, billingRes, messagesRes] = await Promise.all([
        childrenService.getMyChildren(),
        billingService.getMyBilling(),
        messagesService.getUnreadCount()
      ]);

      setChildren(childrenRes.children || childrenRes);
      setBillingInfo(billingRes);
      setUnreadMessages(messagesRes.count || 0);
      
      if (childrenRes.children && childrenRes.children.length > 0) {
        setActiveChild(childrenRes.children[0]);
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      alert('Error loading dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getUpcomingEvents = () => {
    // Mock data - replace with actual events from your API
    return [
      { id: 1, title: 'Parent-Teacher Meeting', date: '2024-01-15', type: 'meeting' },
      { id: 2, title: 'Sports Day', date: '2024-01-20', type: 'event' },
      { id: 3, title: 'Payment Due', date: '2024-01-25', type: 'payment' }
    ];
  };

  const getChildProgress = (child) => {
    // Mock progress data
    return {
      attendance: Math.floor(Math.random() * 30) + 70, // 70-100%
      activities: Math.floor(Math.random() * 20) + 10, // 10-30 activities
      milestones: Math.floor(Math.random() * 5) + 1 // 1-5 milestones
    };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="parent-dashboard">
      <div className="dashboard-header">
        <h1>Parent Dashboard</h1>
        <div className="header-stats">
          <div className="stat-card">
            <div className="stat-icon">👶</div>
            <div className="stat-info">
              <span className="stat-number">{children.length}</span>
              <span className="stat-label">Children</span>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon">💬</div>
            <div className="stat-info">
              <span className="stat-number">{unreadMessages}</span>
              <span className="stat-label">Unread Messages</span>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon">💰</div>
            <div className="stat-info">
              <span className="stat-number">
                ${billingInfo.balanceDue || 0}
              </span>
              <span className="stat-label">Balance Due</span>
            </div>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        {/* Children Overview */}
        <div className="dashboard-section">
          <h2>My Children</h2>
          <div className="children-grid">
            {children.map(child => (
              <div key={child._id} className="child-card">
                <div className="child-avatar">
                  {child.gender === 'male' ? '👦' : '👧'}
                </div>
                <div className="child-info">
                  <h3>{child.firstName} {child.lastName}</h3>
                  <p className="child-age">{child.age} years old</p>
                  <p className="child-room">{child.room} Room</p>
                </div>
                <div className="child-progress">
                  <div className="progress-item">
                    <span className="progress-label">Attendance</span>
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${getChildProgress(child).attendance}%` }}
                      ></div>
                    </div>
                    <span className="progress-value">{getChildProgress(child).attendance}%</span>
                  </div>
                  <div className="progress-item">
                    <span className="progress-label">Activities</span>
                    <span className="progress-value">{getChildProgress(child).activities}</span>
                  </div>
                </div>
                <button 
                  className="btn btn-primary btn-sm"
                  onClick={() => setActiveChild(child)}
                >
                  View Details
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <h2>Quick Actions</h2>
          <div className="quick-actions-grid">
            <button className="action-card">
              <div className="action-icon">📝</div>
              <span>View Reports</span>
            </button>
            <button className="action-card">
              <div className="action-icon">💳</div>
              <span>Make Payment</span>
            </button>
            <button className="action-card">
              <div className="action-icon">📅</div>
              <span>Schedule Visit</span>
            </button>
            <button className="action-card">
              <div className="action-icon">💬</div>
              <span>Send Message</span>
            </button>
            <button className="action-card">
              <div className="action-icon">🍽️</div>
              <span>Meal Preferences</span>
            </button>
            <button className="action-card">
              <div className="action-icon">🏥</div>
              <span>Update Health Info</span>
            </button>
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="dashboard-section">
          <h2>Upcoming Events</h2>
          <div className="events-list">
            {getUpcomingEvents().map(event => (
              <div key={event.id} className="event-item">
                <div className={`event-type event-${event.type}`}></div>
                <div className="event-details">
                  <h4>{event.title}</h4>
                  <p>{new Date(event.date).toLocaleDateString()}</p>
                </div>
                <button className="btn btn-outline btn-sm">View</button>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="dashboard-section">
          <h2>Recent Activity</h2>
          <div className="activity-feed">
            <div className="activity-item">
              <div className="activity-icon">🎨</div>
              <div className="activity-content">
                <p><strong>Art Class</strong> - Your child participated in painting activity</p>
                <span className="activity-time">2 hours ago</span>
              </div>
            </div>
            <div className="activity-item">
              <div className="activity-icon">🍎</div>
              <div className="activity-content">
                <p><strong>Lunch</strong> - Finished all fruits and vegetables</p>
                <span className="activity-time">4 hours ago</span>
              </div>
            </div>
            <div className="activity-item">
              <div className="activity-icon">😴</div>
              <div className="activity-content">
                <p><strong>Nap Time</strong> - Slept for 2 hours</p>
                <span className="activity-time">6 hours ago</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ParentDashboard;