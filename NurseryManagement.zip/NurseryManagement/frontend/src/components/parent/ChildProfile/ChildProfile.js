import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  activitiesService  from '../../../services/activities';
import  attendanceService  from '../../../services/attendance';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './ChildProfile.css';

const ChildProfile = () => {
  const [child, setChild] = useState(null);
  const [activities, setActivities] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [milestones, setMilestones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Get child ID from URL params or context
    const urlParams = new URLSearchParams(window.location.search);
    const childId = urlParams.get('childId') || 'current'; // Replace with actual logic
    
    loadChildData(childId);
  }, []);

  const loadChildData = async (childId) => {
    try {
      setLoading(true);
      
      const [childRes, activitiesRes, attendanceRes, milestonesRes] = await Promise.all([
        childrenService.getById(childId),
        activitiesService.getByChild(childId),
        attendanceService.getChildAttendance(childId),
        childrenService.getMilestones(childId)
      ]);

      setChild(childRes.child || childRes);
      setActivities(activitiesRes.activities || activitiesRes);
      setAttendance(attendanceRes.attendance || attendanceRes);
      setMilestones(milestonesRes.milestones || milestonesRes);
    } catch (error) {
      console.error('Error loading child data:', error);
      alert('Error loading child profile');
    } finally {
      setLoading(false);
    }
  };

  const getAttendanceStats = () => {
    if (!attendance.length) return { present: 0, absent: 0, percentage: 0 };
    
    const present = attendance.filter(a => a.status === 'present').length;
    const total = attendance.length;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
    
    return { present, absent: total - present, percentage };
  };

  const getRecentActivities = () => {
    return activities.slice(0, 5).sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!child) {
    return <div className="child-not-found">Child not found</div>;
  }

  return (
    <div className="child-profile">
      <div className="profile-header">
        <div className="child-basic-info">
          <div className="child-avatar-large">
            {child.gender === 'male' ? '👦' : '👧'}
          </div>
          <div className="child-details">
            <h1>{child.firstName} {child.lastName}</h1>
            <div className="child-meta">
              <span className="meta-item">Age: {child.age} years</span>
              <span className="meta-item">Room: {child.room}</span>
              <span className="meta-item">Teacher: {child.teacher?.name || 'Not assigned'}</span>
            </div>
            <div className="child-tags">
              {child.allergies && child.allergies.length > 0 && (
                <span className="tag allergy">Allergies: {child.allergies.join(', ')}</span>
              )}
              {child.medications && child.medications.length > 0 && (
                <span className="tag medication">Medications</span>
              )}
              {child.specialNeeds && (
                <span className="tag special-needs">Special Needs</span>
              )}
            </div>
          </div>
        </div>
        
        <div className="attendance-stats">
          <div className="attendance-card">
            <div className="attendance-percentage">
              {getAttendanceStats().percentage}%
            </div>
            <div className="attendance-label">Attendance Rate</div>
            <div className="attendance-details">
              <span>{getAttendanceStats().present} days present</span>
              <span>{getAttendanceStats().absent} days absent</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="profile-tabs">
        <button 
          className={`tab-button ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          Overview
        </button>
        <button 
          className={`tab-button ${activeTab === 'activities' ? 'active' : ''}`}
          onClick={() => setActiveTab('activities')}
        >
          Activities
        </button>
        <button 
          className={`tab-button ${activeTab === 'attendance' ? 'active' : ''}`}
          onClick={() => setActiveTab('attendance')}
        >
          Attendance
        </button>
        <button 
          className={`tab-button ${activeTab === 'milestones' ? 'active' : ''}`}
          onClick={() => setActiveTab('milestones')}
        >
          Milestones
        </button>
        <button 
          className={`tab-button ${activeTab === 'health' ? 'active' : ''}`}
          onClick={() => setActiveTab('health')}
        >
          Health
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'overview' && <OverviewTab child={child} activities={getRecentActivities()} />}
        {activeTab === 'activities' && <ActivitiesTab activities={activities} />}
        {activeTab === 'attendance' && <AttendanceTab attendance={attendance} />}
        {activeTab === 'milestones' && <MilestonesTab milestones={milestones} />}
        {activeTab === 'health' && <HealthTab child={child} />}
      </div>
    </div>
  );
};

// Tab Components
const OverviewTab = ({ child, activities }) => (
  <div className="overview-tab">
    <div className="overview-grid">
      <div className="overview-card">
        <h3>Daily Routine</h3>
        <div className="routine-list">
          <div className="routine-item">
            <span className="routine-time">08:00 AM</span>
            <span className="routine-activity">Arrival & Free Play</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">09:00 AM</span>
            <span className="routine-activity">Morning Snack</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">10:00 AM</span>
            <span className="routine-activity">Learning Activity</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">12:00 PM</span>
            <span className="routine-activity">Lunch Time</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">01:00 PM</span>
            <span className="routine-activity">Nap Time</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">03:00 PM</span>
            <span className="routine-activity">Afternoon Activity</span>
          </div>
          <div className="routine-item">
            <span className="routine-time">04:00 PM</span>
            <span className="routine-activity">Pickup Time</span>
          </div>
        </div>
      </div>

      <div className="overview-card">
        <h3>Recent Activities</h3>
        <div className="recent-activities">
          {activities.map(activity => (
            <div key={activity._id} className="activity-item">
              <div className="activity-icon">{getActivityIcon(activity.type)}</div>
              <div className="activity-info">
                <strong>{activity.title}</strong>
                <span>{formatDate(activity.startTime)}</span>
              </div>
            </div>
          ))}
          {activities.length === 0 && (
            <p className="no-data">No recent activities</p>
          )}
        </div>
      </div>

      <div className="overview-card">
        <h3>Emergency Contacts</h3>
        <div className="contacts-list">
          {child.emergencyContacts && child.emergencyContacts.map((contact, index) => (
            <div key={index} className="contact-item">
              <strong>{contact.name}</strong>
              <span>{contact.relationship}</span>
              <span>{contact.phone}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const ActivitiesTab = ({ activities }) => (
  <div className="activities-tab">
    <div className="activities-list">
      {activities.map(activity => (
        <div key={activity._id} className="activity-card">
          <div className="activity-header">
            <span className="activity-type">{activity.type}</span>
            <span className="activity-date">{formatDate(activity.startTime)}</span>
          </div>
          <h4>{activity.title}</h4>
          <p>{activity.description}</p>
          {activity.learningObjectives && (
            <div className="learning-objectives">
              <strong>Learning Objectives:</strong>
              <ul>
                {activity.learningObjectives.map((obj, idx) => (
                  <li key={idx}>{obj}</li>
                ))}
              </ul>
            </div>
          )}
          {activity.notes && (
            <div className="activity-notes">
              <strong>Teacher Notes:</strong> {activity.notes}
            </div>
          )}
        </div>
      ))}
      {activities.length === 0 && (
        <p className="no-data">No activities recorded</p>
      )}
    </div>
  </div>
);

const AttendanceTab = ({ attendance }) => (
  <div className="attendance-tab">
    <div className="attendance-calendar">
      {attendance.map(record => (
        <div key={record._id} className={`attendance-day status-${record.status}`}>
          <span className="date">{formatDate(record.date)}</span>
          <span className="status">{record.status}</span>
          {record.checkIn && (
            <span className="check-in">In: {record.checkIn.time}</span>
          )}
          {record.checkOut && (
            <span className="check-out">Out: {record.checkOut.time}</span>
          )}
        </div>
      ))}
    </div>
  </div>
);

const MilestonesTab = ({ milestones }) => (
  <div className="milestones-tab">
    <div className="milestones-timeline">
      {milestones.map(milestone => (
        <div key={milestone._id} className="milestone-item">
          <div className="milestone-date">{formatDate(milestone.date)}</div>
          <div className="milestone-content">
            <h4>{milestone.title}</h4>
            <p>{milestone.description}</p>
            {milestone.notes && (
              <div className="milestone-notes">{milestone.notes}</div>
            )}
          </div>
        </div>
      ))}
      {milestones.length === 0 && (
        <p className="no-data">No milestones recorded</p>
      )}
    </div>
  </div>
);

const HealthTab = ({ child }) => (
  <div className="health-tab">
    <div className="health-grid">
      <div className="health-card">
        <h3>Medical Information</h3>
        <div className="health-info">
          <div className="info-item">
            <strong>Allergies:</strong>
            <span>{child.allergies?.join(', ') || 'None'}</span>
          </div>
          <div className="info-item">
            <strong>Medications:</strong>
            <span>{child.medications?.join(', ') || 'None'}</span>
          </div>
          <div className="info-item">
            <strong>Special Needs:</strong>
            <span>{child.specialNeeds || 'None'}</span>
          </div>
          <div className="info-item">
            <strong>Dietary Restrictions:</strong>
            <span>{child.dietaryRestrictions?.join(', ') || 'None'}</span>
          </div>
        </div>
      </div>

      <div className="health-card">
        <h3>Emergency Procedures</h3>
        <div className="emergency-info">
          <p>In case of emergency, please contact:</p>
          <ul>
            <li>Primary Physician: {child.primaryPhysician || 'Not specified'}</li>
            <li>Insurance: {child.insuranceInfo || 'Not specified'}</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
);

// Helper function
const getActivityIcon = (type) => {
  const icons = {
    meal: '🍽️',
    nap: '😴',
    play: '🎮',
    learning: '📚',
    art: '🎨',
    music: '🎵',
    outdoor: '🌳'
  };
  return icons[type] || '📝';
};

export default ChildProfile;