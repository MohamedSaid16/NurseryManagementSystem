import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  usersService  from '../../../services/users';
import Modal from '../../common/Modal/Modal';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import  ConfirmationModal  from '../../common/Modal/Modal';
import './ChildManagement.css';

const ChildManagement = () => {
  const [children, setChildren] = useState([]);
  const [parents, setParents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    birthDate: '',
    gender: '',
    parent: '',
    room: '',
    allergies: '',
    medicalConditions: '',
    emergencyContacts: [{ name: '', relationship: '', phone: '' }],
    status: 'active'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [childrenRes, parentsRes, employeesRes] = await Promise.all([
        childrenService.getAll(),
        usersService.getByRole('parent'),
        usersService.getByRole('employee')
      ]);
      
      setChildren(childrenRes.children || childrenRes);
      setParents(parentsRes.users || parentsRes);
      setEmployees(employeesRes.employees || employeesRes);
    } catch (error) {
      console.error('Error loading data:', error);
      alert('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (child) => {
    setSelectedChild(child);
    setFormData({
      firstName: child.firstName,
      lastName: child.lastName,
      birthDate: child.birthDate.split('T')[0],
      gender: child.gender,
      parent: child.parent._id,
      room: child.room,
      allergies: child.allergies?.join(', ') || '',
      medicalConditions: child.medicalConditions?.join(', ') || '',
      emergencyContacts: child.emergencyContacts?.length > 0 ? child.emergencyContacts : [{ name: '', relationship: '', phone: '' }],
      status: child.status
    });
    setShowModal(true);
  };

  const handleDelete = (child) => {
    setSelectedChild(child);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    try {
      await childrenService.delete(selectedChild._id);
      setChildren(children.filter(child => child._id !== selectedChild._id));
      alert('Child deleted successfully');
      setShowDeleteModal(false);
      setSelectedChild(null);
    } catch (error) {
      console.error('Error deleting child:', error);
      alert('Error deleting child');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const childData = {
        ...formData,
        allergies: formData.allergies.split(',').map(a => a.trim()).filter(a => a),
        medicalConditions: formData.medicalConditions.split(',').map(m => m.trim()).filter(m => m),
        emergencyContacts: formData.emergencyContacts.filter(contact => 
          contact.name && contact.relationship && contact.phone
        )
      };

      let result;
      if (selectedChild) {
        result = await childrenService.update(selectedChild._id, childData);
        setChildren(children.map(child => 
          child._id === selectedChild._id ? result : child
        ));
        alert('Child updated successfully');
      } else {
        result = await childrenService.create(childData);
        setChildren([...children, result]);
        alert('Child created successfully');
      }
      
      setShowModal(false);
      resetForm();
    } catch (error) {
      console.error('Error saving child:', error);
      alert('Error saving child');
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      birthDate: '',
      gender: '',
      parent: '',
      room: '',
      allergies: '',
      medicalConditions: '',
      emergencyContacts: [{ name: '', relationship: '', phone: '' }],
      status: 'active'
    });
    setSelectedChild(null);
  };

  const addEmergencyContact = () => {
    setFormData(prev => ({
      ...prev,
      emergencyContacts: [...prev.emergencyContacts, { name: '', relationship: '', phone: '' }]
    }));
  };

  const removeEmergencyContact = (index) => {
    setFormData(prev => ({
      ...prev,
      emergencyContacts: prev.emergencyContacts.filter((_, i) => i !== index)
    }));
  };

  const updateEmergencyContact = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      emergencyContacts: prev.emergencyContacts.map((contact, i) => 
        i === index ? { ...contact, [field]: value } : contact
      )
    }));
  };

  // Filter children based on search and status
  const filteredChildren = children.filter(child => {
    const matchesSearch = child.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         child.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         child.parent?.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || child.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { class: 'success', text: 'Active' },
      inactive: { class: 'secondary', text: 'Inactive' },
      waitlist: { class: 'warning', text: 'Waitlist' }
    };
    
    const config = statusConfig[status] || statusConfig.active;
    return <span className={`status-badge status-${config.class}`}>{config.text}</span>;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="child-management">
      <div className="page-header">
        <div className="header-content">
          <h1>Child Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Add New Child
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="filters-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search children by name or parent..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="filter-controls">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="form-control"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="waitlist">Waitlist</option>
          </select>
        </div>
      </div>

      {/* Children Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Room</th>
              <th>Parent</th>
              <th>Status</th>
              <th>Enrollment Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredChildren.map(child => (
              <tr key={child._id}>
                <td>
                  <div className="child-name">
                    <strong>{child.firstName} {child.lastName}</strong>
                  </div>
                </td>
                <td>{child.age} years</td>
                <td className="capitalize">{child.room}</td>
                <td>{child.parent?.name}</td>
                <td>{getStatusBadge(child.status)}</td>
                <td>{new Date(child.enrollmentDate).toLocaleDateString()}</td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn btn-sm btn-info"
                      onClick={() => handleEdit(child)}
                    >
                      Edit
                    </button>
                    <button 
                      className="btn btn-sm btn-secondary"
                      onClick={() => window.open(`/children/${child._id}`, '_blank')}
                    >
                      View
                    </button>
                    <button 
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(child)}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredChildren.length === 0 && (
          <div className="no-data">
            <p>No children found matching your criteria</p>
          </div>
        )}
      </div>

      {/* Add/Edit Child Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedChild ? 'Edit Child' : 'Add New Child'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="child-form">
          <div className="form-section">
            <h3>Basic Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">First Name *</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={formData.firstName}
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Last Name *</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={formData.lastName}
                  onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Birth Date *</label>
                <input 
                  type="date" 
                  className="form-control" 
                  value={formData.birthDate}
                  onChange={(e) => setFormData({...formData, birthDate: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Gender *</label>
                <select 
                  className="form-control"
                  value={formData.gender}
                  onChange={(e) => setFormData({...formData, gender: e.target.value})}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Enrollment Details</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Parent *</label>
                <select 
                  className="form-control"
                  value={formData.parent}
                  onChange={(e) => setFormData({...formData, parent: e.target.value})}
                  required
                >
                  <option value="">Select Parent</option>
                  {parents.map(parent => (
                    <option key={parent._id} value={parent._id}>
                      {parent.name} ({parent.email})
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Room *</label>
                <select 
                  className="form-control"
                  value={formData.room}
                  onChange={(e) => setFormData({...formData, room: e.target.value})}
                  required
                >
                  <option value="">Select Room</option>
                  <option value="infants">Infants</option>
                  <option value="toddlers">Toddlers</option>
                  <option value="preschool">Preschool</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select 
                  className="form-control"
                  value={formData.status}
                  onChange={(e) => setFormData({...formData, status: e.target.value})}
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="waitlist">Waitlist</option>
                </select>
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Medical Information</h3>
            <div className="form-group">
              <label className="form-label">Allergies</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.allergies}
                onChange={(e) => setFormData({...formData, allergies: e.target.value})}
                placeholder="Enter allergies separated by commas"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Medical Conditions</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.medicalConditions}
                onChange={(e) => setFormData({...formData, medicalConditions: e.target.value})}
                placeholder="Enter medical conditions separated by commas"
              />
            </div>
          </div>

          <div className="form-section">
            <div className="section-header">
              <h3>Emergency Contacts</h3>
              <button 
                type="button" 
                className="btn btn-sm btn-outline"
                onClick={addEmergencyContact}
              >
                Add Contact
              </button>
            </div>
            {formData.emergencyContacts.map((contact, index) => (
              <div key={index} className="emergency-contact">
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Name</label>
                    <input 
                      type="text"
                      className="form-control"
                      value={contact.name}
                      onChange={(e) => updateEmergencyContact(index, 'name', e.target.value)}
                      placeholder="Full name"
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Relationship</label>
                    <input 
                      type="text"
                      className="form-control"
                      value={contact.relationship}
                      onChange={(e) => updateEmergencyContact(index, 'relationship', e.target.value)}
                      placeholder="Father, Mother, etc."
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone</label>
                    <input 
                      type="tel"
                      className="form-control"
                      value={contact.phone}
                      onChange={(e) => updateEmergencyContact(index, 'phone', e.target.value)}
                      placeholder="Phone number"
                    />
                  </div>
                  {formData.emergencyContacts.length > 1 && (
                    <div className="form-group">
                      <label className="form-label">&nbsp;</label>
                      <button 
                        type="button"
                        className="btn btn-sm btn-danger remove-contact"
                        onClick={() => removeEmergencyContact(index)}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedChild ? 'Update' : 'Add'} Child
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setSelectedChild(null);
        }}
        onConfirm={confirmDelete}
        title="Delete Child"
        message={`Are you sure you want to delete ${selectedChild?.firstName} ${selectedChild?.lastName}? This action cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default ChildManagement;