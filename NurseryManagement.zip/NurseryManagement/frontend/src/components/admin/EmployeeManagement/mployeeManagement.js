import React, { useState, useEffect } from 'react';
import  employeesService  from '../../../services/employees';
import  usersService  from '../../../services/users';
import Modal from '../../common/Modal/Modal';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import  ConfirmationModal  from '../../common/Modal/Modal';
import './EmployeeManagement.css';

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'teacher',
    qualifications: '',
    certifications: '',
    salary: '',
    assignedRooms: [],
    emergencyContact: { name: '', relationship: '', phone: '' }
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      setLoading(true);
      const employeesRes = await employeesService.getAll();
      setEmployees(employeesRes.employees || employeesRes);
    } catch (error) {
      console.error('Error loading employees:', error);
      alert('Error loading employees data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (employee) => {
    setSelectedEmployee(employee);
    setFormData({
      name: employee.user?.name || '',
      email: employee.user?.email || '',
      phone: employee.user?.phone || '',
      role: employee.role,
      qualifications: employee.qualifications?.join(', ') || '',
      certifications: employee.certifications?.join(', ') || '',
      salary: employee.salary || '',
      assignedRooms: employee.assignedRooms || [],
      emergencyContact: employee.emergencyContact || { name: '', relationship: '', phone: '' }
    });
    setShowModal(true);
  };

  const handleDelete = (employee) => {
    setSelectedEmployee(employee);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    try {
      await employeesService.delete(selectedEmployee._id);
      setEmployees(employees.filter(emp => emp._id !== selectedEmployee._id));
      alert('Employee deleted successfully');
      setShowDeleteModal(false);
      setSelectedEmployee(null);
    } catch (error) {
      console.error('Error deleting employee:', error);
      alert('Error deleting employee');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const employeeData = {
        ...formData,
        qualifications: formData.qualifications.split(',').map(q => q.trim()).filter(q => q),
        certifications: formData.certifications.split(',').map(c => c.trim()).filter(c => c),
        salary: parseFloat(formData.salary) || 0
      };

      let result;
      if (selectedEmployee) {
        result = await employeesService.update(selectedEmployee._id, employeeData);
        setEmployees(employees.map(emp => 
          emp._id === selectedEmployee._id ? result : emp
        ));
        alert('Employee updated successfully');
      } else {
        result = await employeesService.create(employeeData);
        setEmployees([...employees, result]);
        alert('Employee created successfully');
      }
      
      setShowModal(false);
      resetForm();
    } catch (error) {
      console.error('Error saving employee:', error);
      alert('Error saving employee');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      role: 'teacher',
      qualifications: '',
      certifications: '',
      salary: '',
      assignedRooms: [],
      emergencyContact: { name: '', relationship: '', phone: '' }
    });
    setSelectedEmployee(null);
  };

  const handleRoomAssignment = (room) => {
    setFormData(prev => ({
      ...prev,
      assignedRooms: prev.assignedRooms.includes(room)
        ? prev.assignedRooms.filter(r => r !== room)
        : [...prev.assignedRooms, room]
    }));
  };

  const updateEmergencyContact = (field, value) => {
    setFormData(prev => ({
      ...prev,
      emergencyContact: { ...prev.emergencyContact, [field]: value }
    }));
  };

  // Filter employees
  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.user?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.user?.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || employee.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const getRoleBadge = (role) => {
    const roleConfig = {
      teacher: { class: 'primary', text: 'Teacher' },
      assistant: { class: 'info', text: 'Assistant' },
      caregiver: { class: 'success', text: 'Caregiver' },
      admin: { class: 'warning', text: 'Admin' }
    };
    
    const config = roleConfig[role] || roleConfig.teacher;
    return <span className={`status-badge status-${config.class}`}>{config.text}</span>;
  };

  const getStatusBadge = (isActive) => {
    return isActive ? 
      <span className="status-badge status-success">Active</span> :
      <span className="status-badge status-secondary">Inactive</span>;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="employee-management">
      <div className="page-header">
        <div className="header-content">
          <h1>Employee Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Add New Employee
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="filters-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search employees by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="filter-controls">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="form-control"
          >
            <option value="all">All Roles</option>
            <option value="teacher">Teacher</option>
            <option value="assistant">Assistant</option>
            <option value="caregiver">Caregiver</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>

      {/* Employees Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Employee</th>
              <th>Role</th>
              <th>Contact</th>
              <th>Assigned Rooms</th>
              <th>Status</th>
              <th>Hire Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.map(employee => (
              <tr key={employee._id}>
                <td>
                  <div className="employee-info">
                    <div className="employee-avatar">
                      {employee.user?.name?.charAt(0).toUpperCase() || 'E'}
                    </div>
                    <div className="employee-details">
                      <strong>{employee.user?.name}</strong>
                      <span className="employee-id">{employee.employeeId}</span>
                    </div>
                  </div>
                </td>
                <td>{getRoleBadge(employee.role)}</td>
                <td>
                  <div className="contact-info">
                    <span>{employee.user?.email}</span>
                    <span>{employee.user?.phone}</span>
                  </div>
                </td>
                <td>
                  <div className="rooms-list">
                    {employee.assignedRooms?.map(room => (
                      <span key={room} className="room-tag capitalize">{room}</span>
                    ))}
                  </div>
                </td>
                <td>{getStatusBadge(employee.isActive)}</td>
                <td>{new Date(employee.hireDate).toLocaleDateString()}</td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn btn-sm btn-info"
                      onClick={() => handleEdit(employee)}
                    >
                      Edit
                    </button>
                    <button 
                      className="btn btn-sm btn-secondary"
                      onClick={() => window.open(`/employees/${employee._id}`, '_blank')}
                    >
                      View
                    </button>
                    <button 
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(employee)}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredEmployees.length === 0 && (
          <div className="no-data">
            <p>No employees found matching your criteria</p>
          </div>
        )}
      </div>

      {/* Add/Edit Employee Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedEmployee ? 'Edit Employee' : 'Add New Employee'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="employee-form">
          <div className="form-section">
            <h3>Basic Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Full Name *</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input 
                  type="email" 
                  className="form-control" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input 
                  type="tel" 
                  className="form-control" 
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Role *</label>
                <select 
                  className="form-control"
                  value={formData.role}
                  onChange={(e) => setFormData({...formData, role: e.target.value})}
                  required
                >
                  <option value="teacher">Teacher</option>
                  <option value="assistant">Assistant</option>
                  <option value="caregiver">Caregiver</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Salary ($)</label>
                <input 
                  type="number" 
                  className="form-control" 
                  value={formData.salary}
                  onChange={(e) => setFormData({...formData, salary: e.target.value})}
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Qualifications & Certifications</h3>
            <div className="form-group">
              <label className="form-label">Qualifications</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.qualifications}
                onChange={(e) => setFormData({...formData, qualifications: e.target.value})}
                placeholder="Enter qualifications separated by commas"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Certifications</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.certifications}
                onChange={(e) => setFormData({...formData, certifications: e.target.value})}
                placeholder="Enter certifications separated by commas"
              />
            </div>
          </div>

          <div className="form-section">
            <h3>Room Assignments</h3>
            <div className="room-assignments">
              {['infants', 'toddlers', 'preschool', 'playground', 'art', 'music'].map(room => (
                <label key={room} className="room-checkbox">
                  <input
                    type="checkbox"
                    checked={formData.assignedRooms.includes(room)}
                    onChange={() => handleRoomAssignment(room)}
                  />
                  <span className="checkmark"></span>
                  <span className="room-label capitalize">{room} Room</span>
                </label>
              ))}
            </div>
          </div>

          <div className="form-section">
            <h3>Emergency Contact</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Contact Name</label>
                <input 
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.name}
                  onChange={(e) => updateEmergencyContact('name', e.target.value)}
                  placeholder="Full name"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Relationship</label>
                <input 
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.relationship}
                  onChange={(e) => updateEmergencyContact('relationship', e.target.value)}
                  placeholder="Spouse, Parent, etc."
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input 
                  type="tel"
                  className="form-control"
                  value={formData.emergencyContact.phone}
                  onChange={(e) => updateEmergencyContact('phone', e.target.value)}
                  placeholder="Phone number"
                />
              </div>
            </div>
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedEmployee ? 'Update' : 'Add'} Employee
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setSelectedEmployee(null);
        }}
        onConfirm={confirmDelete}
        title="Delete Employee"
        message={`Are you sure you want to delete ${selectedEmployee?.user?.name}? This action cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default EmployeeManagement;