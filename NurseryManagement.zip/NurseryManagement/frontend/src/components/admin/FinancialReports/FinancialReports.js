import React, { useState, useEffect } from 'react';
import  paymentsService  from '../../../services/payments';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './FinancialReports.css';

const FinancialReports = () => {
  const [reports, setReports] = useState([]);
  const [timeRange, setTimeRange] = useState('monthly');
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    totalRevenue: 0,
    totalExpenses: 0,
    netProfit: 0,
    pendingPayments: 0
  });

  useEffect(() => {
    loadFinancialData();
  }, [timeRange]);

  const loadFinancialData = async () => {
    try {
      setLoading(true);
      
      // Mock data - replace with actual API calls
      const financialData = {
        monthly: [
          { period: 'January 2024', revenue: 12500, expenses: 8500, profit: 4000 },
          { period: 'February 2024', revenue: 13200, expenses: 8200, profit: 5000 },
          { period: 'March 2024', revenue: 14100, expenses: 8800, profit: 5300 },
          { period: 'April 2024', revenue: 12800, expenses: 7900, profit: 4900 },
          { period: 'May 2024', revenue: 13500, expenses: 8100, profit: 5400 }
        ],
        quarterly: [
          { period: 'Q1 2024', revenue: 39800, expenses: 25500, profit: 14300 },
          { period: 'Q2 2024', revenue: 0, expenses: 0, profit: 0 }
        ],
        yearly: [
          { period: '2023', revenue: 145000, expenses: 98000, profit: 47000 },
          { period: '2024', revenue: 0, expenses: 0, profit: 0 }
        ]
      };

      setReports(financialData[timeRange] || financialData.monthly);
      
      // Calculate summary
      const currentData = financialData[timeRange] || financialData.monthly;
      const totalRevenue = currentData.reduce((sum, item) => sum + item.revenue, 0);
      const totalExpenses = currentData.reduce((sum, item) => sum + item.expenses, 0);
      
      setSummary({
        totalRevenue,
        totalExpenses,
        netProfit: totalRevenue - totalExpenses,
        pendingPayments: 5 // Mock data
      });

    } catch (error) {
      console.error('Error loading financial data:', error);
      alert('Error loading financial reports');
    } finally {
      setLoading(false);
    }
  };

  const exportReport = () => {
    // Implement export functionality
    alert(`Exporting ${timeRange} report...`);
  };

  const getProfitMargin = (revenue, profit) => {
    return revenue > 0 ? ((profit / revenue) * 100).toFixed(1) : 0;
  };

  const getTrendIndicator = (current, previous) => {
    if (current > previous) return { class: 'positive', text: '↑' };
    if (current < previous) return { class: 'negative', text: '↓' };
    return { class: 'neutral', text: '→' };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="financial-reports">
      <div className="page-header">
        <div className="header-content">
          <h1>Financial Reports</h1>
          <div className="header-actions">
            <select 
              value={timeRange} 
              onChange={(e) => setTimeRange(e.target.value)}
              className="form-control"
            >
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="yearly">Yearly</option>
            </select>
            <button className="btn btn-primary" onClick={exportReport}>
              Export Report
            </button>
          </div>
        </div>
      </div>

      {/* Financial Summary */}
      <div className="financial-summary">
        <div className="summary-card revenue">
          <div className="summary-icon">💰</div>
          <div className="summary-content">
            <h3>${summary.totalRevenue.toLocaleString()}</h3>
            <p>Total Revenue</p>
            <span className="trend positive">+12% from last period</span>
          </div>
        </div>

        <div className="summary-card expenses">
          <div className="summary-icon">📊</div>
          <div className="summary-content">
            <h3>${summary.totalExpenses.toLocaleString()}</h3>
            <p>Total Expenses</p>
            <span className="trend warning">+8% from last period</span>
          </div>
        </div>

        <div className="summary-card profit">
          <div className="summary-icon">📈</div>
          <div className="summary-content">
            <h3>${summary.netProfit.toLocaleString()}</h3>
            <p>Net Profit</p>
            <span className="trend positive">+15% from last period</span>
          </div>
        </div>

        <div className="summary-card pending">
          <div className="summary-icon">⏳</div>
          <div className="summary-content">
            <h3>{summary.pendingPayments}</h3>
            <p>Pending Payments</p>
            <span className="trend warning">Requires attention</span>
          </div>
        </div>
      </div>

      {/* Financial Reports Table */}
      <div className="reports-section">
        <div className="section-header">
          <h2>Detailed Financial Report</h2>
          <span className="report-period">
            {timeRange.charAt(0).toUpperCase() + timeRange.slice(1)} View
          </span>
        </div>

        <div className="table-container">
          <table className="financial-table">
            <thead>
              <tr>
                <th>Period</th>
                <th>Revenue</th>
                <th>Expenses</th>
                <th>Profit</th>
                <th>Profit Margin</th>
                <th>Trend</th>
              </tr>
            </thead>
            <tbody>
              {reports.map((report, index) => {
                const profitMargin = getProfitMargin(report.revenue, report.profit);
                const previousReport = reports[index - 1];
                const trend = previousReport ? 
                  getTrendIndicator(report.profit, previousReport.profit) : 
                  { class: 'neutral', text: '→' };

                return (
                  <tr key={report.period}>
                    <td className="period">{report.period}</td>
                    <td className="revenue">${report.revenue.toLocaleString()}</td>
                    <td className="expenses">${report.expenses.toLocaleString()}</td>
                    <td className="profit">${report.profit.toLocaleString()}</td>
                    <td className="margin">{profitMargin}%</td>
                    <td className={`trend ${trend.class}`}>
                      <span className="trend-indicator">{trend.text}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Charts Section */}
      <div className="charts-section">
        <div className="chart-card">
          <h3>Revenue vs Expenses</h3>
          <div className="chart-placeholder">
            <div className="bar-chart">
              {reports.slice(0, 5).map((report, index) => (
                <div key={index} className="bar-container">
                  <div 
                    className="bar revenue-bar" 
                    style={{ height: `${(report.revenue / 15000) * 100}%` }}
                    title={`Revenue: $${report.revenue}`}
                  ></div>
                  <div 
                    className="bar expenses-bar" 
                    style={{ height: `${(report.expenses / 15000) * 100}%` }}
                    title={`Expenses: $${report.expenses}`}
                  ></div>
                  <span className="bar-label">
                    {timeRange === 'monthly' ? report.period.split(' ')[0].substring(0, 3) : 
                     timeRange === 'quarterly' ? report.period.split(' ')[0] : 
                     report.period}
                  </span>
                </div>
              ))}
            </div>
            <div className="chart-legend">
              <div className="legend-item">
                <span className="legend-color revenue"></span>
                <span>Revenue</span>
              </div>
              <div className="legend-item">
                <span className="legend-color expenses"></span>
                <span>Expenses</span>
              </div>
            </div>
          </div>
        </div>

        <div className="chart-card">
          <h3>Profit Trend</h3>
          <div className="chart-placeholder">
            <div className="line-chart">
              {reports.slice(0, 5).map((report, index) => (
                <div 
                  key={index}
                  className="data-point"
                  style={{ 
                    left: `${(index / (reports.length - 1)) * 100}%`,
                    bottom: `${(report.profit / 6000) * 100}%`
                  }}
                  title={`Profit: $${report.profit}`}
                >
                  <div className="point-value">${report.profit}</div>
                </div>
              ))}
              <div className="line"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="metrics-section">
        <h3>Key Financial Metrics</h3>
        <div className="metrics-grid">
          <div className="metric-card">
            <span className="metric-value">{getProfitMargin(summary.totalRevenue, summary.netProfit)}%</span>
            <span className="metric-label">Overall Profit Margin</span>
          </div>
          <div className="metric-card">
            <span className="metric-value">${(summary.totalRevenue / 5).toLocaleString()}</span>
            <span className="metric-label">Average Monthly Revenue</span>
          </div>
          <div className="metric-card">
            <span className="metric-value">68%</span>
            <span className="metric-label">Operating Margin</span>
          </div>
          <div className="metric-card">
            <span className="metric-value">24</span>
            <span className="metric-label">Days Receivable</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialReports;