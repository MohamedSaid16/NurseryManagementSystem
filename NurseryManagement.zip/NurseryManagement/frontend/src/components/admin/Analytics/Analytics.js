import React, { useState, useEffect } from 'react';
import  childrenService from '../../../services/children';
import  attendanceService  from '../../../services/attendance';
import  paymentsService  from '../../../services/payments';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './Analytics.css';

const Analytics = () => {
  const [analytics, setAnalytics] = useState({
    attendance: {},
    enrollment: {},
    financial: {},
    demographics: {}
  });
  const [timeRange, setTimeRange] = useState('monthly');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalyticsData();
  }, [timeRange]);

  const loadAnalyticsData = async () => {
    try {
      setLoading(true);
      
      // Mock analytics data - replace with actual API calls
      const mockAnalytics = {
        attendance: {
          rate: 92,
          trend: 'up',
          dailyAverage: 45,
          monthlyPeak: 48
        },
        enrollment: {
          total: 45,
          newThisMonth: 5,
          capacity: 50,
          waitlist: 8
        },
        financial: {
          revenue: 12500,
          expenses: 8500,
          profit: 4000,
          collectionRate: 94
        },
        demographics: {
          ageGroups: [
            { range: '1-2 years', count: 8, percentage: 18 },
            { range: '2-3 years', count: 15, percentage: 33 },
            { range: '3-4 years', count: 12, percentage: 27 },
            { range: '4-5 years', count: 10, percentage: 22 }
          ],
          gender: { male: 24, female: 21 },
          rooms: {
            infants: 8,
            toddlers: 15,
            preschool: 22
          }
        }
      };

      setAnalytics(mockAnalytics);
    } catch (error) {
      console.error('Error loading analytics data:', error);
      alert('Error loading analytics data');
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (trend) => {
    return trend === 'up' ? '📈' : trend === 'down' ? '📉' : '➡️';
  };

  const getTrendClass = (trend) => {
    return trend === 'up' ? 'positive' : trend === 'down' ? 'negative' : 'neutral';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="analytics">
      <div className="page-header">
        <div className="header-content">
          <h1>Analytics Dashboard</h1>
          <div className="header-actions">
            <select 
              value={timeRange} 
              onChange={(e) => setTimeRange(e.target.value)}
              className="form-control"
            >
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="yearly">Yearly</option>
            </select>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="key-metrics">
        <div className="metric-card primary">
          <div className="metric-icon">👥</div>
          <div className="metric-content">
            <h3>{analytics.enrollment.total}</h3>
            <p>Total Children</p>
            <span className="metric-trend positive">
              +{analytics.enrollment.newThisMonth} this month
            </span>
          </div>
        </div>

        <div className="metric-card success">
          <div className="metric-icon">✅</div>
          <div className="metric-content">
            <h3>{analytics.attendance.rate}%</h3>
            <p>Attendance Rate</p>
            <span className={`metric-trend ${getTrendClass(analytics.attendance.trend)}`}>
              {getTrendIcon(analytics.attendance.trend)} {analytics.attendance.trend === 'up' ? '2.5%' : '1.2%'}
            </span>
          </div>
        </div>

        <div className="metric-card warning">
          <div className="metric-icon">💰</div>
          <div className="metric-content">
            <h3>${analytics.financial.revenue.toLocaleString()}</h3>
            <p>Monthly Revenue</p>
            <span className="metric-trend positive">
              ↑ 12% from last month
            </span>
          </div>
        </div>

        <div className="metric-card info">
          <div className="metric-icon">📊</div>
          <div className="metric-content">
            <h3>{analytics.financial.collectionRate}%</h3>
            <p>Collection Rate</p>
            <span className="metric-trend positive">
              ↑ 3% improvement
            </span>
          </div>
        </div>
      </div>

      <div className="analytics-content">
        {/* Attendance Analytics */}
        <div className="analytics-section">
          <h2>Attendance Analytics</h2>
          <div className="charts-grid">
            <div className="chart-card">
              <h3>Daily Attendance Trend</h3>
              <div className="chart-container">
                <div className="attendance-chart">
                  {[85, 88, 92, 90, 94, 91, 89].map((rate, index) => (
                    <div key={index} className="attendance-bar">
                      <div 
                        className="bar-fill" 
                        style={{ height: `${rate}%` }}
                        title={`${rate}% attendance`}
                      ></div>
                      <span className="bar-label">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][index]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="chart-stats">
                <div className="stat-item">
                  <span className="stat-value">{analytics.attendance.dailyAverage}</span>
                  <span className="stat-label">Daily Average</span>
                </div>
                <div className="stat-item">
                  <span className="stat-value">{analytics.attendance.monthlyPeak}</span>
                  <span className="stat-label">Monthly Peak</span>
                </div>
              </div>
            </div>

            <div className="chart-card">
              <h3>Room-wise Attendance</h3>
              <div className="chart-container">
                <div className="room-attendance">
                  {Object.entries(analytics.demographics.rooms).map(([room, count]) => (
                    <div key={room} className="room-item">
                      <div className="room-info">
                        <span className="room-name capitalize">{room}</span>
                        <span className="room-count">{count} children</span>
                      </div>
                      <div className="attendance-rate">
                        <div className="rate-bar">
                          <div 
                            className="rate-fill" 
                            style={{ width: `${(count / analytics.enrollment.total) * 100}%` }}
                          ></div>
                        </div>
                        <span className="rate-percentage">
                          {Math.round((count / analytics.enrollment.total) * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Demographics */}
        <div className="analytics-section">
          <h2>Demographics</h2>
          <div className="charts-grid">
            <div className="chart-card">
              <h3>Age Distribution</h3>
              <div className="chart-container">
                <div className="age-distribution">
                  {analytics.demographics.ageGroups.map((group, index) => (
                    <div key={index} className="age-group">
                      <div className="group-info">
                        <span className="age-range">{group.range}</span>
                        <span className="age-count">{group.count} children</span>
                      </div>
                      <div className="percentage-bar">
                        <div 
                          className="percentage-fill" 
                          style={{ width: `${group.percentage}%` }}
                        ></div>
                        <span className="percentage-text">{group.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="chart-card">
              <h3>Gender Distribution</h3>
              <div className="chart-container">
                <div className="gender-chart">
                  <div className="gender-item male">
                    <div className="gender-icon">👦</div>
                    <div className="gender-info">
                      <span className="gender-count">{analytics.demographics.gender.male}</span>
                      <span className="gender-label">Boys</span>
                      <span className="gender-percentage">
                        {Math.round((analytics.demographics.gender.male / analytics.enrollment.total) * 100)}%
                      </span>
                    </div>
                  </div>
                  <div className="gender-item female">
                    <div className="gender-icon">👧</div>
                    <div className="gender-info">
                      <span className="gender-count">{analytics.demographics.gender.female}</span>
                      <span className="gender-label">Girls</span>
                      <span className="gender-percentage">
                        {Math.round((analytics.demographics.gender.female / analytics.enrollment.total) * 100)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Financial Analytics */}
        <div className="analytics-section">
          <h2>Financial Analytics</h2>
          <div className="charts-grid">
            <div className="chart-card">
              <h3>Revenue vs Expenses</h3>
              <div className="chart-container">
                <div className="financial-bars">
                  <div className="financial-item">
                    <span className="financial-label">Revenue</span>
                    <div className="financial-bar">
                      <div 
                        className="bar revenue-bar" 
                        style={{ width: `${(analytics.financial.revenue / 15000) * 100}%` }}
                      ></div>
                      <span className="financial-value">${analytics.financial.revenue.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="financial-item">
                    <span className="financial-label">Expenses</span>
                    <div className="financial-bar">
                      <div 
                        className="bar expenses-bar" 
                        style={{ width: `${(analytics.financial.expenses / 15000) * 100}%` }}
                      ></div>
                      <span className="financial-value">${analytics.financial.expenses.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="financial-item">
                    <span className="financial-label">Profit</span>
                    <div className="financial-bar">
                      <div 
                        className="bar profit-bar" 
                        style={{ width: `${(analytics.financial.profit / 15000) * 100}%` }}
                      ></div>
                      <span className="financial-value">${analytics.financial.profit.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="chart-card">
              <h3>Capacity Utilization</h3>
              <div className="chart-container">
                <div className="capacity-chart">
                  <div className="capacity-circle">
                    <div 
                      className="capacity-fill"
                      style={{ 
                        transform: `rotate(${(analytics.enrollment.total / analytics.enrollment.capacity) * 180}deg)` 
                      }}
                    ></div>
                    <div className="capacity-text">
                      <span className="capacity-percentage">
                        {Math.round((analytics.enrollment.total / analytics.enrollment.capacity) * 100)}%
                      </span>
                      <span className="capacity-label">Utilized</span>
                    </div>
                  </div>
                  <div className="capacity-info">
                    <div className="capacity-item">
                      <span className="capacity-value">{analytics.enrollment.total}</span>
                      <span className="capacity-desc">Current Enrollment</span>
                    </div>
                    <div className="capacity-item">
                      <span className="capacity-value">{analytics.enrollment.capacity}</span>
                      <span className="capacity-desc">Total Capacity</span>
                    </div>
                    <div className="capacity-item">
                      <span className="capacity-value">{analytics.enrollment.waitlist}</span>
                      <span className="capacity-desc">Waitlist</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Indicators */}
        <div className="analytics-section">
          <h2>Performance Indicators</h2>
          <div className="indicators-grid">
            <div className="indicator-card">
              <div className="indicator-icon">🎯</div>
              <div className="indicator-content">
                <h4>Staff-to-Child Ratio</h4>
                <div className="indicator-value">1:6</div>
                <span className="indicator-status excellent">Excellent</span>
              </div>
            </div>

            <div className="indicator-card">
              <div className="indicator-icon">⭐</div>
              <div className="indicator-content">
                <h4>Parent Satisfaction</h4>
                <div className="indicator-value">4.8/5</div>
                <span className="indicator-status excellent">Excellent</span>
              </div>
            </div>

            <div className="indicator-card">
              <div className="indicator-icon">📚</div>
              <div className="indicator-content">
                <h4>Program Quality</h4>
                <div className="indicator-value">94%</div>
                <span className="indicator-status good">Good</span>
              </div>
            </div>

            <div className="indicator-card">
              <div className="indicator-icon">🔄</div>
              <div className="indicator-content">
                <h4>Retention Rate</h4>
                <div className="indicator-value">92%</div>
                <span className="indicator-status excellent">Excellent</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;