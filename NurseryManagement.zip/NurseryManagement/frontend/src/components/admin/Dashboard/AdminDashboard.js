import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  employeesService  from '../../../services/employees';
import  paymentsService  from '../../../services/payments';
import  attendanceService  from '../../../services/attendance';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalChildren: 0,
    totalEmployees: 0,
    totalParents: 0,
    monthlyRevenue: 0,
    attendanceRate: 0,
    pendingPayments: 0
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      const [
        childrenRes,
        employeesRes,
        paymentsRes,
        attendanceRes
      ] = await Promise.all([
        childrenService.getAll(),
        employeesService.getAll(),
        paymentsService.getAll({ status: 'pending' }),
        attendanceService.getAll({ date: new Date().toISOString().split('T')[0] })
      ]);

      const children = childrenRes.children || childrenRes;
      const employees = employeesRes.employees || employeesRes;
      const pendingPayments = paymentsRes.payments || paymentsRes;
      const todayAttendance = attendanceRes.attendance || attendanceRes;

      // Calculate stats
      const presentCount = todayAttendance.filter(a => a.status === 'present').length;
      const attendanceRate = todayAttendance.length > 0 ? 
        Math.round((presentCount / todayAttendance.length) * 100) : 0;

      const monthlyRevenue = 12500; // This would come from your API

      setStats({
        totalChildren: children.length,
        totalEmployees: employees.length,
        totalParents: calculateUniqueParents(children),
        monthlyRevenue,
        attendanceRate,
        pendingPayments: pendingPayments.length
      });

      // Mock data for activities and events
      setRecentActivities([
        { id: 1, type: 'registration', message: 'New child registered - Liam Smith', time: '2 hours ago' },
        { id: 2, type: 'payment', message: 'Payment received from Johnson family', time: '4 hours ago' },
        { id: 3, type: 'attendance', message: 'Daily attendance completed', time: '6 hours ago' },
        { id: 4, type: 'activity', message: 'New activity planned: Arts & Crafts', time: '1 day ago' }
      ]);

      setUpcomingEvents([
        { id: 1, title: 'Parent-Teacher Meeting', date: 'Tomorrow', time: '3:00 PM' },
        { id: 2, title: 'Field Trip to Zoo', date: 'Next Friday', time: '9:00 AM' },
        { id: 3, title: 'Monthly Assessment', date: 'Next Week', time: 'All day' }
      ]);

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      alert('Error loading dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const calculateUniqueParents = (children) => {
    const parentIds = new Set(children.map(child => child.parent?._id).filter(Boolean));
    return parentIds.size;
  };

  const getActivityIcon = (type) => {
    const icons = {
      registration: '👶',
      payment: '💰',
      attendance: '✅',
      activity: '🎨'
    };
    return icons[type] || '📝';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h1>Admin Dashboard</h1>
        <p>Welcome back! Here's an overview of your nursery.</p>
      </div>

      {/* Statistics Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#3498db' }}>
            👶
          </div>
          <div className="stat-info">
            <h3>{stats.totalChildren}</h3>
            <p>Total Children</p>
            <span className="stat-trend positive">+5 this month</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#2ecc71' }}>
            👨‍💼
          </div>
          <div className="stat-info">
            <h3>{stats.totalEmployees}</h3>
            <p>Total Employees</p>
            <span className="stat-trend positive">+2 this month</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#e74c3c' }}>
            👨‍👩‍👧‍👦
          </div>
          <div className="stat-info">
            <h3>{stats.totalParents}</h3>
            <p>Active Parents</p>
            <span className="stat-trend positive">+3 this month</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#f39c12' }}>
            💰
          </div>
          <div className="stat-info">
            <h3>${stats.monthlyRevenue.toLocaleString()}</h3>
            <p>Monthly Revenue</p>
            <span className="stat-trend positive">+12% from last month</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#9b59b6' }}>
            ✅
          </div>
          <div className="stat-info">
            <h3>{stats.attendanceRate}%</h3>
            <p>Today's Attendance</p>
            <span className="stat-trend positive">Good attendance</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ backgroundColor: '#1abc9c' }}>
            📋
          </div>
          <div className="stat-info">
            <h3>{stats.pendingPayments}</h3>
            <p>Pending Payments</p>
            <span className="stat-trend warning">Requires attention</span>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        {/* Recent Activities */}
        <div className="content-section">
          <div className="section-header">
            <h2>Recent Activities</h2>
            <button className="btn btn-sm btn-outline">View All</button>
          </div>
          <div className="activities-list">
            {recentActivities.map(activity => (
              <div key={activity.id} className="activity-item">
                <div className="activity-icon">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="activity-details">
                  <p className="activity-message">{activity.message}</p>
                  <span className="activity-time">{activity.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="content-section">
          <div className="section-header">
            <h2>Upcoming Events</h2>
            <button className="btn btn-sm btn-outline">View Calendar</button>
          </div>
          <div className="events-list">
            {upcomingEvents.map(event => (
              <div key={event.id} className="event-item">
                <div className="event-date">
                  <span className="event-day">{event.date}</span>
                  <span className="event-time">{event.time}</span>
                </div>
                <div className="event-details">
                  <h4>{event.title}</h4>
                  <button className="btn btn-sm btn-primary">Details</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="content-section">
          <div className="section-header">
            <h2>Quick Actions</h2>
          </div>
          <div className="quick-actions-grid">
            <button className="quick-action-btn">
              <span className="action-icon">👶</span>
              <span>Add New Child</span>
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">👨‍💼</span>
              <span>Add Employee</span>
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">💰</span>
              <span>Generate Invoice</span>
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">📊</span>
              <span>View Reports</span>
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">📅</span>
              <span>Manage Schedule</span>
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">⚙️</span>
              <span>Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;