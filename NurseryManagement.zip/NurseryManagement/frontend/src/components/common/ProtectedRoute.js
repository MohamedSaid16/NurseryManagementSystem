import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import  useAuth  from '../../context/AuthContext';
import LoadingSpinner from './LoadingSpinner/LoadingSpinner';

const ProtectedRoute = ({ children, requiredRole, requiredPermissions = [] }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="full-page-loading">
        <LoadingSpinner size="large" text="Loading..." />
      </div>
    );
  }

  if (!user) {
    // Redirect to login page with return url
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (requiredRole && user.role !== requiredRole) {
    // Redirect to unauthorized page or dashboard based on user role
    const redirectPath = getUserDashboardPath(user.role);
    return (
      <Navigate 
        to={redirectPath} 
        state={{ 
          from: location,
          message: 'You do not have permission to access this page.'
        }} 
        replace 
      />
    );
  }

  if (requiredPermissions.length > 0) {
    const hasPermission = checkPermissions(user, requiredPermissions);
    if (!hasPermission) {
      const redirectPath = getUserDashboardPath(user.role);
      return (
        <Navigate 
          to={redirectPath} 
          state={{ 
            from: location,
            message: 'Insufficient permissions to access this resource.'
          }} 
          replace 
        />
      );
    }
  }

  // Check if user account is active
  if (user.status === 'inactive' || user.isActive === false) {
    return <Navigate to="/account-suspended" replace />;
  }

  return children;
};

// Helper function to get dashboard path based on user role
const getUserDashboardPath = (role) => {
  const paths = {
    admin: '/admin',
    employee: '/employee',
    parent: '/parent'
  };
  return paths[role] || '/dashboard';
};

// Helper function to check user permissions
const checkPermissions = (user, requiredPermissions) => {
  if (!user.permissions) return false;
  
  return requiredPermissions.every(permission => 
    user.permissions.includes(permission)
  );
};

export default ProtectedRoute;