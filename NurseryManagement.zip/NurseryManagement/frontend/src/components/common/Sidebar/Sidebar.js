import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import  useAuth  from '../../../context/AuthContext';
import './Sidebar.css';

const Sidebar = ({ items }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { user } = useAuth();
  const location = useLocation();

  const getRoleBasedItems = (items) => {
    if (!user) return items;
    
    // Filter items based on user role and permissions
    return items.filter(item => {
      if (item.roles && !item.roles.includes(user.role)) {
        return false;
      }
      return true;
    });
  };

  const filteredItems = getRoleBasedItems(items);

  const getItemIcon = (icon, label) => {
    if (icon) return icon;
    
    // Default icons based on label
    const defaultIcons = {
      'dashboard': '📊',
      'children': '👶',
      'employees': '👨‍💼',
      'parents': '👨‍👩‍👧‍👦',
      'finance': '💰',
      'reports': '📈',
      'activities': '🎮',
      'schedule': '📅',
      'attendance': '✅',
      'billing': '💳',
      'messages': '💬',
      'profile': '👤',
      'settings': '⚙️'
    };
    
    return defaultIcons[label.toLowerCase()] || '📄';
  };

  return (
    <aside className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        <button 
          className="sidebar-toggle"
          onClick={() => setIsCollapsed(!isCollapsed)}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <span className="toggle-icon">
            {isCollapsed ? '➡️' : '⬅️'}
          </span>
        </button>
        {!isCollapsed && (
          <div className="sidebar-title">
            <span>Navigation</span>
          </div>
        )}
      </div>

      <nav className="sidebar-nav">
        <ul>
          {filteredItems.map((item, index) => (
            <li key={index}>
              <NavLink 
                to={item.path} 
                className={({ isActive }) => 
                  `sidebar-link ${isActive ? 'active' : ''}`
                }
                title={isCollapsed ? item.label : ''}
              >
                <span className="sidebar-icon">
                  {getItemIcon(item.icon, item.label)}
                </span>
                {!isCollapsed && (
                  <span className="sidebar-label">{item.label}</span>
                )}
                {item.badge && !isCollapsed && (
                  <span className="sidebar-badge">{item.badge}</span>
                )}
              </NavLink>
              
              {/* Submenu items */}
              {item.subItems && !isCollapsed && (
                <ul className="sidebar-submenu">
                  {item.subItems.map((subItem, subIndex) => (
                    <li key={subIndex}>
                      <NavLink 
                        to={subItem.path}
                        className={({ isActive }) => 
                          `sidebar-sub-link ${isActive ? 'active' : ''}`
                        }
                      >
                        <span className="submenu-icon">•</span>
                        <span className="submenu-label">{subItem.label}</span>
                        {subItem.badge && (
                          <span className="sidebar-badge">{subItem.badge}</span>
                        )}
                      </NavLink>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* Sidebar Footer */}
      {!isCollapsed && (
        <div className="sidebar-footer">
          <div className="user-quick-info">
            <div className="user-avatar-small">
              {user?.profileImage ? (
                <img src={user.profileImage} alt={user.name} />
              ) : (
                <span className="user-initials-small">
                  {user?.name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                </span>
              )}
            </div>
            <div className="user-details">
              <span className="user-name-small">{user?.name}</span>
              <span className="user-role-small">
                {user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)}
              </span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;