import React, { useState } from 'react';
import useAuth  from '../../../context/AuthContext';
import './Header.css';

const Header = () => {
  const { user, logout } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleLogout = () => {
    logout();
  };

  const getRoleDisplayName = (role) => {
    const roleNames = {
      admin: 'Administrator',
      employee: 'Staff Member',
      parent: 'Parent'
    };
    return roleNames[role] || role;
  };

  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="header">
      <div className="header-content">
        <div className="header-left">
          <div className="header-logo">
            <span className="logo-icon">🏫</span>
            <h1>Nursery Management</h1>
          </div>
        </div>

        <div className="header-right">
          <div className="header-actions">
            <button className="notification-btn">
              <span className="notification-icon">🔔</span>
              <span className="notification-badge">3</span>
            </button>
            
            <div className="user-menu">
              <button 
                className="user-profile-btn"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <div className="user-avatar">
                  {user?.profileImage ? (
                    <img src={user.profileImage} alt={user.name} />
                  ) : (
                    <span className="user-initials">
                      {getInitials(user?.name || 'User')}
                    </span>
                  )}
                </div>
                <div className="user-info">
                  <span className="user-name">{user?.name}</span>
                  <span className="user-role">{getRoleDisplayName(user?.role)}</span>
                </div>
                <span className="dropdown-arrow">▼</span>
              </button>

              {showUserMenu && (
                <div className="user-dropdown">
                  <div className="dropdown-section">
                    <div className="dropdown-item">
                      <span className="dropdown-icon">👤</span>
                      <span>My Profile</span>
                    </div>
                    <div className="dropdown-item">
                      <span className="dropdown-icon">⚙️</span>
                      <span>Settings</span>
                    </div>
                    <div className="dropdown-item">
                      <span className="dropdown-icon">🛎️</span>
                      <span>Notifications</span>
                    </div>
                  </div>
                  <div className="dropdown-divider"></div>
                  <div className="dropdown-section">
                    <button 
                      className="dropdown-item logout-btn"
                      onClick={handleLogout}
                    >
                      <span className="dropdown-icon">🚪</span>
                      <span>Logout</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Overlay to close dropdown when clicking outside */}
      {showUserMenu && (
        <div 
          className="dropdown-overlay"
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </header>
  );
};

export default Header;