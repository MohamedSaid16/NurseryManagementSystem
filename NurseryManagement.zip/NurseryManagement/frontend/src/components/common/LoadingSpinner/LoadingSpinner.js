import React from 'react';
import './LoadingSpinner.css';

const LoadingSpinner = ({ 
  size = 'medium', 
  color = 'primary',
  text = '',
  overlay = false 
}) => {
  const getSizeClass = () => {
    const sizes = {
      small: 'spinner-small',
      medium: 'spinner-medium',
      large: 'spinner-large',
      xlarge: 'spinner-xlarge'
    };
    return sizes[size] || sizes.medium;
  };

  const getColorClass = () => {
    const colors = {
      primary: 'spinner-primary',
      secondary: 'spinner-secondary',
      white: 'spinner-white',
      success: 'spinner-success',
      warning: 'spinner-warning',
      danger: 'spinner-danger'
    };
    return colors[color] || colors.primary;
  };

  return (
    <div className={`loading-spinner ${overlay ? 'spinner-overlay' : ''}`}>
      <div className="spinner-container">
        <div className={`spinner ${getSizeClass()} ${getColorClass()}`}>
          <div className="spinner-ring"></div>
          <div className="spinner-ring"></div>
          <div className="spinner-ring"></div>
          <div className="spinner-ring"></div>
        </div>
        {text && (
          <div className="spinner-text">
            {text}
          </div>
        )}
      </div>
    </div>
  );
};

// Inline spinner for buttons and small spaces
export const InlineSpinner = ({ size = 'small', color = 'white' }) => {
  return (
    <div className={`inline-spinner spinner-${size} spinner-${color}`}>
      <div className="spinner-dot"></div>
      <div className="spinner-dot"></div>
      <div className="spinner-dot"></div>
    </div>
  );
};

// Page loading spinner with message
export const PageSpinner = ({ message = 'Loading...' }) => {
  return (
    <div className="page-spinner">
      <div className="page-spinner-content">
        <LoadingSpinner size="xlarge" color="primary" />
        <div className="page-spinner-message">
          {message}
        </div>
      </div>
    </div>
  );
};

export default LoadingSpinner;