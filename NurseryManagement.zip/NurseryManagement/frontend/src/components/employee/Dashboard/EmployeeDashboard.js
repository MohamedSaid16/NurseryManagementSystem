import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  activitiesService  from '../../../services/activities';
import  attendanceService  from '../../../services/attendance';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './EmployeeDashboard.css';

const EmployeeDashboard = () => {
  const [assignedChildren, setAssignedChildren] = useState([]);
  const [todaysActivities, setTodaysActivities] = useState([]);
  const [todaysAttendance, setTodaysAttendance] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const today = new Date().toISOString().split('T')[0];
      
      const [childrenRes, activitiesRes, attendanceRes] = await Promise.all([
        childrenService.getAll(),
        activitiesService.getToday(),
        attendanceService.getByDate(today)
      ]);

      // For demo purposes, assign first 5 children to this employee
      const children = childrenRes.children || childrenRes;
      setAssignedChildren(children.slice(0, 5));
      
      setTodaysActivities(activitiesRes.activities || []);
      setTodaysAttendance(attendanceRes.attendance || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      alert('Error loading dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getChildStatus = (childId) => {
    const attendance = todaysAttendance.find(a => a.child._id === childId);
    return attendance ? attendance.status : 'not-checked';
  };

  const getStatusIcon = (status) => {
    const icons = {
      present: '✅',
      absent: '❌',
      late: '⏰',
      excused: '📝',
      'not-checked': '⏳'
    };
    return icons[status] || '❓';
  };

  const getStatusColor = (status) => {
    const colors = {
      present: 'present',
      absent: 'absent',
      late: 'late',
      excused: 'excused',
      'not-checked': 'pending'
    };
    return colors[status] || 'pending';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="employee-dashboard">
      <div className="dashboard-header">
        <h1>Employee Dashboard</h1>
        <p>Welcome back! Here's your schedule for today.</p>
      </div>

      {/* Quick Stats */}
      <div className="quick-stats">
        <div className="stat-card">
          <div className="stat-icon">👶</div>
          <div className="stat-content">
            <h3>{assignedChildren.length}</h3>
            <p>Assigned Children</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <h3>
              {todaysAttendance.filter(a => a.status === 'present').length}
            </h3>
            <p>Present Today</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">🎯</div>
          <div className="stat-content">
            <h3>{todaysActivities.length}</h3>
            <p>Today's Activities</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <h3>92%</h3>
            <p>Attendance Rate</p>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        {/* Assigned Children */}
        <div className="content-section">
          <div className="section-header">
            <h2>My Assigned Children</h2>
            <button className="btn btn-sm btn-outline">View All</button>
          </div>
          <div className="children-grid">
            {assignedChildren.map(child => {
              const status = getChildStatus(child._id);
              return (
                <div key={child._id} className="child-card">
                  <div className="child-avatar">
                    {child.gender === 'male' ? '👦' : '👧'}
                  </div>
                  <div className="child-info">
                    <h4>{child.firstName} {child.lastName}</h4>
                    <p>Age: {child.age} years</p>
                    <p className="room-info">Room: <span className="capitalize">{child.room}</span></p>
                    {child.allergies && child.allergies.length > 0 && (
                      <p className="allergy-warning">⚠️ Allergies: {child.allergies.join(', ')}</p>
                    )}
                  </div>
                  <div className="child-status">
                    <span className={`status-badge status-${getStatusColor(status)}`}>
                      <span className="status-icon">{getStatusIcon(status)}</span>
                      <span className="status-text">{status.replace('-', ' ')}</span>
                    </span>
                    <div className="child-actions">
                      <button className="btn btn-sm btn-primary">Log Activity</button>
                      <button className="btn btn-sm btn-secondary">View Profile</button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="content-section">
          <div className="section-header">
            <h2>Today's Schedule</h2>
            <button className="btn btn-sm btn-outline">Full Schedule</button>
          </div>
          <div className="schedule-list">
            {[
              { time: '08:00 AM', activity: 'Arrival & Welcome', room: 'Main Hall', status: 'completed' },
              { time: '09:00 AM', activity: 'Circle Time', room: 'Main Room', status: 'completed' },
              { time: '10:30 AM', activity: 'Arts & Crafts', room: 'Art Room', status: 'in-progress' },
              { time: '12:00 PM', activity: 'Lunch Time', room: 'Dining Area', status: 'upcoming' },
              { time: '02:00 PM', activity: 'Outdoor Play', room: 'Playground', status: 'upcoming' },
              { time: '04:00 PM', activity: 'Story Time', room: 'Reading Corner', status: 'upcoming' }
            ].map((item, index) => (
              <div key={index} className={`schedule-item ${item.status}`}>
                <div className="schedule-time">
                  <span className="time">{item.time}</span>
                </div>
                <div className="schedule-details">
                  <h4>{item.activity}</h4>
                  <p>{item.room}</p>
                </div>
                <div className="schedule-status">
                  <span className={`status-dot ${item.status}`}></span>
                  <span className="status-text">
                    {item.status === 'completed' ? 'Completed' : 
                     item.status === 'in-progress' ? 'In Progress' : 'Upcoming'}
                  </span>
                </div>
                <div className="schedule-actions">
                  {item.status === 'upcoming' && (
                    <button className="btn btn-sm btn-primary">Start</button>
                  )}
                  {item.status === 'in-progress' && (
                    <button className="btn btn-sm btn-warning">End</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="content-section">
          <div className="section-header">
            <h2>Quick Actions</h2>
          </div>
          <div className="quick-actions-grid">
            <button className="action-btn">
              <span className="action-icon">✅</span>
              <span>Take Attendance</span>
            </button>
            <button className="action-btn">
              <span className="action-icon">📝</span>
              <span>Log Activity</span>
            </button>
            <button className="action-btn">
              <span className="action-icon">🍽️</span>
              <span>Meal Tracking</span>
            </button>
            <button className="action-btn">
              <span className="action-icon">💤</span>
              <span>Nap Time</span>
            </button>
            <button className="action-btn">
              <span className="action-icon">📸</span>
              <span>Add Photos</span>
            </button>
            <button className="action-btn">
              <span className="action-icon">📋</span>
              <span>Incident Report</span>
            </button>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="content-section">
          <div className="section-header">
            <h2>Recent Activities</h2>
            <button className="btn btn-sm btn-outline">View All</button>
          </div>
          <div className="activities-list">
            {todaysActivities.slice(0, 3).map(activity => (
              <div key={activity._id} className="activity-item">
                <div className="activity-icon">
                  {activity.type === 'meal' ? '🍽️' : 
                   activity.type === 'nap' ? '💤' : 
                   activity.type === 'play' ? '🎮' : 
                   activity.type === 'learning' ? '📚' : '⚠️'}
                </div>
                <div className="activity-details">
                  <h4>{activity.title}</h4>
                  <p>{activity.description}</p>
                  <span className="activity-time">
                    {new Date(activity.startTime).toLocaleTimeString([], { 
                      hour: '2-digit', minute: '2-digit' 
                    })} - {activity.room}
                  </span>
                </div>
                <div className="activity-participation">
                  <span className="participation-count">
                    {activity.children?.length || 0} children
                  </span>
                </div>
              </div>
            ))}
            {todaysActivities.length === 0 && (
              <div className="no-activities">
                <p>No activities logged today</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;