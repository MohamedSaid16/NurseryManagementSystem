import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  attendanceService  from '../../../services/attendance';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './Attendance.css';

const Attendance = () => {
  const [children, setChildren] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [bulkAction, setBulkAction] = useState('');

  useEffect(() => {
    loadAttendanceData();
  }, [selectedDate]);

  const loadAttendanceData = async () => {
    try {
      setLoading(true);
      const [childrenRes, attendanceRes] = await Promise.all([
        childrenService.getAll(),
        attendanceService.getByDate(selectedDate)
      ]);
      
      setChildren(childrenRes.children || childrenRes);
      
      // Create attendance records for children without one for today
      const attendanceMap = new Map();
      (attendanceRes.attendance || attendanceRes).forEach(record => {
        attendanceMap.set(record.child._id, record);
      });

      const todayAttendance = children.map(child => {
        const existingRecord = attendanceMap.get(child._id);
        return existingRecord || {
          child: child,
          date: selectedDate,
          status: 'absent',
          checkIn: null,
          checkOut: null
        };
      });

      setAttendance(todayAttendance);
    } catch (error) {
      console.error('Error loading attendance data:', error);
      alert('Error loading attendance data');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (childId, newStatus) => {
    try {
      setSaving(true);
      const childRecord = attendance.find(a => a.child._id === childId);
      const now = new Date().toTimeString().split(' ')[0].substring(0, 5);

      let updateData = {
        child: childId,
        date: selectedDate,
        status: newStatus
      };

      if (newStatus === 'present' && !childRecord.checkIn) {
        updateData.checkIn = {
          time: now,
          recordedBy: JSON.parse(localStorage.getItem('user'))._id,
          notes: 'Checked in by employee'
        };
      } else if (newStatus === 'absent' && childRecord.checkIn) {
        updateData.checkIn = null;
        updateData.checkOut = null;
      }

      let result;
      if (childRecord._id) {
        result = await attendanceService.update(childRecord._id, updateData);
      } else {
        result = await attendanceService.create(updateData);
      }

      // Update local state
      setAttendance(prev => prev.map(record => 
        record.child._id === childId ? { ...record, ...updateData, ...result } : record
      ));

    } catch (error) {
      console.error('Error updating attendance:', error);
      alert('Error updating attendance');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckIn = async (childId) => {
    try {
      setSaving(true);
      const record = attendance.find(a => a.child._id === childId);
      const now = new Date().toTimeString().split(' ')[0].substring(0, 5);

      const updateData = {
        status: 'present',
        checkIn: {
          time: now,
          recordedBy: JSON.parse(localStorage.getItem('user'))._id,
          notes: 'Checked in by employee'
        }
      };

      let result;
      if (record._id) {
        result = await attendanceService.update(record._id, updateData);
      } else {
        result = await attendanceService.create({
          child: childId,
          date: selectedDate,
          ...updateData
        });
      }
      
      setAttendance(prev => prev.map(rec => 
        rec.child._id === childId ? { ...rec, ...updateData, ...result } : rec
      ));

    } catch (error) {
      console.error('Error checking in:', error);
      alert('Error during check-in');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckOut = async (childId) => {
    try {
      setSaving(true);
      const record = attendance.find(a => a.child._id === childId);
      const now = new Date().toTimeString().split(' ')[0].substring(0, 5);

      const updateData = {
        checkOut: {
          time: now,
          recordedBy: JSON.parse(localStorage.getItem('user'))._id,
          notes: 'Checked out by employee'
        }
      };

      const result = await attendanceService.update(record._id, updateData);
      
      setAttendance(prev => prev.map(rec => 
        rec.child._id === childId ? { ...rec, ...updateData, ...result } : rec
      ));

    } catch (error) {
      console.error('Error checking out:', error);
      alert('Error during check-out');
    } finally {
      setSaving(false);
    }
  };

  const handleBulkAction = () => {
    if (!bulkAction) {
      alert('Please select a bulk action');
      return;
    }

    attendance.forEach(record => {
      if (record.status !== bulkAction) {
        handleStatusChange(record.child._id, bulkAction);
      }
    });
    
    setBulkAction('');
    alert(`Bulk action applied: ${bulkAction}`);
  };

  const getStatusStats = () => {
    const stats = {
      present: attendance.filter(a => a.status === 'present').length,
      absent: attendance.filter(a => a.status === 'absent').length,
      late: attendance.filter(a => a.status === 'late').length,
      excused: attendance.filter(a => a.status === 'excused').length
    };
    stats.total = attendance.length;
    stats.attendanceRate = stats.total > 0 ? Math.round((stats.present / stats.total) * 100) : 0;
    return stats;
  };

  const getStatusIcon = (status) => {
    const icons = {
      present: '✅',
      absent: '❌',
      late: '⏰',
      excused: '📝'
    };
    return icons[status] || '❓';
  };

  const stats = getStatusStats();

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="attendance">
      <div className="page-header">
        <div className="header-content">
          <h1>Attendance Management</h1>
          <div className="header-actions">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="form-control"
            />
            <button 
              className="btn btn-secondary"
              onClick={loadAttendanceData}
              disabled={saving}
            >
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Attendance Summary */}
      <div className="attendance-summary">
        <div className="summary-card">
          <div className="summary-icon present">✅</div>
          <div className="summary-content">
            <h3>{stats.present}</h3>
            <p>Present</p>
            <span className="summary-percentage">
              {Math.round((stats.present / stats.total) * 100)}%
            </span>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon absent">❌</div>
          <div className="summary-content">
            <h3>{stats.absent}</h3>
            <p>Absent</p>
            <span className="summary-percentage">
              {Math.round((stats.absent / stats.total) * 100)}%
            </span>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon late">⏰</div>
          <div className="summary-content">
            <h3>{stats.late}</h3>
            <p>Late</p>
            <span className="summary-percentage">
              {Math.round((stats.late / stats.total) * 100)}%
            </span>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon excused">📝</div>
          <div className="summary-content">
            <h3>{stats.excused}</h3>
            <p>Excused</p>
            <span className="summary-percentage">
              {Math.round((stats.excused / stats.total) * 100)}%
            </span>
          </div>
        </div>

        <div className="summary-card overall">
          <div className="summary-icon overall">📊</div>
          <div className="summary-content">
            <h3>{stats.attendanceRate}%</h3>
            <p>Overall Rate</p>
            <span className="summary-total">{stats.total} Total</span>
          </div>
        </div>
      </div>

      {/* Bulk Actions */}
      <div className="bulk-actions">
        <div className="bulk-controls">
          <select
            value={bulkAction}
            onChange={(e) => setBulkAction(e.target.value)}
            className="form-control"
            disabled={saving}
          >
            <option value="">Bulk Action...</option>
            <option value="present">Mark All Present</option>
            <option value="absent">Mark All Absent</option>
            <option value="late">Mark All Late</option>
            <option value="excused">Mark All Excused</option>
          </select>
          <button 
            className="btn btn-primary"
            onClick={handleBulkAction}
            disabled={saving || !bulkAction}
          >
            Apply to All
          </button>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="attendance-table-container">
        <table className="attendance-table">
          <thead>
            <tr>
              <th>Child Name</th>
              <th>Room</th>
              <th>Status</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {attendance.map(record => (
              <tr key={record.child._id} className={`attendance-row status-${record.status}`}>
                <td>
                  <div className="child-info">
                    <div className="child-avatar">
                      {record.child.gender === 'male' ? '👦' : '👧'}
                    </div>
                    <div className="child-details">
                      <strong>{record.child.firstName} {record.child.lastName}</strong>
                      <span>Age: {record.child.age} years</span>
                    </div>
                  </div>
                </td>
                <td className="capitalize">{record.child.room}</td>
                <td>
                  <select
                    value={record.status}
                    onChange={(e) => handleStatusChange(record.child._id, e.target.value)}
                    className={`status-select status-${record.status}`}
                    disabled={saving}
                  >
                    <option value="present">Present</option>
                    <option value="absent">Absent</option>
                    <option value="late">Late</option>
                    <option value="excused">Excused</option>
                  </select>
                </td>
                <td>
                  {record.checkIn ? (
                    <div className="check-time in">
                      <span className="time">{record.checkIn.time}</span>
                      <span className="recorded-by">by {record.checkIn.recordedBy?.name || 'Staff'}</span>
                    </div>
                  ) : (
                    <button
                      className="btn btn-sm btn-success"
                      onClick={() => handleCheckIn(record.child._id)}
                      disabled={saving || record.status === 'present'}
                    >
                      Check In
                    </button>
                  )}
                </td>
                <td>
                  {record.checkOut ? (
                    <div className="check-time out">
                      <span className="time">{record.checkOut.time}</span>
                      <span className="recorded-by">by {record.checkOut.recordedBy?.name || 'Staff'}</span>
                    </div>
                  ) : record.status === 'present' ? (
                    <button
                      className="btn btn-sm btn-warning"
                      onClick={() => handleCheckOut(record.child._id)}
                      disabled={saving}
                    >
                      Check Out
                    </button>
                  ) : (
                    <span className="check-time missing">-</span>
                  )}
                </td>
                <td>
                  <div className="quick-actions">
                    <button 
                      className="btn btn-sm btn-info"
                      onClick={() => handleStatusChange(record.child._id, 'present')}
                      disabled={saving || record.status === 'present'}
                      title="Mark Present"
                    >
                      ✅
                    </button>
                    <button 
                      className="btn btn-sm btn-secondary"
                      onClick={() => handleStatusChange(record.child._id, 'absent')}
                      disabled={saving || record.status === 'absent'}
                      title="Mark Absent"
                    >
                      ❌
                    </button>
                    <button 
                      className="btn btn-sm btn-warning"
                      onClick={() => handleStatusChange(record.child._id, 'late')}
                      disabled={saving || record.status === 'late'}
                      title="Mark Late"
                    >
                      ⏰
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Daily Summary */}
      <div className="daily-summary">
        <h3>Daily Summary - {new Date(selectedDate).toLocaleDateString()}</h3>
        <div className="summary-grid">
          <div className="summary-item">
            <span className="label">Total Children:</span>
            <span className="value">{stats.total}</span>
          </div>
          <div className="summary-item">
            <span className="label">Attendance Rate:</span>
            <span className="value">{stats.attendanceRate}%</span>
          </div>
          <div className="summary-item">
            <span className="label">Present:</span>
            <span className="value present">{stats.present}</span>
          </div>
          <div className="summary-item">
            <span className="label">Absent:</span>
            <span className="value absent">{stats.absent}</span>
          </div>
          <div className="summary-item">
            <span className="label">Late Arrivals:</span>
            <span className="value late">{stats.late}</span>
          </div>
          <div className="summary-item">
            <span className="label">Excused:</span>
            <span className="value excused">{stats.excused}</span>
          </div>
        </div>
      </div>

      {saving && (
        <div className="saving-indicator">
          <LoadingSpinner size="small" />
          <span>Saving changes...</span>
        </div>
      )}
    </div>
  );
};

export default Attendance;