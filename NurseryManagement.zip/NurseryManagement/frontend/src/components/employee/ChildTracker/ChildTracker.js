import React, { useState, useEffect } from 'react';
import  childrenService  from '../../../services/children';
import  activitiesService  from '../../../services/activities';
import  attendanceService  from '../../../services/attendance';
import Modal from '../../common/Modal/Modal';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import './ChildTracker.css';

const ChildTracker = () => {
  const [children, setChildren] = useState([]);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);
  const [activityForm, setActivityForm] = useState({
    type: 'play',
    title: '',
    description: '',
    notes: '',
    duration: 30
  });
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadChildData();
  }, [selectedDate]);

  const loadChildData = async () => {
    try {
      setLoading(true);
      const [childrenRes, activitiesRes] = await Promise.all([
        childrenService.getAll(),
        activitiesService.getAll({ date: selectedDate })
      ]);

      setChildren(childrenRes.children || childrenRes);
      setActivities(activitiesRes.activities || activitiesRes);
    } catch (error) {
      console.error('Error loading child data:', error);
      alert('Error loading child tracker data');
    } finally {
      setLoading(false);
    }
  };

  const handleLogActivity = (child) => {
    setSelectedChild(child);
    setActivityForm({
      type: 'play',
      title: '',
      description: '',
      notes: '',
      duration: 30
    });
    setShowActivityModal(true);
  };

  const handleSubmitActivity = async (e) => {
    e.preventDefault();
    try {
      const activityData = {
        ...activityForm,
        children: [{ child: selectedChild._id, participation: 'good' }],
        room: selectedChild.room,
        startTime: new Date(),
        endTime: new Date(Date.now() + activityForm.duration * 60000)
      };

      await activitiesService.create(activityData);
      alert('Activity logged successfully!');
      setShowActivityModal(false);
      setSelectedChild(null);
      loadChildData(); // Refresh data
    } catch (error) {
      console.error('Error logging activity:', error);
      alert('Error logging activity');
    }
  };

  const handleQuickAction = async (childId, action) => {
    try {
      const now = new Date().toTimeString().split(' ')[0].substring(0, 5);
      
      switch (action) {
        case 'meal':
          await activitiesService.create({
            title: 'Meal Time',
            type: 'meal',
            description: 'Regular meal',
            children: [{ child: childId, participation: 'good' }],
            room: children.find(c => c._id === childId)?.room,
            startTime: new Date(),
            endTime: new Date(Date.now() + 30 * 60000),
            notes: `Meal recorded at ${now}`
          });
          alert('Meal logged successfully!');
          break;

        case 'nap':
          await activitiesService.create({
            title: 'Nap Time',
            type: 'nap',
            description: 'Scheduled nap',
            children: [{ child: childId, participation: 'good' }],
            room: children.find(c => c._id === childId)?.room,
            startTime: new Date(),
            endTime: new Date(Date.now() + 60 * 60000),
            notes: `Nap started at ${now}`
          });
          alert('Nap logged successfully!');
          break;

        case 'diaper':
          await activitiesService.create({
            title: 'Diaper Change',
            type: 'incident',
            description: 'Regular diaper change',
            children: [{ child: childId, participation: 'good' }],
            room: children.find(c => c._id === childId)?.room,
            startTime: new Date(),
            endTime: new Date(),
            notes: `Diaper changed at ${now}`
          });
          alert('Diaper change logged!');
          break;
      }
      
      loadChildData(); // Refresh data
    } catch (error) {
      console.error('Error performing quick action:', error);
      alert('Error performing action');
    }
  };

  const getChildActivities = (childId) => {
    return activities.filter(activity => 
      activity.children?.some(c => c.child._id === childId)
    );
  };

  const getRecentActivity = (childId) => {
    const childActivities = getChildActivities(childId);
    return childActivities.length > 0 ? childActivities[0] : null;
  };

  const getActivityTypeIcon = (type) => {
    const icons = {
      meal: '🍽️',
      nap: '💤',
      play: '🎮',
      learning: '📚',
      incident: '⚠️'
    };
    return icons[type] || '📝';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="child-tracker">
      <div className="page-header">
        <div className="header-content">
          <h1>Child Tracker</h1>
          <div className="header-actions">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="form-control"
            />
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="tracker-summary">
        <div className="summary-card">
          <div className="summary-icon">👶</div>
          <div className="summary-content">
            <h3>{children.length}</h3>
            <p>Total Children</p>
          </div>
        </div>
        <div className="summary-card">
          <div className="summary-icon">📝</div>
          <div className="summary-content">
            <h3>{activities.length}</h3>
            <p>Activities Today</p>
          </div>
        </div>
        <div className="summary-card">
          <div className="summary-icon">🍽️</div>
          <div className="summary-content">
            <h3>{activities.filter(a => a.type === 'meal').length}</h3>
            <p>Meals Served</p>
          </div>
        </div>
        <div className="summary-card">
          <div className="summary-icon">💤</div>
          <div className="summary-content">
            <h3>{activities.filter(a => a.type === 'nap').length}</h3>
            <p>Naps Taken</p>
          </div>
        </div>
      </div>

      {/* Children Grid */}
      <div className="children-grid">
        {children.map(child => {
          const recentActivity = getRecentActivity(child._id);
          const childActivities = getChildActivities(child._id);

          return (
            <div key={child._id} className="child-tracker-card">
              <div className="child-header">
                <div className="child-avatar">
                  {child.gender === 'male' ? '👦' : '👧'}
                </div>
                <div className="child-info">
                  <h3>{child.firstName} {child.lastName}</h3>
                  <p>Age: {child.age} years | Room: <span className="capitalize">{child.room}</span></p>
                  {child.allergies && child.allergies.length > 0 && (
                    <div className="allergy-alert">
                      ⚠️ Allergies: {child.allergies.join(', ')}
                    </div>
                  )}
                </div>
              </div>

              <div className="child-stats">
                <div className="stat">
                  <span className="stat-label">Activities Today:</span>
                  <span className="stat-value">{childActivities.length}</span>
                </div>
                <div className="stat">
                  <span className="stat-label">Last Activity:</span>
                  <span className="stat-value">
                    {recentActivity ? (
                      <span className="recent-activity">
                        <span className="activity-icon">
                          {getActivityTypeIcon(recentActivity.type)}
                        </span>
                        {recentActivity.title}
                      </span>
                    ) : 'None'}
                  </span>
                </div>
              </div>

              <div className="quick-actions">
                <button 
                  className="action-btn meal"
                  onClick={() => handleQuickAction(child._id, 'meal')}
                  title="Log Meal"
                >
                  <span className="action-icon">🍽️</span>
                  <span>Meal</span>
                </button>
                <button 
                  className="action-btn nap"
                  onClick={() => handleQuickAction(child._id, 'nap')}
                  title="Log Nap"
                >
                  <span className="action-icon">💤</span>
                  <span>Nap</span>
                </button>
                <button 
                  className="action-btn diaper"
                  onClick={() => handleQuickAction(child._id, 'diaper')}
                  title="Log Diaper Change"
                >
                  <span className="action-icon">👶</span>
                  <span>Diaper</span>
                </button>
                <button 
                  className="action-btn custom"
                  onClick={() => handleLogActivity(child)}
                  title="Log Custom Activity"
                >
                  <span className="action-icon">📝</span>
                  <span>Custom</span>
                </button>
              </div>

              {/* Recent Activities */}
              {childActivities.length > 0 && (
                <div className="recent-activities">
                  <h4>Recent Activities</h4>
                  <div className="activities-list">
                    {childActivities.slice(0, 3).map(activity => (
                      <div key={activity._id} className="activity-item">
                        <span className="activity-type">
                          {getActivityTypeIcon(activity.type)}
                        </span>
                        <span className="activity-title">{activity.title}</span>
                        <span className="activity-time">
                          {new Date(activity.startTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Activity Log Modal */}
      <Modal
        isOpen={showActivityModal}
        onClose={() => {
          setShowActivityModal(false);
          setSelectedChild(null);
        }}
        title={`Log Activity - ${selectedChild?.firstName} ${selectedChild?.lastName}`}
      >
        <form onSubmit={handleSubmitActivity} className="activity-form">
          <div className="form-group">
            <label className="form-label">Activity Type</label>
            <select
              value={activityForm.type}
              onChange={(e) => setActivityForm({...activityForm, type: e.target.value})}
              className="form-control"
              required
            >
              <option value="play">Play</option>
              <option value="learning">Learning</option>
              <option value="meal">Meal</option>
              <option value="nap">Nap</option>
              <option value="incident">Incident</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Title</label>
            <input
              type="text"
              value={activityForm.title}
              onChange={(e) => setActivityForm({...activityForm, title: e.target.value})}
              className="form-control"
              placeholder="Enter activity title"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              value={activityForm.description}
              onChange={(e) => setActivityForm({...activityForm, description: e.target.value})}
              className="form-control"
              rows="3"
              placeholder="Describe the activity..."
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Duration (minutes)</label>
              <input
                type="number"
                value={activityForm.duration}
                onChange={(e) => setActivityForm({...activityForm, duration: parseInt(e.target.value)})}
                className="form-control"
                min="1"
                max="240"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Additional Notes</label>
            <textarea
              value={activityForm.notes}
              onChange={(e) => setActivityForm({...activityForm, notes: e.target.value})}
              className="form-control"
              rows="2"
              placeholder="Any additional observations..."
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowActivityModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Log Activity
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ChildTracker;