import React, { useState, useEffect } from 'react';
import activityService from '../../../services/activities';
import  childrenService  from '../../../services/children';
import Modal from '../../common/Modal/Modal';
import LoadingSpinner from '../../common/LoadingSpinner/LoadingSpinner';
import  ConfirmationModal  from '../../common/Modal/Modal';
import './ActivityLogger.css';

const ActivityLogger = () => {
  const [activities, setActivities] = useState([]);
  const [children, setChildren] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'play',
    children: [],
    room: '',
    startTime: '',
    endTime: '',
    materials: '',
    learningObjectives: '',
    notes: ''
  });
  const [filter, setFilter] = useState('all');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [activitiesRes, childrenRes] = await Promise.all([
       activityService.getAll({ date: selectedDate }),
        childrenService.getAll()
      ]);

      setActivities(activitiesRes.activities || activitiesRes);
      setChildren(childrenRes.children || childrenRes);
    } catch (error) {
      console.error('Error loading data:', error);
      alert('Error loading activities data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (activity) => {
    setSelectedActivity(activity);
    setFormData({
      title: activity.title,
      description: activity.description || '',
      type: activity.type,
      children: activity.children?.map(c => c.child._id) || [],
      room: activity.room,
      startTime: new Date(activity.startTime).toTimeString().split(' ')[0].substring(0, 5),
      endTime: new Date(activity.endTime).toTimeString().split(' ')[0].substring(0, 5),
      materials: activity.materials?.join(', ') || '',
      learningObjectives: activity.learningObjectives?.join(', ') || '',
      notes: activity.notes || ''
    });
    setShowModal(true);
  };

  const handleDelete = (activity) => {
    setSelectedActivity(activity);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    try {
      await activityService.delete(selectedActivity._id);
      setActivities(activities.filter(a => a._id !== selectedActivity._id));
      alert('Activity deleted successfully');
      setShowDeleteModal(false);
      setSelectedActivity(null);
    } catch (error) {
      console.error('Error deleting activity:', error);
      alert('Error deleting activity');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const activityData = {
        ...formData,
        children: formData.children.map(childId => ({
          child: childId,
          participation: 'good'
        })),
        materials: formData.materials.split(',').map(m => m.trim()).filter(m => m),
        learningObjectives: formData.learningObjectives.split(',').map(o => o.trim()).filter(o => o),
        startTime: new Date(`${selectedDate} ${formData.startTime}`),
        endTime: new Date(`${selectedDate} ${formData.endTime}`)
      };

      let result;
      if (selectedActivity) {
        result = await activityService.update(selectedActivity._id, activityData);
        setActivities(activities.map(a => 
          a._id === selectedActivity._id ? result : a
        ));
        alert('Activity updated successfully');
      } else {
        result = await activityService.create(activityData);
        setActivities([...activities, result]);
        alert('Activity created successfully');
      }
      
      setShowModal(false);
      resetForm();
    } catch (error) {
      console.error('Error saving activity:', error);
      alert('Error saving activity');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      type: 'play',
      children: [],
      room: '',
      startTime: '',
      endTime: '',
      materials: '',
      learningObjectives: '',
      notes: ''
    });
    setSelectedActivity(null);
  };

  const handleChildSelection = (childId) => {
    setFormData(prev => ({
      ...prev,
      children: prev.children.includes(childId)
        ? prev.children.filter(id => id !== childId)
        : [...prev.children, childId]
    }));
  };

  const selectAllChildren = () => {
    setFormData(prev => ({
      ...prev,
      children: children.map(child => child._id)
    }));
  };

  const clearAllChildren = () => {
    setFormData(prev => ({
      ...prev,
      children: []
    }));
  };

  // Filter activities
  const filteredActivities = activities.filter(activity => {
    if (filter === 'all') return true;
    return activity.type === filter;
  });

  const getActivityTypeIcon = (type) => {
    const icons = {
      meal: '🍽️',
      nap: '💤',
      play: '🎮',
      learning: '📚',
      incident: '⚠️'
    };
    return icons[type] || '📝';
  };

  const getActivityTypeColor = (type) => {
    const colors = {
      meal: '#e74c3c',
      nap: '#3498db',
      play: '#2ecc71',
      learning: '#f39c12',
      incident: '#e67e22'
    };
    return colors[type] || '#95a5a6';
  };

  const getStatusBadge = (startTime, endTime) => {
    const now = new Date();
    const start = new Date(startTime);
    const end = new Date(endTime);

    if (now < start) return { class: 'upcoming', text: 'Upcoming' };
    if (now > end) return { class: 'completed', text: 'Completed' };
    return { class: 'in-progress', text: 'In Progress' };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="activity-logger">
      <div className="page-header">
        <div className="header-content">
          <h1>Activity Logger</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Log New Activity
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="filter-group">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="filter-group">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="form-control"
          >
            <option value="all">All Activities</option>
            <option value="play">Play</option>
            <option value="learning">Learning</option>
            <option value="meal">Meal</option>
            <option value="nap">Nap</option>
            <option value="incident">Incident</option>
          </select>
        </div>
      </div>

      {/* Activities Grid */}
      <div className="activities-grid">
        {filteredActivities.map(activity => {
          const status = getStatusBadge(activity.startTime, activity.endTime);
          
          return (
            <div 
              key={activity._id} 
              className="activity-card"
              style={{ borderLeftColor: getActivityTypeColor(activity.type) }}
            >
              <div className="activity-header">
                <div className="activity-type">
                  <span className="activity-icon">
                    {getActivityTypeIcon(activity.type)}
                  </span>
                  <span className="activity-type-text capitalize">{activity.type}</span>
                </div>
                <div className="activity-time">
                  {new Date(activity.startTime).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })} - {new Date(activity.endTime).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </div>
              </div>

              <div className="activity-content">
                <h3 className="activity-title">{activity.title}</h3>
                {activity.description && (
                  <p className="activity-description">{activity.description}</p>
                )}
                
                <div className="activity-meta">
                  <div className="meta-item">
                    <strong>Room:</strong> {activity.room}
                  </div>
                  <div className="meta-item">
                    <strong>Children:</strong> {activity.children?.length || 0}
                  </div>
                  <div className="meta-item">
                    <strong>Duration:</strong> {activity.duration} mins
                  </div>
                </div>

                {activity.learningObjectives && activity.learningObjectives.length > 0 && (
                  <div className="learning-objectives">
                    <strong>Learning Objectives:</strong>
                    <ul>
                      {activity.learningObjectives.map((objective, index) => (
                        <li key={index}>{objective}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {activity.notes && (
                  <div className="activity-notes">
                    <strong>Notes:</strong> {activity.notes}
                  </div>
                )}
              </div>

              <div className="activity-footer">
                <div className="activity-status">
                  <span className={`status-badge status-${status.class}`}>
                    {status.text}
                  </span>
                </div>
                <div className="activity-actions">
                  <button 
                    className="btn btn-sm btn-info"
                    onClick={() => handleEdit(activity)}
                  >
                    Edit
                  </button>
                  <button 
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(activity)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredActivities.length === 0 && (
        <div className="no-activities">
          <p>No activities found for the selected criteria</p>
          <button 
            className="btn btn-primary"
            onClick={() => setShowModal(true)}
          >
            Log Your First Activity
          </button>
        </div>
      )}

      {/* Activity Form Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedActivity ? 'Edit Activity' : 'Log New Activity'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="activity-form">
          <div className="form-section">
            <h3>Activity Details</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Activity Title *</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Activity Type *</label>
                <select 
                  className="form-control"
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  required
                >
                  <option value="play">Play</option>
                  <option value="learning">Learning</option>
                  <option value="meal">Meal</option>
                  <option value="nap">Nap</option>
                  <option value="incident">Incident</option>
                </select>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea 
                className="form-control" 
                rows="3"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Describe the activity..."
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Start Time *</label>
                <input 
                  type="time" 
                  className="form-control" 
                  value={formData.startTime}
                  onChange={(e) => setFormData({...formData, startTime: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">End Time *</label>
                <input 
                  type="time" 
                  className="form-control" 
                  value={formData.endTime}
                  onChange={(e) => setFormData({...formData, endTime: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Room *</label>
                <select 
                  className="form-control"
                  value={formData.room}
                  onChange={(e) => setFormData({...formData, room: e.target.value})}
                  required
                >
                  <option value="">Select Room</option>
                  <option value="infants">Infants Room</option>
                  <option value="toddlers">Toddlers Room</option>
                  <option value="preschool">Preschool Room</option>
                  <option value="playground">Playground</option>
                  <option value="art">Art Room</option>
                  <option value="music">Music Room</option>
                </select>
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="section-header">
              <h3>Participating Children</h3>
              <div className="selection-actions">
                <button type="button" className="btn btn-sm btn-outline" onClick={selectAllChildren}>
                  Select All
                </button>
                <button type="button" className="btn btn-sm btn-outline" onClick={clearAllChildren}>
                  Clear All
                </button>
              </div>
            </div>
            <div className="children-selection">
              {children.map(child => (
                <label key={child._id} className="child-checkbox">
                  <input
                    type="checkbox"
                    checked={formData.children.includes(child._id)}
                    onChange={() => handleChildSelection(child._id)}
                  />
                  <span className="checkmark"></span>
                  <span className="child-info">
                    {child.firstName} {child.lastName} ({child.room})
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="form-section">
            <h3>Additional Information</h3>
            <div className="form-group">
              <label className="form-label">Materials (comma separated)</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.materials}
                onChange={(e) => setFormData({...formData, materials: e.target.value})}
                placeholder="crayons, paper, glue, etc."
              />
            </div>
            <div className="form-group">
              <label className="form-label">Learning Objectives (comma separated)</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.learningObjectives}
                onChange={(e) => setFormData({...formData, learningObjectives: e.target.value})}
                placeholder="color recognition, fine motor skills, etc."
              />
            </div>
            <div className="form-group">
              <label className="form-label">Additional Notes</label>
              <textarea 
                className="form-control" 
                rows="3"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Any additional observations or notes..."
              />
            </div>
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedActivity ? 'Update' : 'Log'} Activity
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setSelectedActivity(null);
        }}
        onConfirm={confirmDelete}
        title="Delete Activity"
        message={`Are you sure you want to delete "${selectedActivity?.title}"? This action cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default ActivityLogger;