import api from './api';

export const scheduleService = {
  getSchedule: async (date) => {
    const response = await api.get('/schedule', { params: { date } });
    return response.data;
  },

  createSchedule: async (scheduleData) => {
    const response = await api.post('/schedule', scheduleData);
    return response.data;
  },

  updateSchedule: async (id, scheduleData) => {
    const response = await api.put(`/schedule/${id}`, scheduleData);
    return response.data;
  },

  deleteSchedule: async (id) => {
    const response = await api.delete(`/schedule/${id}`);
    return response.data;
  },

  getEmployeeSchedule: async (employeeId, date) => {
    const response = await api.get(`/schedule/employee/${employeeId}`, { params: { date } });
    return response.data;
  }
};

export default scheduleService;