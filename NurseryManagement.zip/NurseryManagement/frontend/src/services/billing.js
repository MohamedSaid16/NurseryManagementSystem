import api from './api';

export const billingService = {
  // Get all invoices
  getInvoices: async (filters = {}) => {
    const response = await api.get('/invoices', { params: filters });
    return response.data;
  },

  // Get invoice by ID
  getInvoice: async (id) => {
    const response = await api.get(`/invoices/${id}`);
    return response.data;
  },

  // Create invoice
  createInvoice: async (invoiceData) => {
    const response = await api.post('/invoices', invoiceData);
    return response.data;
  },

  // Update invoice
  updateInvoice: async (id, invoiceData) => {
    const response = await api.put(`/invoices/${id}`, invoiceData);
    return response.data;
  },

  // Record payment
  recordPayment: async (invoiceId, paymentData) => {
    const response = await api.post(`/invoices/${invoiceId}/payments`, paymentData);
    return response.data;
  },

  // Get parent invoices
  getParentInvoices: async () => {
    const response = await api.get('/invoices/parent');
    return response.data;
  }
};

export default billingService;