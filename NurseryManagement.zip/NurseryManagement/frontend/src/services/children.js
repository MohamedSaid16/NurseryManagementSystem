import api from './api';

export const childrenService = {
  getAll: async () => {
    const response = await api.get('/children');
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/children/${id}`);
    return response.data;
  },

  create: async (childData) => {
    const response = await api.post('/children', childData);
    return response.data;
  },

  update: async (id, childData) => {
    const response = await api.put(`/children/${id}`, childData);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/children/${id}`);
    return response.data;
  },

  getAttendance: async (childId) => {
    const response = await api.get(`/children/${childId}/attendance`);
    return response.data;
  },

  getActivities: async (childId) => {
    const response = await api.get(`/children/${childId}/activities`);
    return response.data;
  },

  addMedicalRecord: async (childId, recordData) => {
    const response = await api.post(`/children/${childId}/medical-records`, recordData);
    return response.data;
  }
};
export default childrenService;