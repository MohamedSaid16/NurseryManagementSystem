import api from './api';

export const employeesService = {
  // Get all employees
  getAll: async () => {
    const response = await api.get('/employees');
    return response.data;
  },

  // Get employee by ID
  getById: async (id) => {
    const response = await api.get(`/employees/${id}`);
    return response.data;
  },

  // Create employee
  create: async (employeeData) => {
    const response = await api.post('/employees', employeeData);
    return response.data;
  },

  // Update employee
  update: async (id, employeeData) => {
    const response = await api.put(`/employees/${id}`, employeeData);
    return response.data;
  },

  // Delete employee
  delete: async (id) => {
    const response = await api.delete(`/employees/${id}`);
    return response.data;
  },

  // Get employee schedule
  getSchedule: async (employeeId) => {
    const response = await api.get(`/employees/${employeeId}/schedule`);
    return response.data;
  },

  // Get employees by position
  getByPosition: async (position) => {
    const response = await api.get('/employees', { params: { position } });
    return response.data;
  },

  // Update employee status
  updateStatus: async (id, status) => {
    const response = await api.put(`/employees/${id}/status`, { status });
    return response.data;
  }
};

export default employeesService;