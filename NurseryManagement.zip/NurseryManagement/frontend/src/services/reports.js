import { apiService } from './api';

class ReportsService {
  async getAll() {
    try {
      const response = await apiService.get('/reports');
      return response;
    } catch (error) {
      console.error('Error fetching reports:', error);
      throw error;
    }
  }

  async generate(reportType, parameters = {}) {
    try {
      const response = await apiService.post('/reports/generate', {
        type: reportType,
        parameters
      });
      return response;
    } catch (error) {
      console.error('Error generating report:', error);
      throw error;
    }
  }

  async download(reportId) {
    try {
      const response = await apiService.get(`/reports/${reportId}/download`);
      return response;
    } catch (error) {
      console.error('Error downloading report:', error);
      throw error;
    }
  }
}

export const reportsService = new ReportsService();