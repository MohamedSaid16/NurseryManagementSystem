import api from './api';

export const paymentsService = {
  getAll: async () => {
    const response = await api.get('/payments');
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/payments/${id}`);
    return response.data;
  },

  create: async (paymentData) => {
    const response = await api.post('/payments', paymentData);
    return response.data;
  },

  update: async (id, paymentData) => {
    const response = await api.put(`/payments/${id}`, paymentData);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/payments/${id}`);
    return response.data;
  },

  generateInvoice: async (invoiceData) => {
    const response = await api.post('/payments/generate-invoice', invoiceData);
    return response.data;
  },

  getParentInvoices: async (parentId) => {
    const response = await api.get(`/payments/parent/${parentId}/invoices`);
    return response.data;
  },

  markAsPaid: async (invoiceId) => {
    const response = await api.put(`/payments/invoices/${invoiceId}/pay`);
    return response.data;
  }
};