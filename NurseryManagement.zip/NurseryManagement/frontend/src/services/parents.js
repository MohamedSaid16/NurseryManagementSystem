import { apiService } from './api';

class ParentsService {
  async getAll() {
    try {
      const response = await apiService.get('/parents');
      return response;
    } catch (error) {
      console.error('Error fetching parents:', error);
      throw error;
    }
  }

  async getById(parentId) {
    try {
      const response = await apiService.get(`/parents/${parentId}`);
      return response;
    } catch (error) {
      console.error('Error fetching parent:', error);
      throw error;
    }
  }

  async create(parentData) {
    try {
      const response = await apiService.post('/parents', parentData);
      return response;
    } catch (error) {
      console.error('Error creating parent:', error);
      throw error;
    }
  }

  async update(parentId, updateData) {
    try {
      const response = await apiService.put(`/parents/${parentId}`, updateData);
      return response;
    } catch (error) {
      console.error('Error updating parent:', error);
      throw error;
    }
  }

  async delete(parentId) {
    try {
      const response = await apiService.delete(`/parents/${parentId}`);
      return response;
    } catch (error) {
      console.error('Error deleting parent:', error);
      throw error;
    }
  }
}

export const parentsService = new ParentsService();