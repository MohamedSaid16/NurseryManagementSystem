import api from './api';

export const activityService = {
  // Get all activities
  getActivities: async (filters = {}) => {
    const response = await api.get('/activities', { params: filters });
    return response.data;
  },

  // Get activity by ID
  getActivity: async (id) => {
    const response = await api.get(`/activities/${id}`);
    return response.data;
  },

  // Create activity
  createActivity: async (activityData) => {
    const response = await api.post('/activities', activityData);
    return response.data;
  },

  // Update activity
  updateActivity: async (id, activityData) => {
    const response = await api.put(`/activities/${id}`, activityData);
    return response.data;
  },

  // Delete activity
  deleteActivity: async (id) => {
    const response = await api.delete(`/activities/${id}`);
    return response.data;
  },

  // Add child to activity
  addChildToActivity: async (activityId, childData) => {
    const response = await api.post(`/activities/${activityId}/children`, childData);
    return response.data;
  },

  // Remove child from activity
  removeChildFromActivity: async (activityId, childId) => {
    const response = await api.delete(`/activities/${activityId}/children/${childId}`);
    return response.data;
  }
};

export default activityService;