import api from './api';

export const attendanceService = {
  // Get all attendance records
  getAttendance: async (filters = {}) => {
    const response = await api.get('/attendance', { params: filters });
    return response.data;
  },

  // Record attendance
  recordAttendance: async (attendanceData) => {
    const response = await api.post('/attendance', attendanceData);
    return response.data;
  },

  // Update attendance
  updateAttendance: async (id, attendanceData) => {
    const response = await api.put(`/attendance/${id}`, attendanceData);
    return response.data;
  },

  // Get attendance by child
  getAttendanceByChild: async (childId) => {
    const response = await api.get(`/attendance/child/${childId}`);
    return response.data;
  },

  // Get attendance reports
  getAttendanceReports: async (filters = {}) => {
    const response = await api.get('/attendance/reports', { params: filters });
    return response.data;
  }
};

export default attendanceService;