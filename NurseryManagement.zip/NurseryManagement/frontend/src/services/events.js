import { apiService } from './api';

class EventsService {
  async getUpcoming() {
    try {
      const response = await apiService.get('/events/upcoming');
      return response;
    } catch (error) {
      console.error('Error fetching upcoming events:', error);
      throw error;
    }
  }

  async scheduleVisit(visitData) {
    try {
      const response = await apiService.post('/events/visits', visitData);
      return response;
    } catch (error) {
      console.error('Error scheduling visit:', error);
      throw error;
    }
  }

  async getCalendarEvents(startDate, endDate) {
    try {
      const response = await apiService.get(`/events/calendar?start=${startDate}&end=${endDate}`);
      return response;
    } catch (error) {
      console.error('Error fetching calendar events:', error);
      throw error;
    }
  }
}

export const eventsService = new EventsService();