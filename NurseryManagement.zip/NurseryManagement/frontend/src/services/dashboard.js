import api from './api';

export const dashboardService = {
  getAdminStats: async () => {
    const response = await api.get('/dashboard/admin');
    return response.data;
  },

  getEmployeeStats: async () => {
    const response = await api.get('/dashboard/employee');
    return response.data;
  },

  getParentStats: async () => {
    const response = await api.get('/dashboard/parent');
    return response.data;
  },

  getRecentActivities: async () => {
    const response = await api.get('/dashboard/recent-activities');
    return response.data;
  },

  getAttendanceSummary: async (period = 'today') => {
    const response = await api.get('/dashboard/attendance-summary', {
      params: { period }
    });
    return response.data;
  }
};

export default dashboardService;