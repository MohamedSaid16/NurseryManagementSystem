import React, { useState, useEffect } from 'react';
import  childrenService  from '../../services/children';
import  attendanceService  from '../../services/attendance';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import Modal from '../../components/common/Modal/Modal';
import './MyChildren.css';

const MyChildren = () => {
  const [children, setChildren] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadMyChildren();
  }, []);

  const loadMyChildren = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem('user'));
      
      const [childrenRes, attendanceRes] = await Promise.all([
        childrenService.getByEmployee(user._id),
        attendanceService.getTodayAttendance()
      ]);

      setChildren(childrenRes.children || childrenRes);
      setAttendance(attendanceRes.attendance || attendanceRes);
    } catch (error) {
      console.error('Error loading children:', error);
      alert('Error loading children data');
    } finally {
      setLoading(false);
    }
  };

  const handleTakeAttendance = (child) => {
    setSelectedChild(child);
    setShowAttendanceModal(true);
  };

  const handleAttendanceSubmit = async (status, notes = '') => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      
      const attendanceData = {
        child: selectedChild._id,
        date: selectedDate,
        status: status,
        recordedBy: user._id,
        notes: notes
      };

      await attendanceService.create(attendanceData);
      
      alert('Attendance recorded successfully!');
      setShowAttendanceModal(false);
      setSelectedChild(null);
      loadMyChildren(); // Refresh data
    } catch (error) {
      console.error('Error recording attendance:', error);
      alert('Error recording attendance');
    }
  };

  const getChildAttendance = (childId) => {
    return attendance.find(a => a.child._id === childId);
  };

  const getAttendanceStats = () => {
    const present = attendance.filter(a => a.status === 'present').length;
    const absent = attendance.filter(a => a.status === 'absent').length;
    const total = children.length;
    
    return {
      present,
      absent,
      total,
      percentage: total > 0 ? Math.round((present / total) * 100) : 0
    };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  const stats = getAttendanceStats();

  return (
    <div className="employee-mychildren">
      <div className="page-header">
        <h1>My Children</h1>
        <p>Manage attendance and view information for children in your care</p>
      </div>

      {/* Attendance Overview */}
      <div className="attendance-overview">
        <div className="attendance-card">
          <div className="attendance-stats">
            <div className="stat">
              <span className="number">{stats.present}</span>
              <span className="label">Present</span>
            </div>
            <div className="stat">
              <span className="number">{stats.absent}</span>
              <span className="label">Absent</span>
            </div>
            <div className="stat">
              <span className="number">{stats.total}</span>
              <span className="label">Total</span>
            </div>
            <div className="stat percentage">
              <span className="number">{stats.percentage}%</span>
              <span className="label">Attendance Rate</span>
            </div>
          </div>
        </div>
      </div>

      {/* Children List */}
      <div className="children-grid">
        {children.map(child => {
          const childAttendance = getChildAttendance(child._id);
          
          return (
            <div key={child._id} className="child-card">
              <div className="child-header">
                <div className="child-avatar">
                  {child.gender === 'male' ? '👦' : '👧'}
                </div>
                <div className="child-info">
                  <h3>{child.firstName} {child.lastName}</h3>
                  <p>{child.room} • {child.age} years</p>
                </div>
                <div className={`attendance-status status-${childAttendance?.status || 'unknown'}`}>
                  {childAttendance ? (
                    <span>{childAttendance.status}</span>
                  ) : (
                    <span>Not Recorded</span>
                  )}
                </div>
              </div>

              <div className="child-details">
                {child.allergies && child.allergies.length > 0 && (
                  <div className="detail-item">
                    <strong>Allergies:</strong> {child.allergies.join(', ')}
                  </div>
                )}
                {child.medications && child.medications.length > 0 && (
                  <div className="detail-item">
                    <strong>Medications:</strong> {child.medications.join(', ')}
                  </div>
                )}
                {child.specialNeeds && (
                  <div className="detail-item">
                    <strong>Special Needs:</strong> {child.specialNeeds}
                  </div>
                )}
              </div>

              <div className="emergency-contact">
                <strong>Emergency Contact:</strong>
                {child.emergencyContacts && child.emergencyContacts.length > 0 ? (
                  child.emergencyContacts.map((contact, index) => (
                    <div key={index} className="contact-info">
                      {contact.name} ({contact.relationship}) - {contact.phone}
                    </div>
                  ))
                ) : (
                  <div className="contact-info">No emergency contacts</div>
                )}
              </div>

              <div className="child-actions">
                {!childAttendance && (
                  <button 
                    className="btn btn-primary"
                    onClick={() => handleTakeAttendance(child)}
                  >
                    Take Attendance
                  </button>
                )}
                <button className="btn btn-outline">
                  View Profile
                </button>
                <button className="btn btn-outline">
                  Log Activity
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {children.length === 0 && (
        <div className="no-children">
          <div className="no-children-icon">👶</div>
          <h3>No Children Assigned</h3>
          <p>You don't have any children assigned to your care yet.</p>
        </div>
      )}

      {/* Attendance Modal */}
      <Modal
        isOpen={showAttendanceModal}
        onClose={() => {
          setShowAttendanceModal(false);
          setSelectedChild(null);
        }}
        title={`Record Attendance - ${selectedChild?.firstName} ${selectedChild?.lastName}`}
        size="medium"
      >
        <div className="attendance-modal">
          <div className="attendance-options">
            <button 
              className="attendance-option present"
              onClick={() => handleAttendanceSubmit('present')}
            >
              <span className="option-icon">✅</span>
              <span className="option-text">Present</span>
            </button>
            
            <button 
              className="attendance-option absent"
              onClick={() => handleAttendanceSubmit('absent')}
            >
              <span className="option-icon">❌</span>
              <span className="option-text">Absent</span>
            </button>
            
            <button 
              className="attendance-option late"
              onClick={() => handleAttendanceSubmit('late')}
            >
              <span className="option-icon">⏰</span>
              <span className="option-text">Late</span>
            </button>
            
            <button 
              className="attendance-option excused"
              onClick={() => handleAttendanceSubmit('excused')}
            >
              <span className="option-icon">📝</span>
              <span className="option-text">Excused</span>
            </button>
          </div>

          <div className="attendance-notes">
            <label className="form-label">Additional Notes (Optional)</label>
            <textarea 
              className="form-control" 
              rows="3"
              placeholder="Add any notes about today's attendance..."
              id="attendanceNotes"
            />
          </div>

          <div className="modal-actions">
            <button 
              className="btn btn-secondary"
              onClick={() => setShowAttendanceModal(false)}
            >
              Cancel
            </button>
            <button 
              className="btn btn-primary"
              onClick={() => {
                const notes = document.getElementById('attendanceNotes').value;
                handleAttendanceSubmit('present', notes);
              }}
            >
              Record with Notes
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default MyChildren;