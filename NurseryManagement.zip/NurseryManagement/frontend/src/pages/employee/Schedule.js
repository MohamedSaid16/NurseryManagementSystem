import React, { useState, useEffect } from 'react';
import  scheduleService  from '../../services/schedule';
import activityService from '../../services/activities';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import Modal from '../../components/common/Modal/Modal';
import './Schedule.css';

const Schedule = () => {
  const [schedule, setSchedule] = useState([]);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);

  useEffect(() => {
    loadScheduleData();
  }, [selectedDate]);

  const loadScheduleData = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem('user'));
      
      const [scheduleRes, activitiesRes] = await Promise.all([
        scheduleService.getEmployeeSchedule(user._id, selectedDate),
      activityService.getAll({ date: selectedDate })
      ]);

      setSchedule(scheduleRes.schedule || scheduleRes);
      setActivities(activitiesRes.activities || activitiesRes);
    } catch (error) {
      console.error('Error loading schedule:', error);
      alert('Error loading schedule data');
    } finally {
      setLoading(false);
    }
  };

  const timeSlots = [
    { time: '08:00 - 09:00', period: 'Morning Arrival' },
    { time: '09:00 - 10:00', period: 'Learning Activity' },
    { time: '10:00 - 10:30', period: 'Snack Time' },
    { time: '10:30 - 11:30', period: 'Outdoor Play' },
    { time: '11:30 - 12:00', period: 'Circle Time' },
    { time: '12:00 - 13:00', period: 'Lunch & Cleanup' },
    { time: '13:00 - 15:00', period: 'Nap Time' },
    { time: '15:00 - 15:30', period: 'Afternoon Snack' },
    { time: '15:30 - 16:30', period: 'Creative Activity' },
    { time: '16:30 - 17:00', period: 'Departure Prep' }
  ];

  const getActivitiesForTimeSlot = (timeSlot) => {
    return activities.filter(activity => {
      const activityTime = new Date(activity.startTime).toTimeString().substring(0, 5);
      return activityTime >= timeSlot.time.substring(0, 5) && 
             activityTime < timeSlot.time.substring(8, 13);
    });
  };

  const handleAddActivity = (timeSlot) => {
    setSelectedTimeSlot(timeSlot);
    setShowActivityModal(true);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="employee-schedule">
      <div className="page-header">
        <div className="header-content">
          <h1>Daily Schedule</h1>
          <div className="date-selector">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="form-control"
            />
          </div>
        </div>
        <p>Your schedule for {new Date(selectedDate).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}</p>
      </div>

      {/* Schedule Overview */}
      <div className="schedule-overview">
        <div className="overview-card">
          <div className="overview-item">
            <span className="label">Total Activities:</span>
            <span className="value">{activities.length}</span>
          </div>
          <div className="overview-item">
            <span className="label">Completed:</span>
            <span className="value">
              {activities.filter(a => new Date(a.endTime) < new Date()).length}
            </span>
          </div>
          <div className="overview-item">
            <span className="label">Upcoming:</span>
            <span className="value">
              {activities.filter(a => new Date(a.startTime) > new Date()).length}
            </span>
          </div>
        </div>
      </div>

      {/* Schedule Timeline */}
      <div className="schedule-timeline">
        {timeSlots.map((timeSlot, index) => {
          const slotActivities = getActivitiesForTimeSlot(timeSlot);
          const isCurrentTime = checkIfCurrentTime(timeSlot.time);
          
          return (
            <div 
              key={index} 
              className={`time-slot ${isCurrentTime ? 'current' : ''}`}
            >
              <div className="time-info">
                <div className="time-range">{timeSlot.time}</div>
                <div className="period">{timeSlot.period}</div>
              </div>
              
              <div className="activities-list">
                {slotActivities.map(activity => (
                  <div key={activity._id} className="activity-item">
                    <div className="activity-type">{activity.type}</div>
                    <div className="activity-title">{activity.title}</div>
                    <div className="activity-room">{activity.room}</div>
                    {activity.children && (
                      <div className="activity-children">
                        {activity.children.length} children
                      </div>
                    )}
                  </div>
                ))}
                
                {slotActivities.length === 0 && (
                  <div className="no-activities">
                    <p>No activities scheduled</p>
                    <button 
                      className="btn btn-sm btn-outline"
                      onClick={() => handleAddActivity(timeSlot)}
                    >
                      Add Activity
                    </button>
                  </div>
                )}
              </div>

              {isCurrentTime && (
                <div className="current-indicator">
                  <span>Now</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="quick-actions-section">
        <h2>Quick Actions</h2>
        <div className="quick-actions">
          <button className="action-btn">
            <span className="action-icon">📋</span>
            <span className="action-text">Print Schedule</span>
          </button>
          <button className="action-btn">
            <span className="action-icon">🔄</span>
            <span className="action-text">Copy to Tomorrow</span>
          </button>
          <button className="action-btn">
            <span className="action-icon">📧</span>
            <span className="action-text">Email Schedule</span>
          </button>
          <button className="action-btn">
            <span className="action-icon">➕</span>
            <span className="action-text">Add Custom Slot</span>
          </button>
        </div>
      </div>

      {/* Activity Modal */}
      <Modal
        isOpen={showActivityModal}
        onClose={() => {
          setShowActivityModal(false);
          setSelectedTimeSlot(null);
        }}
        title={`Add Activity - ${selectedTimeSlot?.period}`}
        size="medium"
      >
        <div className="activity-modal">
          <p>
            <strong>Time Slot:</strong> {selectedTimeSlot?.time}
          </p>
          <p>
            To add a new activity for this time slot, please use the Activity Logger.
          </p>
          <div className="modal-actions">
            <button 
              className="btn btn-secondary"
              onClick={() => setShowActivityModal(false)}
            >
              Cancel
            </button>
            <button 
              className="btn btn-primary"
              onClick={() => {
                window.location.href = '/employee/activities';
              }}
            >
              Go to Activity Logger
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

// Helper function to check if current time falls within a time slot
const checkIfCurrentTime = (timeRange) => {
  const now = new Date();
  const currentTime = now.toTimeString().substring(0, 5);
  const [start, end] = timeRange.split(' - ');
  
  return currentTime >= start && currentTime < end;
};

export default Schedule;