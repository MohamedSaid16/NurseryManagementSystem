import React from 'react';
import ActivityLogger from '../../components/employee/ActivityLogger/ActivityLogger';

const Activities = () => {
  return <ActivityLogger />;
};

export default Activities;