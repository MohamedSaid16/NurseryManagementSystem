import React, { useState, useEffect } from 'react';
import  dashboardService  from '../../services/dashboard';
import  childrenService  from '../../services/children';
import  attendanceService  from '../../services/attendance';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import './Dashboard.css';

const EmployeeDashboard = () => {
  const [dashboardData, setDashboardData] = useState({});
  const [myChildren, setMyChildren] = useState([]);
  const [todayAttendance, setTodayAttendance] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem('user'));
      
      const [dashboardRes, childrenRes, attendanceRes] = await Promise.all([
        dashboardService.getEmployeeStats(user._id),
        childrenService.getByEmployee(user._id),
        attendanceService.getTodayAttendance()
      ]);

      setDashboardData(dashboardRes);
      setMyChildren(childrenRes.children || childrenRes);
      setTodayAttendance(attendanceRes.attendance || attendanceRes);
    } catch (error) {
      console.error('Error loading employee dashboard:', error);
      alert('Error loading dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getPresentCount = () => {
    return todayAttendance.filter(a => a.status === 'present').length;
  };

  const getAbsentCount = () => {
    return todayAttendance.filter(a => a.status === 'absent').length;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="employee-dashboard">
      <div className="page-header">
        <h1>Employee Dashboard</h1>
        <p>Welcome back! Here's your overview for today.</p>
      </div>

      {/* Quick Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon children">👶</div>
          <div className="stat-info">
            <h3>{myChildren.length}</h3>
            <p>My Children</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon present">✅</div>
          <div className="stat-info">
            <h3>{getPresentCount()}</h3>
            <p>Present Today</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon absent">❌</div>
          <div className="stat-info">
            <h3>{getAbsentCount()}</h3>
            <p>Absent Today</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon activities">📝</div>
          <div className="stat-info">
            <h3>{dashboardData.todayActivities || 0}</h3>
            <p>Today's Activities</p>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        {/* My Children */}
        <div className="dashboard-section">
          <h2>My Children</h2>
          <div className="children-list">
            {myChildren.map(child => (
              <div key={child._id} className="child-card">
                <div className="child-avatar">
                  {child.gender === 'male' ? '👦' : '👧'}
                </div>
                <div className="child-info">
                  <h4>{child.firstName} {child.lastName}</h4>
                  <p>{child.room} • {child.age} years</p>
                  {child.allergies && child.allergies.length > 0 && (
                    <div className="allergies">
                      <span className="allergy-warning">⚠️ Allergies</span>
                    </div>
                  )}
                </div>
                <div className="child-status">
                  <span className={`status-badge status-${getChildStatus(child._id)}`}>
                    {getChildStatus(child._id)}
                  </span>
                </div>
              </div>
            ))}
            {myChildren.length === 0 && (
              <p className="no-data">No children assigned to you</p>
            )}
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="dashboard-section">
          <h2>Today's Schedule</h2>
          <div className="schedule-list">
            <div className="schedule-item">
              <div className="time">08:00 - 09:00</div>
              <div className="activity">Arrival & Morning Circle</div>
            </div>
            <div className="schedule-item">
              <div className="time">09:00 - 10:00</div>
              <div className="activity">Learning Activity</div>
            </div>
            <div className="schedule-item">
              <div className="time">10:00 - 10:30</div>
              <div className="activity">Snack Time</div>
            </div>
            <div className="schedule-item">
              <div className="time">10:30 - 11:30</div>
              <div className="activity">Outdoor Play</div>
            </div>
            <div className="schedule-item">
              <div className="time">12:00 - 13:00</div>
              <div className="activity">Lunch & Cleanup</div>
            </div>
            <div className="schedule-item">
              <div className="time">13:00 - 15:00</div>
              <div className="activity">Nap Time</div>
            </div>
            <div className="schedule-item">
              <div className="time">15:00 - 16:00</div>
              <div className="activity">Afternoon Activity</div>
            </div>
            <div className="schedule-item">
              <div className="time">16:00 - 17:00</div>
              <div className="activity">Pickup & Departure</div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <h2>Quick Actions</h2>
          <div className="quick-actions">
            <button className="action-btn">
              <span className="action-icon">📝</span>
              Log Activity
            </button>
            <button className="action-btn">
              <span className="action-icon">✅</span>
              Take Attendance
            </button>
            <button className="action-btn">
              <span className="action-icon">🍽️</span>
              Meal Log
            </button>
            <button className="action-btn">
              <span className="action-icon">😴</span>
              Nap Time
            </button>
            <button className="action-btn">
              <span className="action-icon">📋</span>
              Daily Report
            </button>
            <button className="action-btn">
              <span className="action-icon">💬</span>
              Message Parents
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to get child's attendance status
const getChildStatus = (childId) => {
  // This would typically come from today's attendance data
  return 'present'; // Placeholder
};

export default EmployeeDashboard;