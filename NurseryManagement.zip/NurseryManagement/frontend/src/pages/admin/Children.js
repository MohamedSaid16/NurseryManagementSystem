import React, { useState, useEffect } from 'react';
import { childrenService } from '../../services/children';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import Modal from '../../components/common/Modal/Modal';
import './Children.css';

const Children = () => {
  const [children, setChildren] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    birthDate: '',
    gender: '',
    room: '',
    allergies: [],
    medications: [],
    specialNeeds: '',
    emergencyContacts: []
  });

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      setLoading(true);
      const response = await childrenService.getAll();
      setChildren(response.children || response);
    } catch (error) {
      console.error('Error loading children:', error);
      alert('Error loading children data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (child) => {
    setSelectedChild(child);
    setFormData({
      firstName: child.firstName,
      lastName: child.lastName,
      birthDate: child.birthDate.split('T')[0],
      gender: child.gender,
      room: child.room,
      allergies: child.allergies || [],
      medications: child.medications || [],
      specialNeeds: child.specialNeeds || '',
      emergencyContacts: child.emergencyContacts || []
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedChild) {
        await childrenService.update(selectedChild._id, formData);
        alert('Child updated successfully');
      } else {
        await childrenService.create(formData);
        alert('Child added successfully');
      }
      setShowModal(false);
      resetForm();
      loadChildren();
    } catch (error) {
      console.error('Error saving child:', error);
      alert('Error saving child data');
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      birthDate: '',
      gender: '',
      room: '',
      allergies: [],
      medications: [],
      specialNeeds: '',
      emergencyContacts: []
    });
    setSelectedChild(null);
  };

  const calculateAge = (birthDate) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-children">
      <div className="page-header">
        <div className="header-content">
          <h1>Children Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Add New Child
          </button>
        </div>
      </div>

      <div className="children-table-container">
        <table className="children-table">
          <thead>
            <tr>
              <th>Child</th>
              <th>Age</th>
              <th>Room</th>
              <th>Gender</th>
              <th>Allergies</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {children.map(child => (
              <tr key={child._id}>
                <td>
                  <div className="child-info">
                    <div className="child-avatar">
                      {child.gender === 'male' ? '👦' : '👧'}
                    </div>
                    <div className="child-details">
                      <strong>{child.firstName} {child.lastName}</strong>
                      <span>ID: {child.childId}</span>
                    </div>
                  </div>
                </td>
                <td>{calculateAge(child.birthDate)} years</td>
                <td>
                  <span className={`room-badge room-${child.room}`}>
                    {child.room}
                  </span>
                </td>
                <td>
                  <span className={`gender-badge gender-${child.gender}`}>
                    {child.gender}
                  </span>
                </td>
                <td>
                  {child.allergies && child.allergies.length > 0 ? (
                    <span className="allergy-warning">⚠️ {child.allergies.length}</span>
                  ) : (
                    <span className="no-allergies">None</span>
                  )}
                </td>
                <td>
                  <span className={`status-badge status-${child.status || 'active'}`}>
                    {child.status || 'Active'}
                  </span>
                </td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn btn-sm btn-info"
                      onClick={() => handleEdit(child)}
                    >
                      Edit
                    </button>
                    <button className="btn btn-sm btn-outline">
                      View
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Child Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedChild ? 'Edit Child' : 'Add New Child'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="child-form">
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">First Name *</label>
              <input
                type="text"
                className="form-control"
                value={formData.firstName}
                onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Last Name *</label>
              <input
                type="text"
                className="form-control"
                value={formData.lastName}
                onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Birth Date *</label>
              <input
                type="date"
                className="form-control"
                value={formData.birthDate}
                onChange={(e) => setFormData({...formData, birthDate: e.target.value})}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Gender *</label>
              <select
                className="form-control"
                value={formData.gender}
                onChange={(e) => setFormData({...formData, gender: e.target.value})}
                required
              >
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Room *</label>
              <select
                className="form-control"
                value={formData.room}
                onChange={(e) => setFormData({...formData, room: e.target.value})}
                required
              >
                <option value="">Select Room</option>
                <option value="infants">Infants</option>
                <option value="toddlers">Toddlers</option>
                <option value="preschool">Preschool</option>
              </select>
            </div>
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedChild ? 'Update' : 'Add'} Child
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Children;