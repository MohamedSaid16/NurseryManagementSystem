import React, { useState, useEffect } from 'react';
import { reportsService } from '../../services/reports';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import './Reports.css';

const Reports = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [selectedReport, setSelectedReport] = useState('attendance');

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    try {
      setLoading(true);
      const response = await reportsService.getAll();
      setReports(response.reports || response);
    } catch (error) {
      console.error('Error loading reports:', error);
      alert('Error loading reports');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = async (type) => {
    try {
      setGenerating(true);
      const response = await reportsService.generate(type);
      
      // Download the report
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${type}_report_${new Date().toISOString().split('T')[0]}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);
      
      alert('Report generated successfully!');
    } catch (error) {
      console.error('Error generating report:', error);
      alert('Error generating report');
    } finally {
      setGenerating(false);
    }
  };

  const reportTypes = [
    {
      id: 'attendance',
      title: 'Attendance Report',
      description: 'Daily, weekly, and monthly attendance statistics',
      icon: '📊',
      color: '#007bff'
    },
    {
      id: 'financial',
      title: 'Financial Report',
      description: 'Revenue, expenses, and profit analysis',
      icon: '💰',
      color: '#28a745'
    },
    {
      id: 'children',
      title: 'Children Progress',
      description: 'Developmental milestones and progress tracking',
      icon: '👶',
      color: '#17a2b8'
    },
    {
      id: 'employee',
      title: 'Employee Performance',
      description: 'Staff performance and activity reports',
      icon: '👨‍🏫',
      color: '#6f42c1'
    },
    {
      id: 'billing',
      title: 'Billing Summary',
      description: 'Invoice and payment status overview',
      icon: '🧾',
      color: '#fd7e14'
    },
    {
      id: 'incident',
      title: 'Incident Reports',
      description: 'Safety and incident tracking reports',
      icon: '⚠️',
      color: '#dc3545'
    }
  ];

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-reports">
      <div className="page-header">
        <h1>Reports & Analytics</h1>
        <p>Generate and view comprehensive reports</p>
      </div>

      <div className="reports-grid">
        {reportTypes.map(report => (
          <div key={report.id} className="report-card">
            <div 
              className="report-icon"
              style={{ backgroundColor: `${report.color}20`, color: report.color }}
            >
              {report.icon}
            </div>
            <div className="report-content">
              <h3>{report.title}</h3>
              <p>{report.description}</p>
              <div className="report-actions">
                <button 
                  className="btn btn-primary btn-sm"
                  onClick={() => handleGenerateReport(report.id)}
                  disabled={generating}
                >
                  {generating ? 'Generating...' : 'Generate PDF'}
                </button>
                <button className="btn btn-outline btn-sm">
                  View Online
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Report Preview Section */}
      <div className="report-preview">
        <h2>Recent Reports</h2>
        <div className="reports-list">
          {reports.slice(0, 5).map(report => (
            <div key={report._id} className="report-item">
              <div className="report-info">
                <div className="report-type">{report.type}</div>
                <div className="report-date">
                  Generated: {new Date(report.generatedAt).toLocaleDateString()}
                </div>
              </div>
              <div className="report-actions">
                <button className="btn btn-sm btn-outline">Download</button>
                <button className="btn btn-sm btn-info">View</button>
              </div>
            </div>
          ))}
          {reports.length === 0 && (
            <div className="no-reports">
              <p>No reports generated yet</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="quick-stats">
        <h2>Quick Statistics</h2>
        <div className="stats-cards">
          <div className="stat-card">
            <div className="stat-value">95%</div>
            <div className="stat-label">Average Attendance</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">$12,450</div>
            <div className="stat-label">Monthly Revenue</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">42</div>
            <div className="stat-label">Active Children</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">15</div>
            <div className="stat-label">Staff Members</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;