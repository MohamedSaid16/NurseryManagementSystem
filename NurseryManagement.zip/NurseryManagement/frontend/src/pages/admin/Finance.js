import React, { useState, useEffect } from 'react';
import { billingService } from '../../services/billing';
import { dashboardService } from '../../services/dashboard';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import './Finance.css';

const Finance = () => {
  const [financialData, setFinancialData] = useState({});
  const [invoices, setInvoices] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  useEffect(() => {
    loadFinancialData();
  }, [selectedPeriod]);

  const loadFinancialData = async () => {
    try {
      setLoading(true);
      
      const [financeRes, invoicesRes, paymentsRes] = await Promise.all([
        dashboardService.getFinancialData(selectedPeriod),
        billingService.getAllInvoices(),
        billingService.getAllPayments()
      ]);

      setFinancialData(financeRes);
      setInvoices(invoicesRes.invoices || invoicesRes);
      setPayments(paymentsRes.payments || paymentsRes);
    } catch (error) {
      console.error('Error loading financial data:', error);
      alert('Error loading financial information');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      paid: { class: 'paid', text: 'Paid' },
      pending: { class: 'pending', text: 'Pending' },
      overdue: { class: 'overdue', text: 'Overdue' },
      draft: { class: 'draft', text: 'Draft' }
    };
    return statusConfig[status] || { class: 'draft', text: 'Unknown' };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-finance">
      <div className="page-header">
        <div className="header-content">
          <h1>Financial Management</h1>
          <div className="period-selector">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="form-control"
            >
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="quarter">This Quarter</option>
              <option value="year">This Year</option>
            </select>
          </div>
        </div>
      </div>

      {/* Financial Overview */}
      <div className="financial-overview">
        <div className="overview-card revenue">
          <div className="overview-icon">💰</div>
          <div className="overview-content">
            <h3>Total Revenue</h3>
            <div className="amount">{formatCurrency(financialData.totalRevenue || 0)}</div>
            <div className="trend positive">
              +12% from last period
            </div>
          </div>
        </div>

        <div className="overview-card expenses">
          <div className="overview-icon">💸</div>
          <div className="overview-content">
            <h3>Total Expenses</h3>
            <div className="amount">{formatCurrency(financialData.totalExpenses || 0)}</div>
            <div className="trend negative">
              -5% from last period
            </div>
          </div>
        </div>

        <div className="overview-card profit">
          <div className="overview-icon">📈</div>
          <div className="overview-content">
            <h3>Net Profit</h3>
            <div className="amount">{formatCurrency(financialData.netProfit || 0)}</div>
            <div className="trend positive">
              +18% from last period
            </div>
          </div>
        </div>

        <div className="overview-card pending">
          <div className="overview-icon">⏳</div>
          <div className="overview-content">
            <h3>Pending Payments</h3>
            <div className="amount">{formatCurrency(financialData.pendingPayments || 0)}</div>
            <div className="count">{financialData.pendingCount || 0} invoices</div>
          </div>
        </div>
      </div>

      <div className="finance-content">
        {/* Recent Invoices */}
        <div className="finance-section">
          <div className="section-header">
            <h2>Recent Invoices</h2>
            <button className="btn btn-primary">Generate Report</button>
          </div>
          
          <div className="invoices-table">
            <div className="table-header">
              <div className="col">Invoice #</div>
              <div className="col">Parent</div>
              <div className="col">Date</div>
              <div className="col">Amount</div>
              <div className="col">Status</div>
              <div className="col">Due Date</div>
            </div>
            <div className="table-body">
              {invoices.slice(0, 10).map(invoice => {
                const status = getStatusBadge(invoice.status);
                return (
                  <div key={invoice._id} className="table-row">
                    <div className="col">
                      <strong>INV-{invoice.invoiceNumber}</strong>
                    </div>
                    <div className="col">
                      {invoice.parent?.firstName} {invoice.parent?.lastName}
                    </div>
                    <div className="col">
                      {new Date(invoice.invoiceDate).toLocaleDateString()}
                    </div>
                    <div className="col amount">
                      {formatCurrency(invoice.amount)}
                    </div>
                    <div className="col">
                      <span className={`status-badge status-${status.class}`}>
                        {status.text}
                      </span>
                    </div>
                    <div className="col">
                      {new Date(invoice.dueDate).toLocaleDateString()}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent Payments */}
        <div className="finance-section">
          <div className="section-header">
            <h2>Recent Payments</h2>
            <button className="btn btn-outline">View All</button>
          </div>
          
          <div className="payments-table">
            <div className="table-header">
              <div className="col">Payment ID</div>
              <div className="col">Parent</div>
              <div className="col">Date</div>
              <div className="col">Amount</div>
              <div className="col">Method</div>
              <div className="col">Status</div>
            </div>
            <div className="table-body">
              {payments.slice(0, 10).map(payment => (
                <div key={payment._id} className="table-row">
                  <div className="col">
                    <strong>PMT-{payment.paymentNumber}</strong>
                  </div>
                  <div className="col">
                    {payment.parent?.firstName} {payment.parent?.lastName}
                  </div>
                  <div className="col">
                    {new Date(payment.paymentDate).toLocaleDateString()}
                  </div>
                  <div className="col amount">
                    {formatCurrency(payment.amount)}
                  </div>
                  <div className="col">
                    <span className="payment-method">
                      {payment.paymentMethod === 'credit_card' ? '💳 Credit Card' : 
                       payment.paymentMethod === 'bank_transfer' ? '🏦 Bank Transfer' : 
                       payment.paymentMethod === 'cash' ? '💵 Cash' : 'Payment'}
                    </span>
                  </div>
                  <div className="col">
                    <span className={`status-badge status-${payment.status}`}>
                      {payment.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Financial Summary */}
        <div className="finance-section">
          <h2>Financial Summary</h2>
          <div className="summary-grid">
            <div className="summary-item">
              <span className="label">Total Income:</span>
              <span className="value income">{formatCurrency(financialData.totalRevenue || 0)}</span>
            </div>
            <div className="summary-item">
              <span className="label">Staff Salaries:</span>
              <span className="value expense">{formatCurrency(financialData.staffSalaries || 0)}</span>
            </div>
            <div className="summary-item">
              <span className="label">Operational Costs:</span>
              <span className="value expense">{formatCurrency(financialData.operationalCosts || 0)}</span>
            </div>
            <div className="summary-item">
              <span className="label">Supplies & Materials:</span>
              <span className="value expense">{formatCurrency(financialData.suppliesCost || 0)}</span>
            </div>
            <div className="summary-item total">
              <span className="label">Net Profit:</span>
              <span className="value profit">{formatCurrency(financialData.netProfit || 0)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Finance;