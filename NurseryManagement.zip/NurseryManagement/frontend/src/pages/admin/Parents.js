import React, { useState, useEffect } from 'react';
import { parentsService } from '../../services/parents';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import Modal from '../../components/common/Modal/Modal';
import './Parents.css';

const Parents = () => {
  const [parents, setParents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedParent, setSelectedParent] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    emergencyContact: {
      name: '',
      relationship: '',
      phone: ''
    }
  });

  useEffect(() => {
    loadParents();
  }, []);

  const loadParents = async () => {
    try {
      setLoading(true);
      const response = await parentsService.getAll();
      setParents(response.parents || response);
    } catch (error) {
      console.error('Error loading parents:', error);
      alert('Error loading parents data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (parent) => {
    setSelectedParent(parent);
    setFormData({
      firstName: parent.firstName,
      lastName: parent.lastName,
      email: parent.email,
      phone: parent.phone,
      address: parent.address || '',
      emergencyContact: parent.emergencyContact || {
        name: '',
        relationship: '',
        phone: ''
      }
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedParent) {
        await parentsService.update(selectedParent._id, formData);
        alert('Parent updated successfully');
      } else {
        await parentsService.create(formData);
        alert('Parent added successfully');
      }
      setShowModal(false);
      resetForm();
      loadParents();
    } catch (error) {
      console.error('Error saving parent:', error);
      alert('Error saving parent data');
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      }
    });
    setSelectedParent(null);
  };

  const getChildrenCount = (parent) => {
    return parent.children ? parent.children.length : 0;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-parents">
      <div className="page-header">
        <div className="header-content">
          <h1>Parents Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Add New Parent
          </button>
        </div>
      </div>

      <div className="parents-stats">
        <div className="stat-card">
          <div className="stat-icon">👨‍👩‍👧‍👦</div>
          <div className="stat-info">
            <h3>{parents.length}</h3>
            <p>Total Parents</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">👶</div>
          <div className="stat-info">
            <h3>{parents.reduce((total, parent) => total + getChildrenCount(parent), 0)}</h3>
            <p>Total Children</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-info">
            <h3>{parents.filter(p => p.billingStatus === 'overdue').length}</h3>
            <p>Overdue Payments</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <h3>{parents.filter(p => p.billingStatus === 'paid').length}</h3>
            <p>Active Accounts</p>
          </div>
        </div>
      </div>

      <div className="parents-table-container">
        <table className="parents-table">
          <thead>
            <tr>
              <th>Parent</th>
              <th>Contact</th>
              <th>Children</th>
              <th>Billing Status</th>
              <th>Last Payment</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {parents.map(parent => (
              <tr key={parent._id}>
                <td>
                  <div className="parent-info">
                    <div className="parent-avatar">
                      {parent.firstName?.charAt(0)}{parent.lastName?.charAt(0)}
                    </div>
                    <div className="parent-details">
                      <strong>{parent.firstName} {parent.lastName}</strong>
                      <span>ID: {parent.parentId}</span>
                    </div>
                  </div>
                </td>
                <td>
                  <div className="contact-info">
                    <div>{parent.email}</div>
                    <div className="phone">{parent.phone}</div>
                  </div>
                </td>
                <td>
                  <div className="children-count">
                    <span className="count-badge">{getChildrenCount(parent)}</span>
                    {parent.children && parent.children.map(child => (
                      <span key={child._id} className="child-name">
                        {child.firstName}
                      </span>
                    ))}
                  </div>
                </td>
                <td>
                  <span className={`billing-status status-${parent.billingStatus || 'paid'}`}>
                    {parent.billingStatus || 'Paid'}
                  </span>
                </td>
                <td>
                  {parent.lastPayment ? 
                    new Date(parent.lastPayment).toLocaleDateString() : 
                    'No payments'
                  }
                </td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn btn-sm btn-info"
                      onClick={() => handleEdit(parent)}
                    >
                      Edit
                    </button>
                    <button className="btn btn-sm btn-outline">
                      View
                    </button>
                    <button className="btn btn-sm btn-warning">
                      Billing
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Parent Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedParent ? 'Edit Parent' : 'Add New Parent'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="parent-form">
          <div className="form-section">
            <h3>Basic Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">First Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.firstName}
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Last Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.lastName}
                  onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input
                  type="email"
                  className="form-control"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone *</label>
                <input
                  type="tel"
                  className="form-control"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Address</label>
              <textarea
                className="form-control"
                rows="3"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Full address..."
              />
            </div>
          </div>

          <div className="form-section">
            <h3>Emergency Contact</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.name}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, name: e.target.value}
                  })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Relationship</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.relationship}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, relationship: e.target.value}
                  })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input
                  type="tel"
                  className="form-control"
                  value={formData.emergencyContact.phone}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, phone: e.target.value}
                  })}
                />
              </div>
            </div>
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedParent ? 'Update' : 'Add'} Parent
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Parents;