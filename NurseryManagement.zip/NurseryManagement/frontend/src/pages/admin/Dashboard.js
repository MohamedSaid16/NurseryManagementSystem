import React, { useState, useEffect } from 'react';
import { dashboardService } from '../../services/dashboard';
import  childrenService  from '../../services/children';
import employeesService  from '../../services/employees';
import  billingService  from '../../services/billing';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import './Dashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState({});
  const [recentActivities, setRecentActivities] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      const [statsRes, activitiesRes, eventsRes] = await Promise.all([
        dashboardService.getAdminStats(),
        dashboardService.getRecentActivities(),
        dashboardService.getUpcomingEvents()
      ]);

      setStats(statsRes);
      setRecentActivities(activitiesRes.activities || activitiesRes);
      setUpcomingEvents(eventsRes.events || eventsRes);
    } catch (error) {
      console.error('Error loading admin dashboard:', error);
      alert('Error loading dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-dashboard">
      <div className="page-header">
        <h1>Admin Dashboard</h1>
        <p>Welcome back! Here's what's happening today.</p>
      </div>

      {/* Statistics Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon total-children">👶</div>
          <div className="stat-info">
            <h3>{stats.totalChildren || 0}</h3>
            <p>Total Children</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon total-employees">👨‍🏫</div>
          <div className="stat-info">
            <h3>{stats.totalEmployees || 0}</h3>
            <p>Employees</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon total-parents">👨‍👩‍👧‍👦</div>
          <div className="stat-info">
            <h3>{stats.totalParents || 0}</h3>
            <p>Parents</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon revenue">💰</div>
          <div className="stat-info">
            <h3>${stats.monthlyRevenue || 0}</h3>
            <p>Monthly Revenue</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon attendance">📊</div>
          <div className="stat-info">
            <h3>{stats.todayAttendance || 0}%</h3>
            <p>Today's Attendance</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon pending">⏳</div>
          <div className="stat-info">
            <h3>{stats.pendingPayments || 0}</h3>
            <p>Pending Payments</p>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        {/* Recent Activities */}
        <div className="dashboard-section">
          <h2>Recent Activities</h2>
          <div className="activities-list">
            {recentActivities.map(activity => (
              <div key={activity._id} className="activity-item">
                <div className="activity-icon">{getActivityIcon(activity.type)}</div>
                <div className="activity-details">
                  <h4>{activity.title}</h4>
                  <p>{activity.description}</p>
                  <span className="activity-time">
                    {new Date(activity.startTime).toLocaleDateString()} • 
                    {new Date(activity.startTime).toLocaleTimeString()}
                  </span>
                </div>
                <div className="activity-room">{activity.room}</div>
              </div>
            ))}
            {recentActivities.length === 0 && (
              <p className="no-data">No recent activities</p>
            )}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="dashboard-section">
          <h2>Upcoming Events</h2>
          <div className="events-list">
            {upcomingEvents.map(event => (
              <div key={event._id} className="event-item">
                <div className="event-date">
                  <span className="event-day">
                    {new Date(event.date).getDate()}
                  </span>
                  <span className="event-month">
                    {new Date(event.date).toLocaleDateString('en', { month: 'short' })}
                  </span>
                </div>
                <div className="event-details">
                  <h4>{event.title}</h4>
                  <p>{event.description}</p>
                  <span className="event-time">
                    {new Date(event.date).toLocaleTimeString()}
                  </span>
                </div>
                <div className={`event-type ${event.type}`}>
                  {event.type}
                </div>
              </div>
            ))}
            {upcomingEvents.length === 0 && (
              <p className="no-data">No upcoming events</p>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <h2>Quick Actions</h2>
          <div className="quick-actions">
            <button className="action-btn">
              <span className="action-icon">➕</span>
              Add New Child
            </button>
            <button className="action-btn">
              <span className="action-icon">👨‍🏫</span>
              Manage Employees
            </button>
            <button className="action-btn">
              <span className="action-icon">💰</span>
              View Financial Reports
            </button>
            <button className="action-btn">
              <span className="action-icon">📊</span>
              Generate Reports
            </button>
            <button className="action-btn">
              <span className="action-icon">⚙️</span>
              System Settings
            </button>
            <button className="action-btn">
              <span className="action-icon">📧</span>
              Send Announcements
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function
const getActivityIcon = (type) => {
  const icons = {
    meal: '🍽️',
    nap: '😴',
    play: '🎮',
    learning: '📚',
    art: '🎨',
    music: '🎵',
    outdoor: '🌳'
  };
  return icons[type] || '📝';
};

export default AdminDashboard;