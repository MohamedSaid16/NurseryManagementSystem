import React, { useState, useEffect } from 'react';
import { employeesService } from '../../services/employees';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import Modal from '../../components/common/Modal/Modal';
import './Employees.css';

const Employees = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: 'teacher',
    salary: '',
    hireDate: '',
    qualifications: '',
    emergencyContact: {
      name: '',
      relationship: '',
      phone: ''
    }
  });

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      setLoading(true);
      const response = await employeesService.getAll();
      setEmployees(response.employees || response);
    } catch (error) {
      console.error('Error loading employees:', error);
      alert('Error loading employees data');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (employee) => {
    setSelectedEmployee(employee);
    setFormData({
      firstName: employee.firstName,
      lastName: employee.lastName,
      email: employee.email,
      phone: employee.phone,
      role: employee.role,
      salary: employee.salary || '',
      hireDate: employee.hireDate ? employee.hireDate.split('T')[0] : '',
      qualifications: employee.qualifications || '',
      emergencyContact: employee.emergencyContact || {
        name: '',
        relationship: '',
        phone: ''
      }
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedEmployee) {
        await employeesService.update(selectedEmployee._id, formData);
        alert('Employee updated successfully');
      } else {
        await employeesService.create(formData);
        alert('Employee added successfully');
      }
      setShowModal(false);
      resetForm();
      loadEmployees();
    } catch (error) {
      console.error('Error saving employee:', error);
      alert('Error saving employee data');
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      role: 'teacher',
      salary: '',
      hireDate: '',
      qualifications: '',
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      }
    });
    setSelectedEmployee(null);
  };

  const getRoleBadge = (role) => {
    const roleConfig = {
      teacher: { class: 'teacher', label: 'Teacher' },
      assistant: { class: 'assistant', label: 'Assistant' },
      admin: { class: 'admin', label: 'Admin' },
      director: { class: 'director', label: 'Director' }
    };
    return roleConfig[role] || { class: 'default', label: role };
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="admin-employees">
      <div className="page-header">
        <div className="header-content">
          <h1>Employees Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            Add New Employee
          </button>
        </div>
      </div>

      <div className="employees-stats">
        <div className="stat-card">
          <div className="stat-icon">👨‍🏫</div>
          <div className="stat-info">
            <h3>{employees.filter(e => e.role === 'teacher').length}</h3>
            <p>Teachers</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">👨‍💼</div>
          <div className="stat-info">
            <h3>{employees.filter(e => e.role === 'assistant').length}</h3>
            <p>Assistants</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">👨‍💻</div>
          <div className="stat-info">
            <h3>{employees.filter(e => e.role === 'admin').length}</h3>
            <p>Admins</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📊</div>
          <div className="stat-info">
            <h3>{employees.length}</h3>
            <p>Total Employees</p>
          </div>
        </div>
      </div>

      <div className="employees-table-container">
        <table className="employees-table">
          <thead>
            <tr>
              <th>Employee</th>
              <th>Role</th>
              <th>Contact</th>
              <th>Salary</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map(employee => {
              const role = getRoleBadge(employee.role);
              return (
                <tr key={employee._id}>
                  <td>
                    <div className="employee-info">
                      <div className="employee-avatar">
                        {employee.firstName?.charAt(0)}{employee.lastName?.charAt(0)}
                      </div>
                      <div className="employee-details">
                        <strong>{employee.firstName} {employee.lastName}</strong>
                        <span>ID: {employee.employeeId}</span>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`role-badge role-${role.class}`}>
                      {role.label}
                    </span>
                  </td>
                  <td>
                    <div className="contact-info">
                      <div>{employee.email}</div>
                      <div className="phone">{employee.phone}</div>
                    </div>
                  </td>
                  <td>
                    {employee.salary ? `$${employee.salary}` : 'N/A'}
                  </td>
                  <td>
                    <span className={`status-badge status-${employee.status || 'active'}`}>
                      {employee.status || 'Active'}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button 
                        className="btn btn-sm btn-info"
                        onClick={() => handleEdit(employee)}
                      >
                        Edit
                      </button>
                      <button className="btn btn-sm btn-outline">
                        View
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Employee Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title={selectedEmployee ? 'Edit Employee' : 'Add New Employee'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="employee-form">
          <div className="form-section">
            <h3>Basic Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">First Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.firstName}
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Last Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.lastName}
                  onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input
                  type="email"
                  className="form-control"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone *</label>
                <input
                  type="tel"
                  className="form-control"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Role *</label>
                <select
                  className="form-control"
                  value={formData.role}
                  onChange={(e) => setFormData({...formData, role: e.target.value})}
                  required
                >
                  <option value="teacher">Teacher</option>
                  <option value="assistant">Assistant</option>
                  <option value="admin">Admin</option>
                  <option value="director">Director</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Salary</label>
                <input
                  type="number"
                  className="form-control"
                  value={formData.salary}
                  onChange={(e) => setFormData({...formData, salary: e.target.value})}
                  placeholder="Annual salary"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Hire Date</label>
                <input
                  type="date"
                  className="form-control"
                  value={formData.hireDate}
                  onChange={(e) => setFormData({...formData, hireDate: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Additional Information</h3>
            <div className="form-group">
              <label className="form-label">Qualifications</label>
              <textarea
                className="form-control"
                rows="3"
                value={formData.qualifications}
                onChange={(e) => setFormData({...formData, qualifications: e.target.value})}
                placeholder="Educational qualifications, certifications..."
              />
            </div>
          </div>

          <div className="form-section">
            <h3>Emergency Contact</h3>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.name}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, name: e.target.value}
                  })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Relationship</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.emergencyContact.relationship}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, relationship: e.target.value}
                  })}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input
                  type="tel"
                  className="form-control"
                  value={formData.emergencyContact.phone}
                  onChange={(e) => setFormData({
                    ...formData,
                    emergencyContact: {...formData.emergencyContact, phone: e.target.value}
                  })}
                />
              </div>
            </div>
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {selectedEmployee ? 'Update' : 'Add'} Employee
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Employees;