
import React from 'react';
import Messages from '../../components/parent/Messages/Messages';

const MessagesPage = () => {
  return <Messages />;
};

export default MessagesPage;