import React from 'react';
import ParentDashboard from '../../components/parent/Dashboard/ParentDashboard';

const Dashboard = () => {
  return <ParentDashboard />;
};

export default Dashboard;