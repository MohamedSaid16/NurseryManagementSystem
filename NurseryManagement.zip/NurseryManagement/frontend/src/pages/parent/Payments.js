import React from 'react';
import Billing from '../../components/parent/Billing/Billing';

const Payments = () => {
  return <Billing />;
};

export default Payments;