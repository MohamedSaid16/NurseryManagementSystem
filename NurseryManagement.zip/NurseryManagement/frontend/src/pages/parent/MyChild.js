import React from 'react';
import ChildProfile from '../../components/parent/ChildProfile/ChildProfile';

const MyChild = () => {
  return <ChildProfile />;
};

export default MyChild;