import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import  authService  from '../../services/auth';
import LoadingSpinner from '../../components/common/LoadingSpinner/LoadingSpinner';
import './ForgotPassword.css';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    try {
      await authService.forgotPassword(email);
      setMessage('Password reset instructions have been sent to your email.');
      setEmail('');
    } catch (error) {
      setError(error.message || 'Failed to send reset instructions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="forgot-password-page">
      <div className="forgot-password-container">
        <div className="forgot-password-header">
          <div className="logo">
            <span className="logo-icon">👶</span>
            <h1>Nursery Care</h1>
          </div>
          <h2>Forgot Password</h2>
          <p>Enter your email to reset your password</p>
        </div>

        <form onSubmit={handleSubmit} className="forgot-password-form">
          {message && (
            <div className="alert alert-success">
              {message}
            </div>
          )}

          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email" className="form-label">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              className="form-control"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={loading}
              placeholder="Enter your email address"
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary reset-btn"
            disabled={loading}
          >
            {loading ? <LoadingSpinner size="small" /> : 'Send Reset Instructions'}
          </button>
        </form>

        <div className="forgot-password-footer">
          <p>
            Remember your password?{' '}
            <Link to="/login" className="login-link">
              Back to Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;